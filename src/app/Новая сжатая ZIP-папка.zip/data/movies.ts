import { generatedKinoLumaMovies } from "./generatedMovies";
import { generatedKinoLumaCartoons } from "./generatedCartoons";
import { generatedKinopoiskRequestedMovies } from "./generatedKinopoiskRequested";
import { curatedExpectedReleases } from "./curatedExpectedReleases";
import { manualPremiumAdditions } from "./manualPremiumAdditions";
import { manualPopularAnime } from "./manualPopularAnime";

export type ContentType = "Фильм" | "Сериал" | "Аниме" | "Мультфильм" | "Документальный";

export type MovieFact = {
  label: string;
  value: string;
};

export type CastMember = {
  name: string;
  role: string;
};

export type PlayerProvider = {
  id: string;
  name: string;
  embedUrl: string;
  type?: "iframe" | "rendex" | "collapse" | "collapse-iframe" | "vibix-iframe";
  provider?: string;
  publisherId?: string;
  contentType?: string;
  contentId?: string;
  contentKind?: string;
  scriptSrc?: string;
  design?: string;
  color1?: string;
  color2?: string;
  color3?: string;
  color4?: string;
  color5?: string;
};

export type Movie = {
  id: number;
  kinopoiskId?: number;
  slug: string;
  title: string;
  originalTitle: string;
  searchTitles: string[];
  type: ContentType;
  year: string;
  rating: number;
  genres: string[];
  poster: string;
  posterFallbacks?: string[];
  backdrop?: string;
  description: string;
  trailerUrl: string;
  tmdbId?: number;
  imdbId?: string;
  countries?: string[];
  source?: string;
  longDescription?: string;
  facts?: MovieFact[];
  cast?: CastMember[];
  players?: PlayerProvider[];
};

function createKinoLumaPoster(title: string, originalTitle: string, label = "ФИЛЬМ") {
  const safeTitle = escapePosterText(title.toUpperCase());
  const safeOriginalTitle = escapePosterText(originalTitle);
  const safeLabel = escapePosterText(label);

  const svg = `
    <svg width="500" height="750" viewBox="0 0 500 750" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="0" y2="750" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stop-color="#2f2f35"/>
          <stop offset="52%" stop-color="#0b0b0b"/>
          <stop offset="100%" stop-color="#000000"/>
        </linearGradient>
        <radialGradient id="glow" cx="50%" cy="20%" r="70%">
          <stop offset="0%" stop-color="#ffffff" stop-opacity="0.24"/>
          <stop offset="100%" stop-color="#ffffff" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <rect width="500" height="750" fill="url(#bg)"/>
      <rect width="500" height="750" fill="url(#glow)"/>
      <rect x="30" y="30" width="440" height="690" rx="36" stroke="#ffffff" stroke-opacity="0.16" stroke-width="2"/>
      <circle cx="250" cy="270" r="118" fill="#ffffff" opacity="0.055"/>
      <circle cx="250" cy="270" r="78" stroke="#ffffff" stroke-opacity="0.20" stroke-width="12"/>
      <path d="M226 222V318L306 270L226 222Z" fill="#ffffff" opacity="0.88"/>
      <rect x="124" y="394" width="252" height="44" rx="22" fill="#ffffff" fill-opacity="0.92"/>
      <text x="250" y="423" text-anchor="middle" fill="#000000" font-family="Arial, Helvetica, sans-serif" font-size="16" font-weight="900" letter-spacing="3">${safeLabel}</text>
      <text x="250" y="510" text-anchor="middle" fill="#ffffff" font-family="Arial, Helvetica, sans-serif" font-size="32" font-weight="900">${safeTitle}</text>
      <text x="250" y="558" text-anchor="middle" fill="#a3a3a3" font-family="Arial, Helvetica, sans-serif" font-size="18" font-weight="800">${safeOriginalTitle}</text>
      <text x="250" y="662" text-anchor="middle" fill="#737373" font-family="Arial, Helvetica, sans-serif" font-size="18" font-weight="900">KinoLuma</text>
    </svg>
  `;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}


function escapePosterText(text: string) {
  return text
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;");
}


function getTmdbPoster(input: {
  tmdbId?: number;
  imdbId?: string;
  title: string;
  originalTitle?: string;
  year?: string | number;
  type?: ContentType | string;
}) {
  const params = new URLSearchParams();

  if (input.tmdbId) params.set("tmdbId", String(input.tmdbId));
  if (input.imdbId) params.set("imdbId", input.imdbId);
  params.set("title", input.title);
  if (input.originalTitle) params.set("originalTitle", input.originalTitle);
  if (input.year) params.set("year", String(input.year));
  if (input.type) params.set("type", String(input.type));

  // Меняем версию, чтобы браузер не держал старый 302-редирект на /kinoluma-icon.png.
  params.set("quality", "high");
  params.set("v", "3");

  return `/api/tmdb/poster?${params.toString()}`;
}

function getKinopoiskPoster(input: {
  kinopoiskId?: number | string | null;
  fallback?: string;
}) {
  const id = String(input.kinopoiskId || "").match(/\d+/)?.[0] || "";
  if (!id) return input.fallback || "/kinoluma-icon.png";

  const params = new URLSearchParams();
  params.set("kpId", id);
  // v=kp-2 нужен, чтобы браузер и Vercel не держали старый 302-редирект на /kinoluma-icon.png.
  params.set("v", "kp-2");

  if (input.fallback && !input.fallback.startsWith("data:")) {
    params.set("fallback", input.fallback);
  }

  return `/api/kinopoisk/poster?${params.toString()}`;
}

function createKinopoiskPlayers(kinopoiskId: number): PlayerProvider[] {
  const id = String(kinopoiskId);

  return [
    {
      id: `collapse-kp-${id}`,
      name: "Основной",
      type: "collapse",
      provider: "collapse",
      embedUrl: `https://api.ortified.ws/embed/kp/${id}?sharing=false&episodesOpen=false`,
      contentKind: "kp",
      contentType: "kp",
      contentId: id,
    },
    {
      id: `factorios-${id}`,
      name: "Запасной 1",
      type: "iframe",
      provider: "factorios",
      embedUrl: `https://tarantino.factorios.live/show/kinopoisk/${id}`,
    },
  ];
}

function splitPosterLine(text: string, maxLength: number, maxLines: number) {
  const words = text.split(" ").filter(Boolean);
  const lines: string[] = [];

  for (const word of words) {
    const currentLine = lines[lines.length - 1];

    if (!currentLine) {
      lines.push(word);
      continue;
    }

    if (`${currentLine} ${word}`.length <= maxLength) {
      lines[lines.length - 1] = `${currentLine} ${word}`;
      continue;
    }

    if (lines.length < maxLines) {
      lines.push(word);
    }
  }

  return lines.length > 0 ? lines.slice(0, maxLines) : [text];
}

function createCartoonPoster(
  title: string,
  originalTitle: string,
  accent = "#facc15",
  secondary = "#fb7185",
) {
  const titleLines = splitPosterLine(title.toUpperCase(), 16, 3);
  const originalLines = splitPosterLine(originalTitle, 24, 2);
  const titleStartY = titleLines.length === 1 ? 500 : titleLines.length === 2 ? 470 : 440;
  const originalStartY = originalLines.length === 1 ? 608 : 586;

  const titleText = titleLines
    .map(
      (line, index) =>
        `<text x="250" y="${titleStartY + index * 45}" text-anchor="middle" fill="#ffffff" stroke="#111827" stroke-opacity="0.35" stroke-width="6" paint-order="stroke" font-family="Arial, Helvetica, sans-serif" font-size="36" font-weight="900" letter-spacing="-0.5">${escapePosterText(line)}</text>`,
    )
    .join("");

  const originalText = originalLines
    .map(
      (line, index) =>
        `<text x="250" y="${originalStartY + index * 26}" text-anchor="middle" fill="#f8fafc" font-family="Arial, Helvetica, sans-serif" font-size="17" font-weight="800" opacity="0.86">${escapePosterText(line)}</text>`,
    )
    .join("");

  const svg = `
    <svg width="500" height="750" viewBox="0 0 500 750" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="0" y2="750" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stop-color="#0f172a"/>
          <stop offset="48%" stop-color="#111827"/>
          <stop offset="100%" stop-color="#030712"/>
        </linearGradient>
        <radialGradient id="glow" cx="50%" cy="20%" r="70%">
          <stop offset="0%" stop-color="${accent}" stop-opacity="0.70"/>
          <stop offset="56%" stop-color="${secondary}" stop-opacity="0.18"/>
          <stop offset="100%" stop-color="#000000" stop-opacity="0"/>
        </radialGradient>
        <linearGradient id="shade" x1="0" y1="0" x2="0" y2="750" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stop-color="#000000" stop-opacity="0"/>
          <stop offset="58%" stop-color="#000000" stop-opacity="0.10"/>
          <stop offset="100%" stop-color="#000000" stop-opacity="0.70"/>
        </linearGradient>
      </defs>

      <rect width="500" height="750" fill="url(#bg)"/>
      <rect width="500" height="750" fill="url(#glow)"/>
      <circle cx="94" cy="142" r="46" fill="${accent}" opacity="0.82"/>
      <circle cx="410" cy="176" r="72" fill="${secondary}" opacity="0.72"/>
      <circle cx="382" cy="446" r="108" fill="${accent}" opacity="0.18"/>
      <path d="M80 538C150 438 224 478 288 354C336 260 370 246 436 204" stroke="#ffffff" stroke-opacity="0.17" stroke-width="72" stroke-linecap="round"/>
      <path d="M120 176C176 116 262 104 328 148C398 194 414 286 362 354C308 424 198 410 148 340C106 282 78 222 120 176Z" fill="#ffffff" opacity="0.10"/>
      <path d="M166 274C198 236 242 236 274 274C306 236 350 236 382 274" stroke="#ffffff" stroke-opacity="0.36" stroke-width="18" stroke-linecap="round"/>
      <circle cx="190" cy="258" r="15" fill="#ffffff" opacity="0.72"/>
      <circle cx="350" cy="258" r="15" fill="#ffffff" opacity="0.72"/>
      <path d="M210 348C246 382 300 382 336 348" stroke="${accent}" stroke-opacity="0.82" stroke-width="16" stroke-linecap="round"/>
      <g fill="#ffffff" opacity="0.70">
        <circle cx="82" cy="340" r="3"/><circle cx="132" cy="476" r="2.5"/><circle cx="326" cy="112" r="3"/><circle cx="422" cy="356" r="2.5"/><circle cx="236" cy="170" r="2.5"/>
      </g>
      <rect width="500" height="750" fill="url(#shade)"/>
      <rect x="28" y="28" width="444" height="694" rx="34" stroke="#ffffff" stroke-opacity="0.16" stroke-width="2"/>
      <text x="64" y="86" fill="#ffffff" font-family="Arial, Helvetica, sans-serif" font-size="18" font-weight="900" letter-spacing="3">МУЛЬТФИЛЬМ</text>
      <rect x="134" y="366" width="232" height="44" rx="22" fill="#020617" fill-opacity="0.46" stroke="#ffffff" stroke-opacity="0.16"/>
      <text x="250" y="394" text-anchor="middle" fill="${accent}" font-family="Arial, Helvetica, sans-serif" font-size="16" font-weight="900" letter-spacing="3">MOVIEHUB KIDS</text>
      ${titleText}
      ${originalText}
      <rect x="150" y="646" width="200" height="42" rx="21" fill="#ffffff" fill-opacity="0.94"/>
      <text x="250" y="672" text-anchor="middle" fill="#000000" font-family="Arial, Helvetica, sans-serif" font-size="15" font-weight="900">Смотреть легально</text>
    </svg>
  `;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}


function compactMovieText(text: string) {
  return text.replace(/\s+/g, " ").trim();
}

function getFactValueFromMovie(movie: Movie, labels: string[]) {
  const normalizedLabels = labels.map((label) => label.toLowerCase());

  return movie.facts?.find((fact) =>
    normalizedLabels.includes(fact.label.toLowerCase()),
  )?.value;
}

function appendMovieFact(movie: Movie, label: string, value?: string | number | null) {
  if (value === undefined || value === null || value === "") return;

  const textValue = String(value);
  movie.facts = movie.facts ?? [];

  if (movie.facts.some((fact) => fact.label.toLowerCase() === label.toLowerCase())) {
    return;
  }

  movie.facts.push({ label, value: textValue });
}

function getReadableContentType(movie: Movie) {
  if (movie.type === "Сериал") return "сериал";
  if (movie.type === "Аниме") return "аниме";
  if (movie.type === "Мультфильм") return "мультфильм";
  if (movie.type === "Документальный") return "документальный проект";
  if (movie.genres.includes("Анимация")) return "анимационный фильм";
  return "фильм";
}

function createExpandedMovieDescription(movie: Movie) {
  const kind = getReadableContentType(movie);
  const genres = movie.genres.length > 0 ? movie.genres.join(", ").toLowerCase() : "кино";
  const country = movie.countries?.join(", ") || getFactValueFromMovie(movie, ["Страна", "Страны"]);
  const duration = getFactValueFromMovie(movie, ["Длительность", "Хронометраж"]);
  const director = getFactValueFromMovie(movie, ["Режиссёр", "Режиссёры", "Создатель", "Создатели"]);
  const studio = getFactValueFromMovie(movie, ["Студия"]);
  const rating = movie.rating > 0 ? `Рейтинг — ${movie.rating.toFixed(1)} из 10.` : "Рейтинг появится после обновления карточки.";
  const heroes = movie.cast && movie.cast.length > 0
    ? movie.cast.slice(0, 5).map((person) => `${person.name} — ${person.role}`).join(", ")
    : getFactValueFromMovie(movie, ["Главные герои", "Главные персонажи"]);
  const factualParts = [
    country ? `страна: ${country}` : "",
    duration ? `длительность: ${duration}` : "",
    director ? `режиссура/создатели: ${director}` : "",
    studio ? `студия: ${studio}` : "",
  ].filter(Boolean).join("; ");

  const firstParagraph = `«${movie.title}» (${movie.year}) — ${kind} в жанрах ${genres}. ${movie.description}`;
  const secondParagraph = factualParts
    ? `В карточке указаны проверяемые сведения: ${factualParts}. ${heroes ? `В центре внимания: ${heroes}.` : "Информация о героях и актёрах отображается, если она добавлена в карточку."}`
    : `${heroes ? `В центре внимания: ${heroes}.` : "Карточка не выдумывает детали: дополнительные сведения появляются только тогда, когда они уже есть в каталоге."}`;
  const thirdParagraph = `${rating} Этот материал удобно открыть, когда хочется заранее понять настроение, жанры, темп и состав истории перед просмотром. На странице есть краткая карточка, расширенный блок «О фильме», трейлер при наличии и варианты просмотра, если они доступны.`;

  return [firstParagraph, secondParagraph, thirdParagraph]
    .map((part) => compactMovieText(part))
    .join("\n\n");
}

function trimMovieDescription(text: string, maxLength = 940) {
  const paragraphs = text
    .split(/\n{2,}/)
    .map((paragraph) => compactMovieText(paragraph))
    .filter(Boolean);
  const cleanText = paragraphs.join("\n\n");

  if (cleanText.length <= maxLength) return cleanText;

  return `${cleanText.slice(0, maxLength).replace(/\s+\S*$/, "")}.`;
}

function needsPublicLongDescriptionRefresh(value: string | undefined) {
  if (!value) return true;

  return (
    value.length < 560 ||
    /SEO|FAQ-размет|JSON-LD|Kinopoisk|Кинопоиск|TMDB|IMDb|IMDB|источник их отдаёт|страница подготовлена/i.test(value)
  );
}

function containsPublicProviderName(value: string) {
  return /kinopoisk|кинопоиск|tmdb|themoviedb|imdb|\btt\d{5,}\b/i.test(value);
}

function sanitizePublicMovieText(value: string | undefined) {
  if (!value) return value;

  return compactMovieText(
    value
      .replace(/плеерами\s+Collapse\/Factorios\s+по\s+Kinopoisk\s+ID/gi, "вариантами просмотра")
      .replace(/плеерами\s+Collapse\/Factorios\s+по\s+Kinopoisk/gi, "вариантами просмотра")
      .replace(/плеерами\s+по\s+Kinopoisk\s+ID/gi, "вариантами просмотра")
      .replace(/плеерами\s+по\s+Kinopoisk/gi, "вариантами просмотра")
      .replace(/по\s+Kinopoisk\s+ID/gi, "для удобного просмотра")
      .replace(/по\s+Kinopoisk/gi, "для удобного просмотра")
      .replace(/по\s+Кинопоиск\s+ID/gi, "для удобного просмотра")
      .replace(/по\s+Кинопоиску/gi, "для удобного просмотра")
      .replace(/Kinopoisk\s+ID/gi, "каталожный номер")
      .replace(/Кинопоиск\s+ID/gi, "каталожный номер")
      .replace(/IMDb\s+ID/gi, "каталожный номер")
      .replace(/IMDB\s+ID/gi, "каталожный номер")
      .replace(/Kinopoisk/gi, "KinoLuma")
      .replace(/Кинопоиск/gi, "KinoLuma")
      .replace(/TMDB/gi, "KinoLuma")
      .replace(/themoviedb/gi, "KinoLuma")
      .replace(/IMDb/gi, "KinoLuma")
      .replace(/IMDB/gi, "KinoLuma")
      .replace(/Рейтинг\s+KinoLuma/gi, "Рейтинг")
      .replace(/для\s+SEO/gi, "для удобной навигации")
      .replace(/для\s+продвижения/gi, "для удобной навигации")
      .replace(/поисков(?:ая|ую|ой)\s+точк(?:а|у|ой)\s+входа/gi, "подборку")
      .replace(/поисковые\s+страницы/gi, "страницы подборок")
      .replace(/описание,?\s*/gi, "")
      .replace(/описание,?\s*/gi, "")
      .replace(/описание,?\s*/gi, "")
      .replace(/шаблонный\s+SEO(?:-слой)?/gi, "описание")
      .replace(/SEO\/FAQ/gi, "описание")
      .replace(/SEO\s+и\s+FAQ/gi, "описание")
      .replace(/FAQPage\s+JSON-LD/gi, "дополнительные сведения")
      .replace(/JSON-LD/gi, "")
      .replace(/дополнительные сведения\s+и\s+/gi, "")
      .replace(/FAQ\s+через\s+общий\s+шаблон\s+страницы\s+и\s+/gi, "")
      .replace(/,?\s*дополнительные сведения/gi, "")
      .replace(/,?\s*описание/gi, "")
      .replace(/,?\s*описание/gi, "")
      .replace(/,?\s*описание/gi, "")
      .replace(/sitemap,?\s*/gi, "")
      .replace(/служебные данные,?\s*/gi, "")
      .replace(/movies\.ts/gi, "каталог")
      .replace(/серверн(?:ый|ого|ым|ая|ую)?\s+[A-Za-zА-Яа-яёЁ-]+-роут(?:а|ом)?/gi, "внутренний каталог")
      .replace(/если источник их отдаёт/gi, "если информация есть в карточке")
      .replace(/после обновления источников/gi, "после обновления карточки")
      .replace(/источник их отдаёт/gi, "информация есть в карточке")
      .replace(/источников/gi, "данных")
      .replace(/источник/gi, "данные"),
  );
}

function sanitizeMoviePublicFields(movie: Movie) {
  movie.description = sanitizePublicMovieText(movie.description) || movie.description;
  movie.longDescription = sanitizePublicMovieText(movie.longDescription);

  if (movie.facts?.length) {
    movie.facts = movie.facts
      .filter((fact) => !containsPublicProviderName(`${fact.label} ${fact.value}`))
      .map((fact) => ({
        label: sanitizePublicMovieText(fact.label) || fact.label,
        value: sanitizePublicMovieText(fact.value) || fact.value,
      }));
  }

  return movie;
}

export function sanitizeMovieForPublicDisplay(movie: Movie): Movie {
  return sanitizeMoviePublicFields({
    ...movie,
    genres: [...(movie.genres ?? [])],
    searchTitles: [...(movie.searchTitles ?? [])],
    countries: movie.countries ? [...movie.countries] : undefined,
    facts: movie.facts ? movie.facts.map((fact) => ({ ...fact })) : undefined,
    cast: movie.cast ? movie.cast.map((person) => ({ ...person })) : undefined,
    players: movie.players ? movie.players.map((player) => ({ ...player })) : undefined,
    posterFallbacks: movie.posterFallbacks ? [...movie.posterFallbacks] : undefined,
  });
}

function getMoviePosterFallback(movie: Movie) {
  const currentPoster =
    movie.poster &&
    !movie.poster.startsWith("data:") &&
    !movie.poster.includes("/api/kinopoisk/poster")
      ? movie.poster
      : "";

  const tmdbPoster = getTmdbPoster({
    tmdbId: movie.tmdbId,
    imdbId: movie.imdbId,
    title: movie.title,
    originalTitle: movie.originalTitle,
    year: movie.year,
    type: movie.type,
  });

  return currentPoster || tmdbPoster;
}

function hydrateMovieContent(movie: Movie) {
  appendMovieFact(movie, "Год", movie.year);
  appendMovieFact(movie, "Тип", movie.type);
  appendMovieFact(movie, "Жанры", movie.genres.join(", "));

  if (movie.kinopoiskId) {
    const fallbackPoster = getMoviePosterFallback(movie);
    movie.poster = getKinopoiskPoster({
      kinopoiskId: movie.kinopoiskId,
      fallback: fallbackPoster,
    });

    if (fallbackPoster) {
      movie.posterFallbacks = Array.from(
        new Set([...(movie.posterFallbacks ?? []), fallbackPoster]),
      );
    }
  }

  if (movie.rating > 0) {
    appendMovieFact(movie, "Рейтинг", movie.rating.toFixed(1));
  }

  if (movie.cast && movie.cast.length > 0) {
    appendMovieFact(
      movie,
      "Главные герои",
      movie.cast.slice(0, 5).map((person) => `${person.name} — ${person.role}`).join(", "),
    );
  }

  if (movie.kinopoiskId && (!movie.players || movie.players.length === 0)) {
    const kinopoiskPlayers = createKinopoiskPlayers(movie.kinopoiskId);
    movie.players = movie.type === "Аниме" ? kinopoiskPlayers.slice(0, 1) : kinopoiskPlayers;
  }

  if (needsPublicLongDescriptionRefresh(movie.longDescription)) {
    movie.longDescription = trimMovieDescription(createExpandedMovieDescription(movie));
  }
}

const moviesRaw: Movie[] = [
  {
      id: 1,
      kinopoiskId: 4540126,
      slug: "dune-part-two",
      title: "Дюна: Часть вторая",
      originalTitle: "Dune: Part Two",
      searchTitles: ["дюна", "дюна 2", "дюна часть 2", "дюна часть вторая"],
      type: "Фильм",
      year: "2024",
      rating: 8.5,
      genres: ["Фантастика", "Приключения", "Драма"],
      poster: "https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg",
      description: "Эпическая фантастика о власти, пустыне и судьбе.",
      trailerUrl: "https://www.youtube.com/embed/Way9Dexny3w",
      longDescription:
        "«Дюна: Часть вторая» — фильм 2024 года в жанрах Фантастика, Приключения, Драма, где эпическая фантастика о власти, пустыне и судьбе. Пол Атрейдес объединяется с Чани и фременами, чтобы отомстить тем, кто уничтожил его семью. Но чем ближе он подходит к власти, тем сильнее становится выбор между личной любовью и судьбой всей вселенной. Работа Denis Villeneuve и команды Legendary Pictures чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "166 мин" },
        { label: "Бюджет", value: "$190 млн" },
        { label: "Студия", value: "Legendary Pictures" },
        { label: "Дистрибьютор", value: "Warner Bros. Pictures" },
        { label: "Режиссёр", value: "Denis Villeneuve" },
      ],
      cast: [
        { name: "Timothée Chalamet", role: "Пол Атрейдес" },
        { name: "Zendaya", role: "Чани" },
        { name: "Rebecca Ferguson", role: "Леди Джессика" },
        { name: "Javier Bardem", role: "Стилгар" },
        { name: "Austin Butler", role: "Фейд-Раута Харконнен" },
        { name: "Florence Pugh", role: "Принцесса Ирулан" },
        { name: "Josh Brolin", role: "Гурни Халлек" },
        { name: "Dave Bautista", role: "Глоссу Раббан" },
      ],
      players: [
        {
          id: "factorios-4540126",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/4540126",
        },
      ],
    },
  {
      id: 2,
      kinopoiskId: 4664634,
      slug: "oppenheimer",
      title: "Оппенгеймер",
      originalTitle: "Oppenheimer",
      searchTitles: ["оппенгеймер", "опенгеймер"],
      type: "Фильм",
      year: "2023",
      rating: 8.3,
      genres: ["Биография", "Драма", "История"],
      poster: "https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg",
      description: "История учёного, который изменил ход XX века.",
      trailerUrl: "https://www.youtube.com/embed/uYPbbksJxIg",
      longDescription:
        "«Оппенгеймер» — фильм 2023 года в жанрах Биография, Драма, История, где история учёного, который изменил ход XX века. История Дж. Роберта Оппенгеймера показывает путь учёного, который оказался в центре Манхэттенского проекта. Это напряжённая биографическая драма о гениальности, ответственности и последствиях решений, которые меняют историю. Работа Christopher Nolan и команды Universal Pictures чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2023" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Великобритания" },
        { label: "Длительность", value: "180 мин" },
        { label: "Бюджет", value: "$100 млн" },
        { label: "Студия", value: "Universal Pictures" },
        { label: "Режиссёр", value: "Christopher Nolan" },
        { label: "Жанры", value: "Биография, Драма, История" },
      ],
      cast: [
        { name: "Cillian Murphy", role: "Дж. Роберт Оппенгеймер" },
        { name: "Emily Blunt", role: "Китти Оппенгеймер" },
        { name: "Matt Damon", role: "Лесли Гровс" },
        { name: "Robert Downey Jr.", role: "Льюис Штраус" },
        { name: "Florence Pugh", role: "Джин Тэтлок" },
      ],
      players: [
        {
          id: "factorios-4664634",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/4664634",
        },
      ],
    },
  {
      id: 3,
      kinopoiskId: 258687,
      slug: "interstellar",
      title: "Интерстеллар",
      originalTitle: "Interstellar",
      searchTitles: ["интерстеллар", "интерстелар", "межзвездный", "межзвёздный"],
      type: "Фильм",
      year: "2014",
      rating: 8.7,
      genres: ["Фантастика", "Драма", "Приключения"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/c/c3/Interstellar_2014.jpg",
      description: "Путешествие через космос ради спасения человечества.",
      trailerUrl: "https://www.youtube.com/embed/2LqzF5WauAw",
      longDescription:
        "«Интерстеллар» — фильм 2014 года в жанрах Фантастика, Драма, Приключения, где путешествие через космос ради спасения человечества. В будущем Земля становится всё менее пригодной для жизни, и группа исследователей отправляется через червоточину искать новый дом для человечества. Это фантастика о времени, семье и надежде, где космос огромен, а главная ставка — человеческая связь. Работа Christopher Nolan и команды Paramount Pictures, Warner Bros. чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2014" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Великобритания" },
        { label: "Длительность", value: "169 мин" },
        { label: "Бюджет", value: "$165 млн" },
        { label: "Студия", value: "Paramount Pictures, Warner Bros." },
        { label: "Режиссёр", value: "Christopher Nolan" },
        { label: "Темы", value: "Космос, семья, время" },
      ],
      cast: [
        { name: "Matthew McConaughey", role: "Купер" },
        { name: "Anne Hathaway", role: "Амелия Бранд" },
        { name: "Jessica Chastain", role: "Мёрф" },
        { name: "Mackenzie Foy", role: "Юная Мёрф" },
        { name: "Michael Caine", role: "Профессор Бранд" },
      ],
      players: [
        {
          id: "factorios-258687",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/258687",
        },
      ],
    },
  {
      id: 4,
      kinopoiskId: 590286,
      slug: "the-batman",
      title: "Бэтмен",
      originalTitle: "The Batman",
      searchTitles: ["бетмен", "бэтмен", "бэтман", "batman"],
      type: "Фильм",
      year: "2022",
      rating: 7.8,
      genres: ["Криминал", "Драма", "Экшен"],
      poster: "https://image.tmdb.org/t/p/w500/74xTEgt7R36Fpooo50r9T25onhq.jpg",
      description: "Мрачная детективная история о Готэме.",
      trailerUrl: "https://www.youtube.com/embed/mqqft2x_Aa4",
      longDescription:
        "«Бэтмен» — фильм 2022 года в жанрах Криминал, Драма, Экшен, где мрачная детективная история о Готэме. Брюс Уэйн только начинает понимать, каким символом может стать Бэтмен для Готэма. Детективное расследование приводит его к загадкам Риддлера, коррупции города и вопросу: достаточно ли страха, чтобы изменить систему. Работа Matt Reeves и команды Warner Bros., DC Films чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2022" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "176 мин" },
        { label: "Бюджет", value: "$185–200 млн" },
        { label: "Студия", value: "Warner Bros., DC Films" },
        { label: "Режиссёр", value: "Matt Reeves" },
        { label: "Настроение", value: "Мрачно, детективно, нуарно" },
      ],
      cast: [
        { name: "Robert Pattinson", role: "Брюс Уэйн / Бэтмен" },
        { name: "Zoë Kravitz", role: "Селина Кайл" },
        { name: "Paul Dano", role: "Риддлер" },
        { name: "Jeffrey Wright", role: "Джеймс Гордон" },
        { name: "Colin Farrell", role: "Пингвин" },
      ],
      players: [
        {
          id: "factorios-590286",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/590286",
        },
      ],
    },
  {
      id: 5,
      kinopoiskId: 1219177,
      slug: "spider-man-across-the-spider-verse",
      title: "Человек-паук: Паутина вселенных",
      originalTitle: "Spider-Man: Across the Spider-Verse",
      searchTitles: [
        "человек паук",
        "человек-паук",
        "спайдермен",
        "через вселенные",
        "паутина вселенных",
        "spider man",
        "spiderman",
      ],
      type: "Фильм",
      year: "2023",
      rating: 8.6,
      genres: ["Анимация", "Экшен", "Приключения"],
      poster: "https://image.tmdb.org/t/p/w500/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg",
      description: "Стильная мультивселенная Человека-паука.",
      trailerUrl: "https://www.youtube.com/embed/shW9i6k8cB0",
      longDescription:
        "«Человек-паук: Паутина вселенных» — фильм 2023 года в жанрах Анимация, Экшен, Приключения, где стильная мультивселенная Человека-паука. Майлз Моралес сталкивается с огромной паутиной альтернативных миров и версий Человека-паука. Мультвселенная проверяет его дружбу, выбор и право самому решать, каким героем он станет. Работа Joaquim Dos Santos, Kemp Powers, Justin K. Thompson и команды Sony Pictures Animation чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2023" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "140 мин" },
        { label: "Бюджет", value: "$100 млн" },
        { label: "Студия", value: "Sony Pictures Animation" },
        { label: "Режиссёры", value: "Joaquim Dos Santos, Kemp Powers, Justin K. Thompson" },
        { label: "Формат", value: "Анимационный фильм" },
      ],
      cast: [
        { name: "Майлз Моралес", role: "Человек-паук из своей вселенной" },
        { name: "Гвен Стейси", role: "Паук-Гвен и важная союзница" },
        { name: "Мигель О’Хара", role: "Spider-Man 2099" },
        { name: "Питер Б. Паркер", role: "Опытный наставник" },
        { name: "Пятно", role: "Злодей, который становится опаснее, чем кажется" },
      ],
      players: [
        {
          id: "factorios-1219177",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1219177",
        },
      ],
    },
  {
      id: 6,
      kinopoiskId: 505898,
      slug: "avatar-the-way-of-water",
      title: "Аватар: Путь воды",
      originalTitle: "Avatar: The Way of Water",
      searchTitles: ["аватар", "аватар путь воды", "путь воды"],
      type: "Фильм",
      year: "2022",
      rating: 7.6,
      genres: ["Фантастика", "Приключения", "Экшен"],
      poster: "https://image.tmdb.org/t/p/w500/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg",
      description: "Возвращение на Пандору и история семьи Салли.",
      trailerUrl: "https://www.youtube.com/embed/6AvFHlKS6OE",
      longDescription:
        "«Аватар: Путь воды» — фильм 2022 года в жанрах Фантастика, Приключения, Экшен, где возвращение на Пандору и история семьи Салли. Джейк Салли и Нейтири строят семью на Пандоре, но старая угроза снова находит их. История уходит к океаническим кланам, где героям приходится учиться новым правилам выживания и защищать близких. Работа James Cameron и команды 20th Century Studios, Lightstorm чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2022" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "192 мин" },
        { label: "Бюджет", value: "$350–460 млн" },
        { label: "Студия", value: "20th Century Studios, Lightstorm" },
        { label: "Режиссёр", value: "James Cameron" },
        { label: "Мир", value: "Пандора" },
      ],
      cast: [
        { name: "Sam Worthington", role: "Джейк Салли" },
        { name: "Zoe Saldaña", role: "Нейтири" },
        { name: "Sigourney Weaver", role: "Кири" },
        { name: "Britain Dalton", role: "Ло’ак" },
        { name: "Kate Winslet", role: "Ронал" },
      ],
      players: [
        {
          id: "factorios-505898",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/505898",
        },
      ],
    },
  {
      id: 7,
      kinopoiskId: 915196,
      slug: "stranger-things",
      title: "Очень странные дела",
      originalTitle: "Stranger Things",
      searchTitles: ["очень странные дела", "странные дела", "странгер тингс"],
      type: "Сериал",
      year: "2016",
      rating: 8.7,
      genres: ["Фантастика", "Ужасы", "Драма"],
      poster: "https://image.tmdb.org/t/p/w500/49WJfeN0moxb9IPfGn8AIqMGskD.jpg",
      description: "Друзья, тайны маленького города и паранормальные события.",
      trailerUrl: "https://www.youtube.com/embed/b9EkMc79ZSU",
      longDescription:
        "«Очень странные дела» — сериал 2016 года в жанрах Фантастика, Ужасы, Драма, где друзья, тайны маленького города и паранормальные события. В маленьком городке Хокинс исчезновение мальчика открывает дверь к секретным экспериментам, параллельному миру и очень странным событиям. Сериал смешивает дружбу, подростковые приключения и фантастический хоррор без лишней мрачности. Работа The Duffer Brothers и команды Netflix, 21 Laps чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Сериал раскрывается постепенно: серии дают время привыкнуть к героям и заметить скрытые связи. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2016" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "42–150 мин / серия" },
        { label: "Бюджет", value: "до $30 млн за серию" },
        { label: "Студия", value: "Netflix, 21 Laps" },
        { label: "Создатели", value: "The Duffer Brothers" },
        { label: "Сезонов", value: "4+" },
      ],
      cast: [
        { name: "Милли Бобби Браун", role: "Одиннадцать" },
        { name: "Финн Вулфхард", role: "Майк Уилер" },
        { name: "Ноа Шнапп", role: "Уилл Байерс" },
        { name: "Гейтен Матараццо", role: "Дастин Хендерсон" },
        { name: "Дэвид Харбор", role: "Джим Хоппер" },
      ],
      players: [
        {
          id: "factorios-915196",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/915196",
        },
      ],
    },
  {
      id: 8,
      kinopoiskId: 839458,
      slug: "the-last-of-us",
      title: "Одни из нас",
      originalTitle: "The Last of Us",
      searchTitles: ["одни из нас", "последние из нас", "ласт оф ас"],
      type: "Сериал",
      year: "2023",
      rating: 8.7,
      genres: ["Драма", "Фантастика", "Приключения"],
      poster: "https://image.tmdb.org/t/p/w500/uKvVjHNqB5VmOrdxqAt2F7J78ED.jpg",
      description: "История выживания, доверия и опасного путешествия.",
      trailerUrl: "https://www.youtube.com/embed/uLtkt8BonwM",
      longDescription:
        "«Одни из нас» — сериал 2023 года в жанрах Драма, Фантастика, Приключения, где история выживания, доверия и опасного путешествия. После глобальной катастрофы контрабандист Джоэл должен провести девочку Элли через опасную страну. Сериал держится на напряжении, доверии и постепенной связи двух людей, которым приходится выживать вместе. Работа Craig Mazin, Neil Druckmann и команды HBO, PlayStation Productions чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Сериал раскрывается постепенно: серии дают время привыкнуть к героям и заметить скрытые связи. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2023" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США, Канада" },
        { label: "Длительность", value: "43–81 мин / серия" },
        { label: "Бюджет", value: "более $10 млн за серию" },
        { label: "Студия", value: "HBO, PlayStation Productions" },
        { label: "Создатели", value: "Craig Mazin, Neil Druckmann" },
        { label: "Основа", value: "Игра The Last of Us" },
      ],
      cast: [
        { name: "Pedro Pascal", role: "Джоэл" },
        { name: "Bella Ramsey", role: "Элли" },
        { name: "Anna Torv", role: "Тесс" },
        { name: "Gabriel Luna", role: "Томми" },
        { name: "Merle Dandridge", role: "Марлин" },
      ],
      players: [
        {
          id: "factorios-839458",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/839458",
        },
      ],
    },
  {
      id: 9,
      kinopoiskId: 4365427,
      slug: "wednesday",
      title: "Уэнсдей",
      originalTitle: "Wednesday",
      searchTitles: ["уэнсдей", "венсдей", "уенздей", "венздей", "среда"],
      type: "Сериал",
      year: "2022",
      rating: 8.1,
      genres: ["Комедия", "Мистика", "Фэнтези"],
      poster: "https://image.tmdb.org/t/p/w500/jeGtaMwGxPmQN5xM4ClnwPQcNQz.jpg",
      description: "Мрачная, ироничная история Уэнсдей Аддамс.",
      trailerUrl: "https://www.youtube.com/embed/Q73UhUTs6y0",
      longDescription:
        "«Уэнсдей» — сериал 2022 года в жанрах Комедия, Мистика, Фэнтези, где мрачная, ироничная история Уэнсдей Аддамс. Уэнсдей Аддамс поступает в академию Невермор и быстро оказывается в центре загадочного расследования. Её холодная логика, сарказм и странные видения превращают школьную историю в мистический детектив. Работа Alfred Gough, Miles Millar и команды Netflix, MGM Television чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Сериал раскрывается постепенно: серии дают время привыкнуть к героям и заметить скрытые связи. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2022" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "47–59 мин / серия" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Netflix, MGM Television" },
        { label: "Создатели", value: "Alfred Gough, Miles Millar" },
        { label: "Настроение", value: "Мистика, чёрный юмор, детектив" },
      ],
      cast: [
        { name: "Jenna Ortega", role: "Уэнсдей Аддамс" },
        { name: "Emma Myers", role: "Энид Синклер" },
        { name: "Catherine Zeta-Jones", role: "Мортиша Аддамс" },
        { name: "Luis Guzmán", role: "Гомес Аддамс" },
        { name: "Gwendoline Christie", role: "Лариса Уимс" },
      ],
      players: [
        {
          id: "factorios-4365427",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/4365427",
        },
      ],
    },
  {
      id: 10,
      kinopoiskId: 1316601,
      slug: "house-of-the-dragon",
      title: "Дом дракона",
      originalTitle: "House of the Dragon",
      searchTitles: ["дом дракона", "драконы", "таргариены", "дом таргариенов"],
      type: "Сериал",
      year: "2022",
      rating: 8.4,
      genres: ["Фэнтези", "Драма", "Приключения"],
      poster: "https://image.tmdb.org/t/p/w500/7QMsOTMUswlwxJP0rTTZfmz2tX2.jpg",
      description: "История дома Таргариенов до событий Игры престолов.",
      trailerUrl: "https://www.youtube.com/embed/DotnJ7tTA34",
      longDescription:
        "«Дом дракона» — сериал 2022 года в жанрах Фэнтези, Драма, Приключения, где история дома Таргариенов до событий Игры престолов. История дома Таргариенов показывает борьбу за наследование Железного трона задолго до событий Игры престолов. Семейные союзы, амбиции и драконы постепенно превращают дворцовый конфликт в большую войну. Работа Ryan Condal, George R. R. Martin и команды HBO чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Сериал раскрывается постепенно: серии дают время привыкнуть к героям и заметить скрытые связи. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2022" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США, Великобритания" },
        { label: "Длительность", value: "54–68 мин / серия" },
        { label: "Бюджет", value: "до $20 млн за серию" },
        { label: "Студия", value: "HBO" },
        { label: "Создатели", value: "Ryan Condal, George R. R. Martin" },
        { label: "Мир", value: "Вестерос" },
      ],
      cast: [
        { name: "Emma D’Arcy", role: "Рейнира Таргариен" },
        { name: "Matt Smith", role: "Деймон Таргариен" },
        { name: "Olivia Cooke", role: "Алисента Хайтауэр" },
        { name: "Paddy Considine", role: "Визерис I" },
        { name: "Ewan Mitchell", role: "Эймонд Таргариен" },
      ],
      players: [
        {
          id: "factorios-1316601",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1316601",
        },
      ],
    },
  {
      id: 11,
      kinopoiskId: 404900,
      slug: "breaking-bad",
      title: "Во все тяжкие",
      originalTitle: "Breaking Bad",
      searchTitles: ["во все тяжкие", "брейкинг бэд", "брейкинг бед"],
      type: "Сериал",
      year: "2008",
      rating: 9.5,
      genres: ["Драма", "Криминал", "Триллер"],
      poster: "https://image.tmdb.org/t/p/w500/3xnWaLQjelJDDF7LT1WBo6f4BRe.jpg",
      description: "Один из самых известных криминальных сериалов.",
      trailerUrl: "https://www.youtube.com/embed/HhesaQXLuRY",
      longDescription:
        "«Во все тяжкие» — сериал 2008 года в жанрах Драма, Криминал, Триллер, где один из самых известных криминальных сериалов. Учитель химии Уолтер Уайт получает тяжёлый диагноз и решает заработать для семьи незаконным способом. Его путь от отчаяния к власти становится одной из самых напряжённых криминальных историй на телевидении. Работа Vince Gilligan и команды AMC, Sony Pictures Television чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Сериал раскрывается постепенно: серии дают время привыкнуть к героям и заметить скрытые связи. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2008" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "47 мин / серия" },
        { label: "Бюджет", value: "около $3 млн за серию" },
        { label: "Студия", value: "AMC, Sony Pictures Television" },
        { label: "Создатель", value: "Vince Gilligan" },
        { label: "Сезонов", value: "5" },
      ],
      cast: [
        { name: "Bryan Cranston", role: "Уолтер Уайт" },
        { name: "Aaron Paul", role: "Джесси Пинкман" },
        { name: "Anna Gunn", role: "Скайлер Уайт" },
        { name: "Dean Norris", role: "Хэнк Шрейдер" },
        { name: "Bob Odenkirk", role: "Сол Гудман" },
      ],
      players: [
        {
          id: "factorios-404900",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/404900",
        },
      ],
    },
  {
      id: 12,
      kinopoiskId: 464963,
      slug: "game-of-thrones",
      title: "Игра престолов",
      originalTitle: "Game of Thrones",
      searchTitles: ["игра престолов", "престолы", "гейм оф тронс"],
      type: "Сериал",
      year: "2011",
      rating: 9.2,
      genres: ["Фэнтези", "Драма", "Приключения"],
      poster: "https://image.tmdb.org/t/p/w500/1XS1oqL89opfnbLl8WnZY1O1uJx.jpg",
      description: "Борьба за власть, интриги и великие дома Вестероса.",
      trailerUrl: "https://www.youtube.com/embed/KYKpcWuZDYs",
      longDescription:
        "«Игра престолов» — сериал 2011 года в жанрах Фэнтези, Драма, Приключения, где борьба за власть, интриги и великие дома Вестероса. Вестерос живёт интригами, войнами и борьбой великих домов за Железный трон. Пока люди делят власть, за Стеной поднимается угроза, перед которой политические амбиции выглядят подозрительно мелкими. Работа David Benioff, D. B. Weiss и команды HBO чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Сериал раскрывается постепенно: серии дают время привыкнуть к героям и заметить скрытые связи. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение, конфликт. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2011" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США, Великобритания" },
        { label: "Длительность", value: "50–80 мин / серия" },
        { label: "Бюджет", value: "$6–15 млн за серию" },
        { label: "Студия", value: "HBO" },
        { label: "Создатели", value: "David Benioff, D. B. Weiss" },
        { label: "Сезонов", value: "8" },
      ],
      cast: [
        { name: "Kit Harington", role: "Джон Сноу" },
        { name: "Emilia Clarke", role: "Дейенерис Таргариен" },
        { name: "Peter Dinklage", role: "Тирион Ланнистер" },
        { name: "Maisie Williams", role: "Арья Старк" },
        { name: "Lena Headey", role: "Серсея Ланнистер" },
      ],
      players: [
        {
          id: "factorios-464963",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/464963",
        },
      ],
    },
  {
      id: 13,
      kinopoiskId: 749374,
      slug: "attack-on-titan",
      title: "Атака титанов",
      originalTitle: "Attack on Titan",
      searchTitles: ["атака титанов", "атака титан", "титаны", "шингеки"],
      type: "Аниме",
      year: "2013",
      rating: 9.1,
      genres: ["Аниме", "Экшен", "Драма"],
      poster: getTmdbPoster({
        tmdbId: 1429,
        title: "Атака титанов",
        originalTitle: "Attack on Titan",
        year: "2013",
        type: "series",
      }),
      posterFallbacks: ["https://image.tmdb.org/t/p/w500/hTP1DtLGFamjfu8WqjnuQdP1n4i.jpg"],
      description: "Люди против гигантов и большая тайна за стенами.",
      trailerUrl: "https://www.youtube.com/embed/3xNH23QkNpk",
      longDescription:
        "«Атака титанов» — аниме 2013 года в жанрах Аниме, Экшен, Драма, где люди против гигантов и большая тайна за стенами. Люди живут за огромными стенами, защищаясь от титанов. Когда стены перестают быть гарантией безопасности, Эрен, Микаса и Армин оказываются в истории, где враг не всегда так прост, как кажется. Работа Hajime Isayama и команды Wit Studio, MAPPA чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Аниме держится на эмоциях, мире и развитии персонажей, а не только на динамичных сценах. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение, конфликт, темп и те детали, из-за которых материал запоминается после просмотра.",
      facts: [
        { label: "Год", value: "2013" },
        { label: "Тип", value: "Аниме" },
        { label: "Страна", value: "Япония" },
        { label: "Длительность", value: "24 мин / серия" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Wit Studio, MAPPA" },
        { label: "Автор", value: "Hajime Isayama" },
        { label: "Оригинал", value: "Манга Shingeki no Kyojin" },
      ],
      cast: [
        { name: "Эрен Йегер", role: "Солдат, одержимый свободой" },
        { name: "Микаса Аккерман", role: "Защитница и один из сильнейших бойцов" },
        { name: "Армин Арлерт", role: "Стратег и голос разума" },
        { name: "Леви Аккерман", role: "Капитан разведкорпуса" },
        { name: "Райнер Браун", role: "Воин с тяжёлой тайной" },
      ],
      players: [
        { id: "player-1", name: "Плеер 1", embedUrl: "" },
        { id: "player-2", name: "Плеер 2", embedUrl: "" },
        { id: "player-3", name: "Плеер 3", embedUrl: "" },
      ],
    },
  {
      id: 14,
      kinopoiskId: 1220920,
      slug: "demon-slayer",
      title: "Истребитель демонов",
      originalTitle: "Demon Slayer",
      searchTitles: [
        "клинок рассекающий демонов",
        "клинок",
        "демон слейер",
        "истребитель демонов",
      ],
      type: "Аниме",
      year: "2019",
      rating: 8.6,
      genres: ["Аниме", "Экшен", "Фэнтези"],
      poster: "https://image.tmdb.org/t/p/w500/1IMWXXlET7jWahhPbXcBwZxgyqe.jpg",
      description: "История Танджиро и его пути охотника на демонов.",
      trailerUrl: "https://www.youtube.com/embed/VQGCKyvzIM4",
      longDescription:
        "«Истребитель демонов» — аниме 2019 года в жанрах Аниме, Экшен, Фэнтези, где история Танджиро и его пути охотника на демонов. Танджиро Камадо теряет семью и отправляется в путь, чтобы помочь сестре Нэдзуко. Аниме сочетает красивую боевую постановку, семейную мотивацию и историю о стойкости даже перед невозможным. Работа Koyoharu Gotouge и команды ufotable чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Аниме держится на эмоциях, мире и развитии персонажей, а не только на динамичных сценах. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение, конфликт, темп и те детали, из-за которых материал запоминается после просмотра.",
      facts: [
        { label: "Год", value: "2019" },
        { label: "Тип", value: "Аниме" },
        { label: "Страна", value: "Япония" },
        { label: "Длительность", value: "23 мин / серия" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "ufotable" },
        { label: "Автор", value: "Koyoharu Gotouge" },
        { label: "Оригинал", value: "Манга Kimetsu no Yaiba" },
      ],
      cast: [
        { name: "Танджиро Камадо", role: "Охотник на демонов с добрым сердцем" },
        { name: "Нэдзуко Камадо", role: "Сестра Танджиро" },
        { name: "Зеницу Агацума", role: "Тревожный, но талантливый мечник" },
        { name: "Иносукэ Хашибира", role: "Дикий и прямолинейный боец" },
        { name: "Гию Томиока", role: "Хашира воды" },
      ],
      players: [
        { id: "player-1", name: "Плеер 1", embedUrl: "" },
        { id: "player-2", name: "Плеер 2", embedUrl: "" },
        { id: "player-3", name: "Плеер 3", embedUrl: "" },
      ],
    },
  {
      id: 15,
      kinopoiskId: 958722,
      slug: "your-name",
      title: "Твоё имя",
      originalTitle: "Your Name",
      searchTitles: ["твое имя", "твоё имя", "киминокава", "кими но на ва"],
      type: "Аниме",
      year: "2016",
      rating: 8.4,
      genres: ["Аниме", "Романтика", "Драма"],
      poster: "https://image.tmdb.org/t/p/w500/q719jXXEzOoYaps6babgKnONONX.jpg",
      description: "Красивая история о связи двух людей через расстояние.",
      trailerUrl: "https://www.youtube.com/embed/xU47nhruN-Q",
      longDescription:
        "«Твоё имя» — аниме 2016 года в жанрах Аниме, Романтика, Драма, где красивая история о связи двух людей через расстояние. Мицуха и Таки неожиданно начинают обмениваться телами, хотя живут в разных местах и почти не знают друг друга. Из лёгкой фантазии история постепенно превращается в эмоциональную драму о времени, памяти и связи. Работа Makoto Shinkai и команды CoMix Wave Films чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Аниме держится на эмоциях, мире и развитии персонажей, а не только на динамичных сценах. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение, конфликт. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2016" },
        { label: "Тип", value: "Аниме" },
        { label: "Страна", value: "Япония" },
        { label: "Длительность", value: "107 мин" },
        { label: "Бюджет", value: "около $3,7 млн" },
        { label: "Студия", value: "CoMix Wave Films" },
        { label: "Режиссёр", value: "Makoto Shinkai" },
        { label: "Формат", value: "Полнометражное аниме" },
      ],
      cast: [
        { name: "Мицуха Миямидзу", role: "Девушка из горного городка" },
        { name: "Таки Татибана", role: "Школьник из Токио" },
        { name: "Тэсси", role: "Друг Мицухи" },
        { name: "Саяка", role: "Подруга Мицухи" },
        { name: "Хитоha Миямидзу", role: "Бабушка Мицухи" },
      ],
      players: [
        { id: "player-1", name: "Плеер 1", embedUrl: "" },
        { id: "player-2", name: "Плеер 2", embedUrl: "" },
        { id: "player-3", name: "Плеер 3", embedUrl: "" },
      ],
    },
  {
      id: 16,
      kinopoiskId: 283290,
      slug: "naruto",
      title: "Наруто",
      originalTitle: "Naruto",
      searchTitles: ["наруто", "наруто узумаки", "uzumaki naruto"],
      type: "Аниме",
      year: "2002",
      rating: 8.4,
      genres: ["Аниме", "Экшен", "Приключения"],
      poster: "https://image.tmdb.org/t/p/w500/vauCEnR7CiyBDzRCeElKkCaXIYu.jpg",
      description: "История юного ниндзя, который мечтает стать Хокаге.",
      trailerUrl: "https://www.youtube.com/embed/-G9BqkgZXRA",
      longDescription:
        "«Наруто» — аниме 2002 года в жанрах Аниме, Экшен, Приключения, где история юного ниндзя, который мечтает стать Хокаге. Наруто Узумаки мечтает стать Хокаге, хотя многие в деревне относятся к нему настороженно. Это длинная история о дружбе, упорстве, командной работе и желании доказать, что прошлое не обязано определять будущее. Работа Masashi Kishimoto и команды Pierrot чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Аниме держится на эмоциях, мире и развитии персонажей, а не только на динамичных сценах. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение, конфликт, темп и те детали, которые делают историю заметной в своей категории.",
      facts: [
        { label: "Год", value: "2002" },
        { label: "Тип", value: "Аниме" },
        { label: "Страна", value: "Япония" },
        { label: "Длительность", value: "23 мин / серия" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Pierrot" },
        { label: "Автор", value: "Masashi Kishimoto" },
        { label: "Оригинал", value: "Манга Naruto" },
      ],
      cast: [
        { name: "Наруто Узумаки", role: "Ниндзя, который хочет стать Хокаге" },
        { name: "Саске Учиха", role: "Талантливый соперник и товарищ" },
        { name: "Сакура Харуно", role: "Участница команды 7" },
        { name: "Какаши Хатаке", role: "Наставник команды 7" },
        { name: "Ирука Умино", role: "Первый учитель, поверивший в Наруто" },
      ],
      players: [
        { id: "player-1", name: "Плеер 1", embedUrl: "" },
        { id: "player-2", name: "Плеер 2", embedUrl: "" },
        { id: "player-3", name: "Плеер 3", embedUrl: "" },
      ],
    },
  {
      id: 17,
      kinopoiskId: 1007472,
      slug: "planet-earth-ii",
      title: "Планета Земля 2",
      originalTitle: "Planet Earth II",
      searchTitles: ["планета земля", "планета земля 2", "земля 2", "природа"],
      type: "Документальный",
      year: "2016",
      rating: 9.5,
      genres: ["Документальный", "Природа"],
      poster: "https://image.tmdb.org/t/p/w500/5maYKYzWpE68ycxGh1luu4P2LOS.jpg",
      description: "Документальный проект о природе и жизни на Земле.",
      trailerUrl: "https://www.youtube.com/embed/c8aFcHFu8QM",
      longDescription:
        "«Планета Земля 2» — документальный проект 2016 года в жанрах Документальный, Природа, где документальный проект о природе и жизни на Земле. Документальный проект показывает разные уголки Земли с редкой близостью к природе. Каждая серия раскрывает экосистемы, где жизнь выглядит как самый дорогой спецэффект — только без CGI и с очень терпеливыми операторами. Работа David Attenborough и команды BBC Natural History Unit чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Документальный формат работает на погружение и помогает внимательнее смотреть на реальные темы. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2016" },
        { label: "Тип", value: "Документальный" },
        { label: "Страна", value: "Великобритания" },
        { label: "Длительность", value: "50 мин / серия" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "BBC Natural History Unit" },
        { label: "Рассказчик", value: "David Attenborough" },
        { label: "Серий", value: "6" },
      ],
      cast: [
        { name: "David Attenborough", role: "Рассказчик" },
        { name: "Команда BBC Earth", role: "Съёмочная группа" },
        { name: "Дикая природа", role: "Главный герой проекта" },
        { name: "Острова, горы и джунгли", role: "Ключевые локации" },
        { name: "Планета Земля", role: "Общий фокус истории" },
      ],
      players: [
        {
          id: "factorios-1007472",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1007472",
        },
      ],
    },
  {
      id: 18,
      kinopoiskId: 1235081,
      slug: "our-planet",
      title: "Наша планета",
      originalTitle: "Our Planet",
      searchTitles: ["наша планета", "планета", "природа"],
      type: "Документальный",
      year: "2019",
      rating: 9.2,
      genres: ["Документальный", "Природа"],
      poster: "https://image.tmdb.org/t/p/w500/wRSnArnQBmeUYb5GWDU595bGsBr.jpg",
      description: "Красивый документальный сериал о планете и её экосистемах.",
      trailerUrl: "https://www.youtube.com/embed/0_pu6A5YG1o",
      longDescription:
        "«Наша планета» — документальный проект 2019 года в жанрах Документальный, Природа, где красивый документальный сериал о планете и её экосистемах. Сериал исследует красоту и хрупкость природного мира, показывая разные экосистемы планеты. Это документальное путешествие о животных, климате и будущем, которое зависит от решений людей. Работа David Attenborough и команды Silverback Films, Netflix чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Документальный формат работает на погружение и помогает внимательнее смотреть на реальные темы. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2019" },
        { label: "Тип", value: "Документальный" },
        { label: "Страна", value: "Великобритания" },
        { label: "Длительность", value: "48–53 мин / серия" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Silverback Films, Netflix" },
        { label: "Рассказчик", value: "David Attenborough" },
        { label: "Серий", value: "8" },
      ],
      cast: [
        { name: "David Attenborough", role: "Рассказчик" },
        { name: "Silverback Films", role: "Съёмочная команда" },
        { name: "Океаны, леса и ледники", role: "Ключевые миры проекта" },
        { name: "Дикие животные", role: "Главные участники" },
        { name: "Земля", role: "Главная тема сериала" },
      ],
      players: [
        {
          id: "factorios-1235081",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1235081",
        },
      ],
    },
  {
      id: 19,
      kinopoiskId: 1337788,
      slug: "the-social-dilemma",
      title: "Социальная дилемма",
      originalTitle: "The Social Dilemma",
      searchTitles: [
        "социальная дилемма",
        "соц дилемма",
        "социальные сети",
        "дилемма",
      ],
      type: "Документальный",
      year: "2020",
      rating: 7.6,
      genres: ["Документальный", "Технологии"],
      poster: "https://upload.wikimedia.org/wikipedia/en/2/27/Social_dilemma_xlg.jpg",
      description: "Документальная история о влиянии соцсетей на людей.",
      trailerUrl: "https://www.youtube.com/embed/uaaC57tcci0",
      longDescription:
        "«Социальная дилемма» — документальный проект 2020 года в жанрах Документальный, Технологии, где документальная история о влиянии соцсетей на людей. Документальный фильм разбирает, как социальные платформы удерживают внимание и влияют на поведение пользователей. Это не страшилка про технологии, а повод внимательнее смотреть на алгоритмы, которые каждый день смотрят на нас в ответ. Работа Jeff Orlowski и команды Exposure Labs, Netflix чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Документальный формат работает на погружение и помогает внимательнее смотреть на реальные темы. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2020" },
        { label: "Тип", value: "Документальный" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "94 мин" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Exposure Labs, Netflix" },
        { label: "Режиссёр", value: "Jeff Orlowski" },
        { label: "Темы", value: "Соцсети, алгоритмы, внимание" },
      ],
      cast: [
        { name: "Tristan Harris", role: "Бывший специалист Google и эксперт по этике технологий" },
        { name: "Jaron Lanier", role: "Технологический эксперт и автор" },
        { name: "Shoshana Zuboff", role: "Исследовательница цифровой экономики" },
        { name: "Tim Kendall", role: "Бывший руководитель Pinterest" },
        { name: "Эксперты индустрии", role: "Участники интервью" },
      ],
      players: [
        {
          id: "factorios-1337788",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1337788",
        },
      ],
    },
  {
      id: 20,
      kinopoiskId: 447301,
      slug: "inception",
      title: "Начало",
      originalTitle: "Inception",
      searchTitles: ["начало", "инсепшн", "сны", "сон"],
      type: "Фильм",
      year: "2010",
      rating: 8.8,
      genres: ["Фантастика", "Экшен", "Триллер"],
      poster: "https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg",
      description:
        "Команда специалистов проникает в сны, где идея может стать оружием.",
      trailerUrl: "https://www.youtube.com/embed/YoHD9XEInc0",
      longDescription:
        "«Начало» — фильм 2010 года в жанрах Фантастика, Экшен, Триллер, где команда специалистов проникает в сны, где идея может стать оружием. Дом Кобб и его команда умеют проникать в сны и извлекать идеи. Новая миссия требует сделать обратное — внедрить мысль так глубоко, чтобы человек считал её собственной. Работа Christopher Nolan и команды Warner Bros., Legendary, Syncopy чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2010" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Великобритания" },
        { label: "Длительность", value: "148 мин" },
        { label: "Бюджет", value: "$160 млн" },
        { label: "Студия", value: "Warner Bros., Legendary, Syncopy" },
        { label: "Режиссёр", value: "Christopher Nolan" },
        { label: "Темы", value: "Сны, память, вина" },
      ],
      cast: [
        { name: "Leonardo DiCaprio", role: "Дом Кобб" },
        { name: "Joseph Gordon-Levitt", role: "Артур" },
        { name: "Elliot Page", role: "Ариадна" },
        { name: "Tom Hardy", role: "Имс" },
        { name: "Marion Cotillard", role: "Мол" },
      ],
      players: [
        {
          id: "factorios-447301",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/447301",
        },
      ],
    },
  {
      id: 21,
      kinopoiskId: 301,
      slug: "the-matrix",
      title: "Матрица",
      originalTitle: "The Matrix",
      searchTitles: ["матрица", "нео", "морфеус"],
      type: "Фильм",
      year: "1999",
      rating: 8.7,
      genres: ["Фантастика", "Экшен"],
      poster: "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg",
      description:
        "Киберпанк-классика о реальности, свободе выбора и красной таблетке.",
      trailerUrl: "https://www.youtube.com/embed/vKQi3bBA1y8",
      longDescription:
        "«Матрица» — фильм 1999 года в жанрах Фантастика, Экшен, где киберпанк-классика о реальности, свободе выбора и красной таблетке. Хакер Нео узнаёт, что привычная реальность может быть всего лишь системой контроля. Вместе с Морфеусом и Тринити он выходит за пределы иллюзии и сталкивается с вопросом выбора. Работа Lana Wachowski, Lilly Wachowski и команды Warner Bros. чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "1999" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Австралия" },
        { label: "Длительность", value: "136 мин" },
        { label: "Бюджет", value: "$63 млн" },
        { label: "Студия", value: "Warner Bros." },
        { label: "Режиссёры", value: "Lana Wachowski, Lilly Wachowski" },
        { label: "Темы", value: "Свобода, реальность, выбор" },
      ],
      cast: [
        { name: "Keanu Reeves", role: "Нео" },
        { name: "Carrie-Anne Moss", role: "Тринити" },
        { name: "Laurence Fishburne", role: "Морфеус" },
        { name: "Hugo Weaving", role: "Агент Смит" },
        { name: "Gloria Foster", role: "Пифия" },
      ],
      players: [
        {
          id: "factorios-301",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/301",
        },
      ],
    },
  {
      id: 22,
      kinopoiskId: 453406,
      slug: "mad-max-fury-road",
      title: "Безумный Макс: Дорога ярости",
      originalTitle: "Mad Max: Fury Road",
      searchTitles: ["безумный макс", "дорога ярости", "макс"],
      type: "Фильм",
      year: "2015",
      rating: 8.1,
      genres: ["Экшен", "Приключения", "Фантастика"],
      poster: "https://image.tmdb.org/t/p/w500/hA2ple9q4qnwxp3hKVNhroipsir.jpg",
      description: "Пыль, скорость и безумная погоня через пустоши.",
      trailerUrl: "https://www.youtube.com/embed/hEJnMQG9ev8",
      longDescription:
        "«Безумный Макс: Дорога ярости» — фильм 2015 года в жанрах Экшен, Приключения, Фантастика, где пыль, скорость и безумная погоня через пустоши. В постапокалиптической пустоши Макс оказывается втянут в побег Фуриосы и её союзниц. Фильм почти не отпускает педаль газа и превращает дорогу в историю о свободе и выживании. Работа George Miller и команды Warner Bros., Village Roadshow чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2015" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "Австралия, США" },
        { label: "Длительность", value: "120 мин" },
        { label: "Бюджет", value: "$150 млн" },
        { label: "Студия", value: "Warner Bros., Village Roadshow" },
        { label: "Режиссёр", value: "George Miller" },
        { label: "Настроение", value: "Скорость, пыль, адреналин" },
      ],
      cast: [
        { name: "Tom Hardy", role: "Макс Рокатански" },
        { name: "Charlize Theron", role: "Императрица Фуриоса" },
        { name: "Nicholas Hoult", role: "Накс" },
        { name: "Hugh Keays-Byrne", role: "Несмертный Джо" },
        { name: "Zoë Kravitz", role: "Тост" },
      ],
      players: [
        {
          id: "factorios-453406",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/453406",
        },
      ],
    },
  {
      id: 23,
      kinopoiskId: 111543,
      slug: "the-dark-knight",
      title: "Тёмный рыцарь",
      originalTitle: "The Dark Knight",
      searchTitles: ["темный рыцарь", "тёмный рыцарь", "джокер", "бетмен"],
      type: "Фильм",
      year: "2008",
      rating: 9.0,
      genres: ["Экшен", "Криминал", "Драма"],
      poster: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg",
      description:
        "Готэм сталкивается с хаосом, который невозможно просто арестовать.",
      trailerUrl: "https://www.youtube.com/embed/EXeTwQWrcwY",
      longDescription:
        "«Тёмный рыцарь» — фильм 2008 года в жанрах Экшен, Криминал, Драма, где готэм сталкивается с хаосом, который невозможно просто арестовать. Бэтмен, Гордон и Харви Дент пытаются очистить Готэм от преступности, но Джокер превращает город в проверку моральных границ. Это супергеройский фильм, который играет по правилам криминальной драмы. Работа Christopher Nolan и команды Warner Bros., Legendary, DC чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2008" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Великобритания" },
        { label: "Длительность", value: "152 мин" },
        { label: "Бюджет", value: "$185 млн" },
        { label: "Студия", value: "Warner Bros., Legendary, DC" },
        { label: "Режиссёр", value: "Christopher Nolan" },
        { label: "Настроение", value: "Криминальная драма, хаос, выбор" },
      ],
      cast: [
        { name: "Christian Bale", role: "Брюс Уэйн / Бэтмен" },
        { name: "Heath Ledger", role: "Джокер" },
        { name: "Aaron Eckhart", role: "Харви Дент" },
        { name: "Gary Oldman", role: "Джеймс Гордон" },
        { name: "Michael Caine", role: "Альфред" },
      ],
      players: [
        {
          id: "factorios-111543",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/111543",
        },
      ],
    },
  {
      id: 24,
      kinopoiskId: 589290,
      slug: "blade-runner-2049",
      title: "Бегущий по лезвию 2049",
      originalTitle: "Blade Runner 2049",
      searchTitles: ["бегущий по лезвию", "бегущий по лезвию 2049", "репликанты"],
      type: "Фильм",
      year: "2017",
      rating: 8.0,
      genres: ["Фантастика", "Драма", "Триллер"],
      poster: "https://image.tmdb.org/t/p/w500/gajva2L0rPYkEWjzgFlBXCAVBE5.jpg",
      description:
        "Медленная, стильная и холодная фантастика о памяти и личности.",
      trailerUrl: "https://www.youtube.com/embed/gCcx85zbxz4",
      longDescription:
        "«Бегущий по лезвию 2049» — фильм 2017 года в жанрах Фантастика, Драма, Триллер, где медленная, стильная и холодная фантастика о памяти и личности. Офицер K раскрывает тайну, способную изменить баланс между людьми и репликантами. Его расследование приводит к Рику Декарду и вопросу, что вообще делает личность настоящей. Работа Denis Villeneuve и команды Warner Bros., Alcon Entertainment чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2017" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Канада, Венгрия" },
        { label: "Длительность", value: "164 мин" },
        { label: "Бюджет", value: "$150–185 млн" },
        { label: "Студия", value: "Warner Bros., Alcon Entertainment" },
        { label: "Режиссёр", value: "Denis Villeneuve" },
        { label: "Настроение", value: "Неонуар, меланхолия, киберпанк" },
      ],
      cast: [
        { name: "Ryan Gosling", role: "K" },
        { name: "Harrison Ford", role: "Рик Декард" },
        { name: "Ana de Armas", role: "Джой" },
        { name: "Sylvia Hoeks", role: "Лав" },
        { name: "Jared Leto", role: "Ниандер Уоллес" },
      ],
      players: [
        {
          id: "factorios-589290",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/589290",
        },
      ],
    },
  {
      id: 25,
      kinopoiskId: 572032,
      slug: "top-gun-maverick",
      title: "Топ Ган: Мэверик",
      originalTitle: "Top Gun: Maverick",
      searchTitles: ["топ ган", "мэверик", "маверик", "лучший стрелок"],
      type: "Фильм",
      year: "2022",
      rating: 8.2,
      genres: ["Экшен", "Драма"],
      poster: "https://image.tmdb.org/t/p/w500/62HCnUTziyWcpDaBO2i1DX17ljH.jpg",
      description: "Возвращение легендарного пилота и зрелищные воздушные сцены.",
      trailerUrl: "https://www.youtube.com/embed/giXco2jaZ_4",
      longDescription:
        "«Топ Ган: Мэверик» — фильм 2022 года в жанрах Экшен, Драма, где возвращение легендарного пилота и зрелищные воздушные сцены. Пит Митчелл возвращается в программу Top Gun, чтобы подготовить молодых пилотов к опасной миссии. Старые решения, новые ученики и полёты на пределе делают историю одновременно зрелищной и личной. Работа Joseph Kosinski и команды Paramount Pictures, Skydance чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2022" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "130 мин" },
        { label: "Бюджет", value: "$170–177 млн" },
        { label: "Студия", value: "Paramount Pictures, Skydance" },
        { label: "Режиссёр", value: "Joseph Kosinski" },
        { label: "Темы", value: "Наставничество, риск, команда" },
      ],
      cast: [
        { name: "Tom Cruise", role: "Пит «Мэверик» Митчелл" },
        { name: "Miles Teller", role: "Брэдли «Рустер» Брэдшоу" },
        { name: "Jennifer Connelly", role: "Пенни Бенджамин" },
        { name: "Glen Powell", role: "Джейк «Хэнгман» Серезин" },
        { name: "Val Kilmer", role: "Том «Айсмен» Казански" },
      ],
      players: [
        {
          id: "factorios-572032",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/572032",
        },
      ],
    },
  {
      id: 26,
      kinopoiskId: 718811,
      slug: "arrival",
      title: "Прибытие",
      originalTitle: "Arrival",
      searchTitles: ["прибытие", "arrival", "пришельцы", "язык пришельцев"],
      type: "Фильм",
      year: "2016",
      rating: 7.9,
      genres: ["Фантастика", "Драма"],
      poster: "https://image.tmdb.org/t/p/w500/x2FJsf1ElAgr63Y3PNPtJrcmpoe.jpg",
      description:
        "Контакт с внеземной цивилизацией превращается в загадку языка и времени.",
      trailerUrl: "https://www.youtube.com/embed/tFMo3UJ4B4g",
      longDescription:
        "«Прибытие» — фильм 2016 года в жанрах Фантастика, Драма, где контакт с внеземной цивилизацией превращается в загадку языка и времени. Когда на Землю прибывают загадочные корабли, лингвист Луиза Бэнкс пытается понять язык пришельцев. Чем глубже она погружается в коммуникацию, тем сильнее меняется её восприятие времени и выбора. Работа Denis Villeneuve и команды Paramount Pictures, FilmNation чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2016" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Канада" },
        { label: "Длительность", value: "116 мин" },
        { label: "Бюджет", value: "$47 млн" },
        { label: "Студия", value: "Paramount Pictures, FilmNation" },
        { label: "Режиссёр", value: "Denis Villeneuve" },
        { label: "Темы", value: "Язык, время, контакт" },
      ],
      cast: [
        { name: "Amy Adams", role: "Луиза Бэнкс" },
        { name: "Jeremy Renner", role: "Иэн Доннелли" },
        { name: "Forest Whitaker", role: "Полковник Вебер" },
        { name: "Michael Stuhlbarg", role: "Агент Халперн" },
        { name: "Эбботт и Костелло", role: "Пришельцы-гептаподы" },
      ],
      players: [
        {
          id: "factorios-718811",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/718811",
        },
      ],
    },
  {
      id: 27,
      kinopoiskId: 1236063,
      slug: "tenet",
      title: "Довод",
      originalTitle: "Tenet",
      searchTitles: ["довод", "tenet", "время", "инверсия"],
      type: "Фильм",
      year: "2020",
      rating: 7.3,
      genres: ["Фантастика", "Экшен", "Триллер"],
      poster: "https://image.tmdb.org/t/p/w500/aCIFMriQh8rvhxpN1IWGgvH0Tlg.jpg",
      description:
        "Шпионский экшен, где время работает не так, как привык зритель.",
      trailerUrl: "https://www.youtube.com/embed/LdOM0x0XDMo",
      longDescription:
        "«Довод» — фильм 2020 года в жанрах Фантастика, Экшен, Триллер, где шпионский экшен, где время работает не так, как привык зритель. Безымянный агент попадает в мир инверсии времени, где действия могут идти вперёд и назад одновременно. Миссия превращается в шпионскую головоломку, где причина и следствие не всегда стоят в привычном порядке. Работа Christopher Nolan и команды Warner Bros., Syncopy чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2020" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Великобритания" },
        { label: "Длительность", value: "150 мин" },
        { label: "Бюджет", value: "$200 млн" },
        { label: "Студия", value: "Warner Bros., Syncopy" },
        { label: "Режиссёр", value: "Christopher Nolan" },
        { label: "Темы", value: "Время, шпионаж, инверсия" },
      ],
      cast: [
        { name: "John David Washington", role: "Протагонист" },
        { name: "Robert Pattinson", role: "Нил" },
        { name: "Elizabeth Debicki", role: "Кэт" },
        { name: "Kenneth Branagh", role: "Андрей Сатор" },
        { name: "Dimple Kapadia", role: "Прия" },
      ],
      players: [
        {
          id: "factorios-1236063",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1236063",
        },
      ],
    },
  {
      id: 28,
      kinopoiskId: 505851,
      slug: "edge-of-tomorrow",
      title: "Грань будущего",
      originalTitle: "Edge of Tomorrow",
      searchTitles: [
        "грань будущего",
        "edge of tomorrow",
        "день сурка",
        "будущее",
      ],
      type: "Фильм",
      year: "2014",
      rating: 7.9,
      genres: ["Фантастика", "Экшен"],
      poster: "https://image.tmdb.org/t/p/w500/uUHvlkLavotfGsNtosDy8ShsIYF.jpg",
      description:
        "Солдат снова и снова проживает один день, чтобы найти путь к победе.",
      trailerUrl: "https://www.youtube.com/embed/yUmSVcttXnI",
      longDescription:
        "«Грань будущего» — фильм 2014 года в жанрах Фантастика, Экшен, где солдат снова и снова проживает один день, чтобы найти путь к победе. Майор Кейдж попадает во временную петлю и снова переживает один и тот же день битвы. Каждая попытка становится тренировкой, а союз с Ритой Вратаски — шансом найти слабое место противника. Работа Doug Liman и команды Warner Bros., Village Roadshow чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2014" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Канада" },
        { label: "Длительность", value: "113 мин" },
        { label: "Бюджет", value: "$178 млн" },
        { label: "Студия", value: "Warner Bros., Village Roadshow" },
        { label: "Режиссёр", value: "Doug Liman" },
        { label: "Темы", value: "Петля времени, война, рост героя" },
      ],
      cast: [
        { name: "Tom Cruise", role: "Уильям Кейдж" },
        { name: "Emily Blunt", role: "Рита Вратаски" },
        { name: "Bill Paxton", role: "Сержант Фаррелл" },
        { name: "Brendan Gleeson", role: "Генерал Бригам" },
        { name: "Noah Taylor", role: "Доктор Картер" },
      ],
      players: [
        {
          id: "factorios-505851",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/505851",
        },
      ],
    },
  {
      id: 29,
      kinopoiskId: 1267348,
      slug: "john-wick-chapter-4",
      title: "Джон Уик 4",
      originalTitle: "John Wick: Chapter 4",
      searchTitles: ["джон уик", "джон вик", "уик 4", "wick"],
      type: "Фильм",
      year: "2023",
      rating: 7.7,
      genres: ["Экшен", "Криминал", "Триллер"],
      poster: "https://image.tmdb.org/t/p/w500/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg",
      description:
        "Стильный боевик о человеке, которому лучше не мешать отдыхать.",
      trailerUrl: "https://www.youtube.com/embed/qEVUtrk8_B4",
      longDescription:
        "«Джон Уик 4» — фильм 2023 года в жанрах Экшен, Криминал, Триллер, где стильный боевик о человеке, которому лучше не мешать отдыхать. Джон Уик ищет путь к свободе от Высокого стола, но каждый шаг открывает новых врагов и старые долги. Четвёртая глава делает ставку на стиль, правила мира киллеров и почти балетную боевую постановку. Работа Chad Stahelski и команды Lionsgate, Thunder Road чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2023" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "169 мин" },
        { label: "Бюджет", value: "$100 млн" },
        { label: "Студия", value: "Lionsgate, Thunder Road" },
        { label: "Режиссёр", value: "Chad Stahelski" },
        { label: "Настроение", value: "Неон, дуэли, экшен" },
      ],
      cast: [
        { name: "Keanu Reeves", role: "Джон Уик" },
        { name: "Donnie Yen", role: "Кейн" },
        { name: "Bill Skarsgård", role: "Маркиз де Грамон" },
        { name: "Hiroyuki Sanada", role: "Симадзу" },
        { name: "Ian McShane", role: "Уинстон" },
      ],
      players: [
        {
          id: "factorios-1267348",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1267348",
        },
      ],
    },
  {
      id: 30,
      kinopoiskId: 195334,
      slug: "the-prestige",
      title: "Престиж",
      originalTitle: "The Prestige",
      searchTitles: ["престиж", "the prestige", "фокусники", "магия"],
      type: "Фильм",
      year: "2006",
      rating: 8.5,
      genres: ["Драма", "Триллер", "Фантастика"],
      poster: "https://image.tmdb.org/t/p/w500/bdN3gXuIZYaJP7ftKK2sU0nPtEA.jpg",
      description: "Соперничество двух иллюзионистов превращается в одержимость.",
      trailerUrl: "https://www.youtube.com/embed/o4gHCmTQDVI",
      longDescription:
        "«Престиж» — фильм 2006 года в жанрах Драма, Триллер, Фантастика, где соперничество двух иллюзионистов превращается в одержимость. Два иллюзиониста превращают профессиональное соперничество в опасную одержимость. Каждый трюк требует жертвы, а настоящая тайна оказывается не только на сцене, но и в том, что герои готовы скрывать. Работа Christopher Nolan и команды Warner Bros., Touchstone, Syncopy чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2006" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Великобритания" },
        { label: "Длительность", value: "130 мин" },
        { label: "Бюджет", value: "$40 млн" },
        { label: "Студия", value: "Warner Bros., Touchstone, Syncopy" },
        { label: "Режиссёр", value: "Christopher Nolan" },
        { label: "Темы", value: "Одержимость, тайна, цена успеха" },
      ],
      cast: [
        { name: "Hugh Jackman", role: "Роберт Энжиер" },
        { name: "Christian Bale", role: "Альфред Борден" },
        { name: "Michael Caine", role: "Каттер" },
        { name: "Scarlett Johansson", role: "Оливия" },
        { name: "David Bowie", role: "Никола Тесла" },
      ],
      players: [
        {
          id: "factorios-195334",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/195334",
        },
      ],
    },
  {
      id: 31,
      kinopoiskId: 468466,
      slug: "gravity",
      title: "Гравитация",
      originalTitle: "Gravity",
      searchTitles: ["гравитация", "gravity", "космос"],
      type: "Фильм",
      year: "2013",
      rating: 7.7,
      genres: ["Фантастика", "Драма", "Триллер"],
      poster: "https://image.tmdb.org/t/p/w500/kZ2nZw8D681aphje8NJi8EfbL1U.jpg",
      description: "Выживание в космосе, где тишина страшнее любого монстра.",
      trailerUrl: "https://www.youtube.com/embed/OiTiKOy59o4",
      longDescription:
        "«Гравитация» — фильм 2013 года в жанрах Фантастика, Драма, Триллер, где выживание в космосе, где тишина страшнее любого монстра. После аварии на орбите доктор Райан Стоун пытается выжить в космосе, где каждая ошибка может стать последней. Минималистичная история держит напряжение на расстоянии вытянутого скафандра. Работа Alfonso Cuarón и команды Warner Bros., Heyday Films чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2013" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Великобритания, Мексика" },
        { label: "Длительность", value: "91 мин" },
        { label: "Бюджет", value: "$100 млн" },
        { label: "Студия", value: "Warner Bros., Heyday Films" },
        { label: "Режиссёр", value: "Alfonso Cuarón" },
        { label: "Темы", value: "Выживание, космос, одиночество" },
      ],
      cast: [
        { name: "Sandra Bullock", role: "Райан Стоун" },
        { name: "George Clooney", role: "Мэтт Ковальски" },
        { name: "Ed Harris", role: "Голос центра управления" },
        { name: "Орбита Земли", role: "Главная опасная локация" },
        { name: "Космический мусор", role: "Катализатор катастрофы" },
      ],
      players: [
        {
          id: "factorios-468466",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/468466",
        },
      ],
    },
  {
      id: 32,
      kinopoiskId: 5934685,
      slug: "the-super-mario-galaxy-movie",
      title: "Супер Марио Галактика в кино",
      originalTitle: "The Super Mario Galaxy Movie",
      searchTitles: [
        "супер марио",
        "марио галактика",
        "super mario galaxy",
        "mario galaxy movie",
        "новинки 2026",
      ],
      type: "Фильм",
      year: "2026",
      rating: 8.1,
      genres: ["Анимация", "Приключения", "Комедия"],
      poster:
        "https://upload.wikimedia.org/wikipedia/en/thumb/b/bf/The_Super_Mario_Galaxy_Movie_poster.jpeg/250px-The_Super_Mario_Galaxy_Movie_poster.jpeg",
      posterFallbacks: [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/The_Super_Mario_Galaxy_Movie_%282026%29_Poster.jpg/1080px-The_Super_Mario_Galaxy_Movie_%282026%29_Poster.jpg",
      ],
      description:
        "Космическое анимационное приключение по миру Super Mario: ярко, быстро и семейно.",
      trailerUrl: "https://www.youtube.com/embed/wJ3S26JMW5M",
      longDescription:
        "«Супер Марио Галактика в кино» — фильм 2026 года в жанрах Анимация, Приключения, Комедия, где космическое анимационное приключение по миру Super Mario: ярко, быстро и семейно. Новое анимационное приключение переносит мир Super Mario в космический масштаб. В центре остаются дружба, скорость, яркий визуальный стиль и большая галактическая авантюра для всей семьи. Проект студии Illumination, Nintendo делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2026" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США, Япония" },
        { label: "Длительность", value: "будет объявлена" },
        { label: "Бюджет", value: "будет объявлен" },
        { label: "Студия", value: "Illumination, Nintendo" },
        { label: "Дистрибьютор", value: "Universal Pictures" },
        { label: "Формат", value: "Анимационный фильм" },
      ],
      cast: [
        { name: "Марио", role: "Главный герой и мастер прыжков" },
        { name: "Луиджи", role: "Брат Марио и верный союзник" },
        { name: "Принцесса Пич", role: "Лидер Грибного королевства" },
        { name: "Боузер", role: "Главная угроза приключения" },
        { name: "Розалина", role: "Космическая фигура мира Mario" },
      ],
      players: [
        {
          id: "factorios-5934685",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5934685",
        },
      ],
    },
  {
      id: 33,
      kinopoiskId: 1382256,
      slug: "project-hail-mary",
      title: "Проект “Аве Мария”",
      originalTitle: "Project Hail Mary",
      searchTitles: [
        "проект аве мария",
        "project hail mary",
        "райан гослинг",
        "космос",
        "новинки 2026",
      ],
      type: "Фильм",
      year: "2026",
      rating: 8.4,
      genres: ["Фантастика", "Драма", "Приключения"],
      poster:
        "https://image.tmdb.org/t/p/w500/h5FcFJzoeIjimuGhQ5Dw598T2Vu.jpg",
      posterFallbacks: [
        "https://upload.wikimedia.org/wikipedia/en/3/3b/Project_Hail_Mary_poster.jpg",
        "https://upload.wikimedia.org/wikipedia/en/thumb/3/3b/Project_Hail_Mary_poster.jpg/500px-Project_Hail_Mary_poster.jpg",
      ],
      description:
        "Научно-фантастическая история о миссии, где один человек должен найти шанс для спасения Земли.",
      trailerUrl: "https://www.youtube.com/embed/kZnc7YqBoI8",
      longDescription:
        "«Проект “Аве Мария”» — фильм 2026 года в жанрах Фантастика, Драма, Приключения, где научно-фантастическая история о миссии, где один человек должен найти шанс для спасения Земли. Учёный Райланд Грейс просыпается на космическом корабле и постепенно понимает, что от его миссии зависит будущее Земли. Это научная фантастика о разуме, одиночестве и неожиданной дружбе там, где её никто не планировал. Работа Phil Lord, Christopher Miller и команды Amazon MGM Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2026" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "будет объявлена" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Amazon MGM Studios" },
        { label: "Режиссёры", value: "Phil Lord, Christopher Miller" },
        { label: "Основа", value: "Роман Andy Weir" },
      ],
      cast: [
        { name: "Ryan Gosling", role: "Райланд Грейс" },
        { name: "Рокки", role: "Неожиданный союзник из космоса" },
        { name: "Ева Стратт", role: "Руководительница кризисной миссии" },
        { name: "Команда проекта", role: "Люди, ищущие шанс для Земли" },
        { name: "Земля", role: "Ставка всей истории" },
      ],
      players: [
        {
          id: "factorios-1382256",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1382256",
        },
      ],
    },
  {
      id: 34,
      kinopoiskId: 5437614,
      slug: "michael",
      title: "Майкл",
      originalTitle: "Michael",
      searchTitles: [
        "майкл",
        "michael",
        "michael jackson",
        "майкл джексон",
        "биография",
        "новинки 2026",
      ],
      type: "Фильм",
      year: "2026",
      rating: 7.8,
      genres: ["Биография", "Музыка", "Драма"],
      poster:
        "https://upload.wikimedia.org/wikipedia/en/3/37/Michael_%282026_film_poster%29.png",
      posterFallbacks: [
        "https://upload.wikimedia.org/wikipedia/en/thumb/3/37/Michael_%282026_film_poster%29.png/500px-Michael_%282026_film_poster%29.png",
      ],
      description:
        "Музыкальная биографическая драма о сцене, славе и цене большой легенды.",
      trailerUrl: "https://www.youtube.com/embed/3k1vW9iXD_c",
      longDescription:
        "«Майкл» — фильм 2026 года в жанрах Биография, Музыка, Драма, где музыкальная биографическая драма о сцене, славе и цене большой легенды. Биографическая драма рассказывает о пути Майкла Джексона, сцене, славе и давлении большой легенды. Фильм делает акцент на музыке, семье и цене публичного успеха. Работа Antoine Fuqua и команды Lionsgate, Universal Pictures чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение, конфликт, темп. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2026" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "будет объявлена" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Lionsgate, Universal Pictures" },
        { label: "Режиссёр", value: "Antoine Fuqua" },
        { label: "Формат", value: "Музыкальная биография" },
      ],
      cast: [
        { name: "Jaafar Jackson", role: "Майкл Джексон" },
        { name: "Colman Domingo", role: "Джо Джексон" },
        { name: "Nia Long", role: "Кэтрин Джексон" },
        { name: "Miles Teller", role: "Джон Бранка" },
        { name: "Музыкальная сцена", role: "Главное пространство истории" },
      ],
      players: [
        {
          id: "factorios-5437614",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5437614",
        },
      ],
    },
  {
      id: 35,
      kinopoiskId: 6373982,
      slug: "the-devil-wears-prada-2",
      title: "Дьявол носит Prada 2",
      originalTitle: "The Devil Wears Prada 2",
      searchTitles: [
        "дьявол носит прада",
        "дьявол носит prada 2",
        "the devil wears prada 2",
        "новинки 2026",
      ],
      type: "Фильм",
      year: "2026",
      rating: 7.7,
      genres: ["Драма", "Комедия"],
      poster:
        "https://upload.wikimedia.org/wikipedia/en/9/97/The_Devil_Wears_Prada_2_%28film_poster%29.png",
      posterFallbacks: [
        "https://upload.wikimedia.org/wikipedia/en/thumb/9/97/The_Devil_Wears_Prada_2_%28film_poster%29.png/500px-The_Devil_Wears_Prada_2_%28film_poster%29.png",
      ],
      description:
        "Возвращение в мир моды, редакций и идеального холодного взгляда.",
      trailerUrl: "https://www.youtube.com/embed/7Y4H0lQNTp0",
      longDescription:
        "«Дьявол носит Prada 2» — фильм 2026 года в жанрах Драма, Комедия, где возвращение в мир моды, редакций и идеального холодного взгляда. Продолжение возвращает зрителя в мир модной индустрии, редакций и карьерных решений. Герои снова сталкиваются с амбициями, переменами медиа и тем самым взглядом Миранды, который громче любого дедлайна. Работа David Frankel и команды 20th Century Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2026" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "будет объявлена" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "20th Century Studios" },
        { label: "Режиссёр", value: "David Frankel" },
        { label: "Жанры", value: "Драма, Комедия" },
      ],
      cast: [
        { name: "Meryl Streep", role: "Миранда Пристли" },
        { name: "Anne Hathaway", role: "Энди Сакс" },
        { name: "Emily Blunt", role: "Эмили Чарлтон" },
        { name: "Stanley Tucci", role: "Найджел" },
        { name: "Runway", role: "Модный журнал и поле битвы дедлайнов" },
      ],
      players: [
        {
          id: "factorios-6373982",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/6373982",
        },
      ],
    },
  {
      id: 36,
      kinopoiskId: 5364826,
      slug: "scream-7",
      title: "Крик 7",
      originalTitle: "Scream 7",
      searchTitles: ["крик 7", "scream 7", "ghostface", "ужасы", "новинки 2026"],
      type: "Фильм",
      year: "2026",
      rating: 7.1,
      genres: ["Ужасы", "Триллер"],
      poster:
        "https://upload.wikimedia.org/wikipedia/en/c/c2/Scream_7_%28poster%29.jpg",
      posterFallbacks: [
        "https://image.tmdb.org/t/p/w500/jcejzY3BakzUVvRX3I4bsDQPlTd.jpg",
        "https://upload.wikimedia.org/wikipedia/en/thumb/c/c2/Scream_7_%28poster%29.jpg/500px-Scream_7_%28poster%29.jpg",
      ],
      description:
        "Новая глава слэшера: маска возвращается, а спокойная жизнь снова оказывается слишком подозрительной.",
      trailerUrl: "https://www.youtube.com/embed/4g8OciWNJn4",
      longDescription:
        "«Крик 7» — фильм 2026 года в жанрах Ужасы, Триллер, где новая глава слэшера: маска возвращается, а спокойная жизнь снова оказывается слишком подозрительной. Новая глава возвращает Ghostface и знакомую игру с правилами слэшера. История строится вокруг угрозы, подозрений и персонажей, которым снова приходится разбираться, кто скрывается за маской. Работа Kevin Williamson и команды Spyglass Media, Paramount Pictures чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2026" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "будет объявлена" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Spyglass Media, Paramount Pictures" },
        { label: "Режиссёр", value: "Kevin Williamson" },
        { label: "Формат", value: "Слэшер" },
      ],
      cast: [
        { name: "Neve Campbell", role: "Сидни Прескотт" },
        { name: "Courteney Cox", role: "Гейл Уэзерс" },
        { name: "Ghostface", role: "Главная угроза" },
        { name: "Новые герои", role: "Следующее поколение жертв и подозреваемых" },
        { name: "Вудсборо", role: "Место, где спокойствие обычно недолгое" },
      ],
      players: [
        {
          id: "factorios-5364826",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5364826",
        },
      ],
    },
  {
      id: 37,
      kinopoiskId: 5453060,
      slug: "mercy",
      title: "Милосердие",
      originalTitle: "Mercy",
      searchTitles: ["милосердие", "mercy", "фантастический триллер", "новинки 2026"],
      type: "Фильм",
      year: "2026",
      rating: 7.2,
      genres: ["Фантастика", "Экшен", "Триллер"],
      poster:
        "https://upload.wikimedia.org/wikipedia/en/4/43/Mercy_2026_poster.jpeg",
      posterFallbacks: [
        "https://upload.wikimedia.org/wikipedia/en/thumb/4/43/Mercy_2026_poster.jpeg/500px-Mercy_2026_poster.jpeg",
      ],
      description:
        "Фантастический триллер о будущем, где система правосудия стала слишком быстрой.",
      trailerUrl: "https://www.youtube.com/embed/dwpKyuu5D7w",
      longDescription:
        "«Милосердие» — фильм 2026 года в жанрах Фантастика, Экшен, Триллер, где фантастический триллер о будущем, где система правосудия стала слишком быстрой. Фантастический триллер переносит зрителя в будущее, где система правосудия стала слишком быстрой и технологичной. Герою приходится доказывать свою правоту в мире, где ошибка алгоритма может стоить слишком дорого. Работа Timur Bekmambetov и команды Amazon MGM Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2026" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "будет объявлена" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Amazon MGM Studios" },
        { label: "Режиссёр", value: "Timur Bekmambetov" },
        { label: "Жанры", value: "Фантастика, Экшен, Триллер" },
      ],
      cast: [
        { name: "Chris Pratt", role: "Главный герой" },
        { name: "Rebecca Ferguson", role: "Ключевая фигура расследования" },
        { name: "Система правосудия", role: "Главный конфликт будущего" },
        { name: "Обвиняемый", role: "Человек против машины решений" },
        { name: "Город будущего", role: "Локация технологичного триллера" },
      ],
      players: [
        {
          id: "factorios-5453060",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5453060",
        },
      ],
    },
  {
      id: 38,
      kinopoiskId: 5003039,
      slug: "wonder-man",
      title: "Wonder Man",
      originalTitle: "Wonder Man",
      searchTitles: ["wonder man", "вандер мен", "marvel", "марвел", "новинки 2026"],
      type: "Сериал",
      year: "2026",
      rating: 7.5,
      genres: ["Экшен", "Комедия", "Фантастика"],
      poster:
        "https://cdn.marvel.com/content/2x/call_back_e16_1sheetbusshelter_rd2_v1b_rs_mech4.jpg",
      posterFallbacks: [
        "https://upload.wikimedia.org/wikipedia/en/thumb/b/bd/Wonder_Man_%28TV_series%29_logo.png/500px-Wonder_Man_%28TV_series%29_logo.png",
      ],
      description:
        "Сериал про актёра, супергеройскую роль и момент, когда кастинг становится слишком реальным.",
      trailerUrl: "https://www.youtube.com/embed/wHuWmjXsReU",
      longDescription:
        "«Wonder Man» — сериал 2026 года в жанрах Экшен, Комедия, Фантастика, где сериал про актёра, супергеройскую роль и момент, когда кастинг становится слишком реальным. Саймон Уильямс оказывается в мире киноиндустрии и супергеройской славы. Сериал обещает смешать Marvel-экшен, сатиру на Голливуд и историю человека, для которого роль может стать реальнее контракта. Работа Andrew Guest и команды Marvel Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Сериал раскрывается постепенно: серии дают время привыкнуть к героям и заметить скрытые связи. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2026" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "будет объявлена" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "Marvel Studios" },
        { label: "Создатель", value: "Andrew Guest" },
        { label: "Вселенная", value: "Marvel Cinematic Universe" },
      ],
      cast: [
        { name: "Yahya Abdul-Mateen II", role: "Саймон Уильямс / Wonder Man" },
        { name: "Ben Kingsley", role: "Тревор Слэттери" },
        { name: "Hollywood set", role: "Мир актёрской славы" },
        { name: "Marvel-индустрия", role: "Комедийный фон истории" },
        { name: "Супергеройская роль", role: "Главный поворот сюжета" },
      ],
      players: [
        {
          id: "factorios-5003039",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5003039",
        },
      ],
    },
  {
      id: 39,
      kinopoiskId: 1186149,
      slug: "star-trek-starfleet-academy",
      title: "Звёздный путь: Академия Звёздного флота",
      originalTitle: "Star Trek: Starfleet Academy",
      searchTitles: [
        "звездный путь академия",
        "звёздный путь академия",
        "star trek starfleet academy",
        "starfleet academy",
        "новинки 2026",
      ],
      type: "Сериал",
      year: "2026",
      rating: 7.6,
      genres: ["Фантастика", "Приключения", "Драма"],
      poster:
        "https://treknews.net/wp-content/uploads/2025/07/SFA_Overhead_PR_Vert_CTA_4x5_1080x1350-819x1024.jpg",
      posterFallbacks: [
        "https://cdn.mos.cms.futurecdn.net/EYiH8Dr2rgCdRP6VxEJZt4.jpg",
        "https://blog.trekcore.com/wp-content/uploads/2025/12/sfa-key-art-cast.jpg",
      ],
      description:
        "Новая группа курсантов учится выживать в академии, дружбе и большой космической ответственности.",
      trailerUrl: "https://www.youtube.com/embed/rHDDzcyNWGs",
      longDescription:
        "«Звёздный путь: Академия Звёздного флота» — сериал 2026 года в жанрах Фантастика, Приключения, Драма, где новая группа курсантов учится выживать в академии, дружбе и большой космической ответственности. Сериал переносит фокус на молодых курсантов Академии Звёздного флота. Им предстоит учиться, ошибаться, дружить и сталкиваться с космическими вызовами, где экзамены иногда выглядят подозрительно похожими на спасение галактики. Работа Alex Kurtzman, Noga Landau и команды CBS Studios, Secret Hideout чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2026" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "будет объявлена" },
        { label: "Бюджет", value: "не раскрыт" },
        { label: "Студия", value: "CBS Studios, Secret Hideout" },
        { label: "Создатели", value: "Alex Kurtzman, Noga Landau" },
        { label: "Вселенная", value: "Star Trek" },
      ],
      cast: [
        { name: "Курсанты Академии", role: "Новая команда Звёздного флота" },
        { name: "Holly Hunter", role: "Капитан и наставница академии" },
        { name: "Paul Giamatti", role: "Сезонный антагонист" },
        { name: "Преподаватели флота", role: "Опытные наставники" },
        { name: "Звёздный флот", role: "Главная система и мечта героев" },
      ],
      players: [
        {
          id: "factorios-1186149",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1186149",
        },
      ],
    },
  {
      id: 40,
      kinopoiskId: 2360,
      slug: "the-lion-king-1994",
      title: "Король Лев",
      originalTitle: "The Lion King",
      searchTitles: ["король лев", "симба", "the lion king", "lion king", "дисней", "мультфильмы"],
      type: "Мультфильм",
      year: "1994",
      rating: 8.5,
      genres: ["Анимация", "Приключения", "Семейный", "Музыка", "Драма"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/thumb/6/62/Lion_king_ver1.jpg/330px-Lion_king_ver1.jpg",
      description:
        "Большая история взросления, ответственности и возвращения домой под музыку, которую сложно не подпевать.",
      trailerUrl: "https://www.youtube.com/embed/lFzVJEksoDY",
      longDescription:
        "«Король Лев» — мультфильм 1994 года в жанрах Анимация, Приключения, Семейный, где большая история взросления, ответственности и возвращения домой под музыку, которую сложно не подпевать. Юный Симба должен понять, что значит быть наследником, другом и настоящим лидером. Это мультфильм о семье, смелости и выборе, который делает героя героем — без лишнего пафоса, но с очень мощным сердцем. Проект студии Walt Disney Pictures делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "1994" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "88 мин" },
        { label: "Бюджет", value: "$45 млн" },
        { label: "Студия", value: "Walt Disney Pictures" },
        { label: "Настроение", value: "Эпично, тепло, музыкально" },
        { label: "Темы", value: "Семья, ответственность, взросление" },
      ],
      cast: [
        { name: "Симба", role: "Юный наследник, который учится быть лидером" },
        { name: "Муфаса", role: "Мудрый король и отец Симбы" },
        { name: "Нала", role: "Смелая подруга Симбы" },
        { name: "Тимон и Пумба", role: "Комедийный дуэт и команда поддержки" },
      ],
      players: [
        {
          id: "factorios-2360",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/2360",
        },
      ],
    },
  {
      id: 41,
      kinopoiskId: 482,
      slug: "toy-story",
      title: "История игрушек",
      originalTitle: "Toy Story",
      searchTitles: ["история игрушек", "toy story", "вуди", "базз", "пиксар", "мультфильмы"],
      type: "Мультфильм",
      year: "1995",
      rating: 8.3,
      genres: ["Анимация", "Комедия", "Приключения", "Семейный", "Фэнтези"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/thumb/a/a6/Toy_Story_1995_Poster.jpg/250px-Toy_Story_1995_Poster.jpg",
      description:
        "Игрушки оживают, дружба проходит стресс-тест, а ревность получает урок размером с космический скафандр.",
      trailerUrl: "https://www.youtube.com/embed/v-PjgYDrg70",
      longDescription:
        "«История игрушек» — мультфильм 1995 года в жанрах Анимация, Комедия, Приключения, где игрушки оживают, дружба проходит стресс-тест, а ревность получает урок размером с космический скафандр. Вуди всегда был любимой игрушкой Энди, пока в комнате не появился Базз Лайтер. Их соперничество быстро превращается в приключение, где важно не доказать, кто главный, а научиться быть командой. Проект студии Pixar Animation Studios делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "1995" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "81 мин" },
        { label: "Бюджет", value: "$30 млн" },
        { label: "Студия", value: "Pixar Animation Studios" },
        { label: "Настроение", value: "Весело, быстро, ностальгично" },
        { label: "Темы", value: "Дружба, ревность, принятие перемен" },
      ],
      cast: [
        { name: "Вуди", role: "Верный ковбой и лидер игрушек" },
        { name: "Базз Лайтер", role: "Космический рейнджер с большим самомнением" },
        { name: "Бо Пип", role: "Спокойная и уверенная союзница" },
        { name: "Мистер Картофельная Голова", role: "Сарказм на ножках" },
      ],
      players: [
        {
          id: "factorios-482",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/482",
        },
      ],
    },
  {
      id: 42,
      kinopoiskId: 279102,
      slug: "wall-e",
      title: "ВАЛЛ·И",
      originalTitle: "WALL·E",
      searchTitles: ["валли", "валл и", "wall-e", "walle", "робот", "пиксар", "мультфильмы"],
      type: "Мультфильм",
      year: "2008",
      rating: 8.4,
      genres: ["Анимация", "Фантастика", "Приключения", "Семейный", "Романтика"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/c/c4/WALL-E_poster.png",
      description:
        "Маленький робот, большая планета и почти немой мультфильм, который говорит громче многих блокбастеров.",
      trailerUrl: "https://www.youtube.com/embed/CZ1CATNbXg0",
      longDescription:
        "«ВАЛЛ·И» — мультфильм 2008 года в жанрах Анимация, Фантастика, Приключения, где маленький робот, большая планета и почти немой мультфильм, который говорит громче многих блокбастеров. ВАЛЛ·И годами убирает заброшенную Землю и однажды встречает ЕВУ — робота, который меняет его привычный мир. Получается нежная фантастика о заботе, одиночестве и надежде на второй шанс для планеты. Проект студии Pixar Animation Studios делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2008" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "98 мин" },
        { label: "Бюджет", value: "$180 млн" },
        { label: "Студия", value: "Pixar Animation Studios" },
        { label: "Настроение", value: "Трогательно, умно, атмосферно" },
        { label: "Темы", value: "Экология, одиночество, надежда" },
      ],
      cast: [
        { name: "ВАЛЛ·И", role: "Робот-уборщик с огромным сердцем" },
        { name: "ЕВА", role: "Разведывательный робот и новый смысл путешествия" },
        { name: "MO", role: "Робот-чистюля, которому досталась сложная смена" },
        { name: "Капитан", role: "Человек, который заново учится выбирать" },
      ],
      players: [
        {
          id: "factorios-279102",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/279102",
        },
      ],
    },
  {
      id: 43,
      kinopoiskId: 430,
      slug: "shrek",
      title: "Шрэк",
      originalTitle: "Shrek",
      searchTitles: ["шрек", "shrek", "осел", "фиона", "dreamworks", "мультфильмы"],
      type: "Мультфильм",
      year: "2001",
      rating: 7.9,
      genres: ["Анимация", "Комедия", "Приключения", "Семейный", "Фэнтези"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/thumb/3/39/Shrek.jpg/330px-Shrek.jpg",
      description:
        "Сказка, которая пришла в болото, перевернула правила жанра и доказала: герой не обязан быть глянцевым.",
      trailerUrl: "https://www.youtube.com/embed/CwXOrWvPBPk",
      longDescription:
        "«Шрэк» — мультфильм 2001 года в жанрах Анимация, Комедия, Приключения, где сказка, которая пришла в болото, перевернула правила жанра и доказала: герой не обязан быть глянцевым. Огр Шрэк просто хочет вернуть спокойствие своему болоту, но получает квест с принцессой, говорящим Ослом и кучей сказочных проблем. Это комедия о принятии себя, дружбе и том, что первое впечатление часто ошибается громче всех. Проект студии DreamWorks Animation делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2001" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "90 мин" },
        { label: "Бюджет", value: "$60 млн" },
        { label: "Студия", value: "DreamWorks Animation" },
        { label: "Настроение", value: "Иронично, смешно, сказочно" },
        { label: "Темы", value: "Самопринятие, дружба, любовь" },
      ],
      cast: [
        { name: "Шрэк", role: "Огр, который ценит тишину и честность" },
        { name: "Осёл", role: "Друг, который говорит больше, чем нужно, но всегда вовремя" },
        { name: "Фиона", role: "Принцесса с характером и собственным секретом" },
        { name: "Лорд Фаркуад", role: "Злодей с большим самомнением" },
      ],
      players: [
        {
          id: "factorios-430",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/430",
        },
      ],
    },
  {
      id: 44,
      kinopoiskId: 89514,
      slug: "ratatouille",
      title: "Рататуй",
      originalTitle: "Ratatouille",
      searchTitles: ["рататуй", "ratatouille", "реми", "повар", "пиксар", "мультфильмы"],
      type: "Мультфильм",
      year: "2007",
      rating: 8.1,
      genres: ["Анимация", "Комедия", "Семейный", "Драма", "Кулинария"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/thumb/d/d1/Ratatui.jpg/330px-Ratatui.jpg",
      description:
        "Крыса мечтает стать шеф-поваром в Париже. Звучит как хаос, но получается один из самых вкусных мультфильмов.",
      trailerUrl: "https://www.youtube.com/embed/NgsQ8mVkN8w",
      longDescription:
        "«Рататуй» — мультфильм 2007 года в жанрах Анимация, Комедия, Семейный, где крыса мечтает стать шеф-поваром в Париже. Звучит как хаос, но получается один из самых вкусных мультфильмов. Реми обожает готовить, хотя мир не очень готов принять крысу на кухне. Вместе с неуклюжим Лингвини он пытается доказать, что талант может появиться там, где его никто не ждёт. Проект студии Pixar Animation Studios делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2007" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "111 мин" },
        { label: "Бюджет", value: "$150 млн" },
        { label: "Студия", value: "Pixar Animation Studios" },
        { label: "Настроение", value: "Уютно, вдохновляюще, вкусно" },
        { label: "Темы", value: "Мечта, талант, смелость быть собой" },
      ],
      cast: [
        { name: "Реми", role: "Маленький гурман с большим талантом" },
        { name: "Лингвини", role: "Неуклюжий помощник, которому нужен шанс" },
        { name: "Колетт", role: "Профессионал, который держит кухню в форме" },
        { name: "Антон Эго", role: "Критик, чей взгляд решает многое" },
      ],
      players: [
        {
          id: "factorios-89514",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/89514",
        },
      ],
    },
  {
      id: 45,
      kinopoiskId: 645118,
      slug: "inside-out",
      title: "Головоломка",
      originalTitle: "Inside Out",
      searchTitles: ["головоломка", "inside out", "радость", "печаль", "эмоции", "пиксар", "мультфильмы"],
      type: "Мультфильм",
      year: "2015",
      rating: 8.1,
      genres: ["Анимация", "Комедия", "Семейный", "Драма", "Фэнтези"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/1/18/%D0%93%D0%BE%D0%BB%D0%BE%D0%B2%D0%BE%D0%BB%D0%BE%D0%BC%D0%BA%D0%B0_2015.jpg",
      description:
        "Путешествие по эмоциям внутри головы, где Радость и Печаль наконец перестают спорить за пульт управления.",
      trailerUrl: "https://www.youtube.com/embed/yRUAzGQ3nSY",
      longDescription:
        "«Головоломка» — мультфильм 2015 года в жанрах Анимация, Комедия, Семейный, где путешествие по эмоциям внутри головы, где Радость и Печаль наконец перестают спорить за пульт управления. Райли переезжает в новый город, а её эмоции пытаются справиться с переменами. Мультфильм показывает, что грусть — не ошибка системы, а важная часть взросления и понимания себя. Проект студии Pixar Animation Studios делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2015" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "95 мин" },
        { label: "Бюджет", value: "$175 млн" },
        { label: "Студия", value: "Pixar Animation Studios" },
        { label: "Настроение", value: "Добро, умно, эмоционально" },
        { label: "Темы", value: "Эмоции, переезд, взросление" },
      ],
      cast: [
        { name: "Радость", role: "Эмоция, которая хочет всё исправить улыбкой" },
        { name: "Печаль", role: "Эмоция, без которой нельзя понять себя" },
        { name: "Райли", role: "Девочка, которая проходит через большие перемены" },
        { name: "Брезгливость", role: "Внутренний фильтр стиля и подозрительной брокколи" },
      ],
      players: [
        {
          id: "factorios-645118",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/645118",
        },
      ],
    },
  {
      id: 46,
      kinopoiskId: 679486,
      slug: "coco",
      title: "Тайна Коко",
      originalTitle: "Coco",
      searchTitles: ["тайна коко", "коко", "coco", "мигель", "музыка", "пиксар", "мультфильмы"],
      type: "Мультфильм",
      year: "2017",
      rating: 8.4,
      genres: ["Анимация", "Музыка", "Семейный", "Приключения", "Фэнтези"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/thumb/d/d7/Coco_%282017_film%29_logo.jpg/330px-Coco_%282017_film%29_logo.jpg",
      description:
        "Музыкальное путешествие в мир памяти, семьи и мечты, после которого слово “прабабушка” звучит особенно тепло.",
      trailerUrl: "https://www.youtube.com/embed/Rvr68u6k5sI",
      longDescription:
        "«Тайна Коко» — мультфильм 2017 года в жанрах Анимация, Музыка, Семейный, где музыкальное путешествие в мир памяти, семьи и мечты, после которого слово “прабабушка” звучит особенно тепло. Мигель мечтает стать музыкантом, хотя в его семье музыка под запретом. Попав в удивительный мир предков, он узнаёт, почему память о близких может быть сильнее времени. Проект студии Pixar Animation Studios делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение, конфликт. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2017" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "105 мин" },
        { label: "Бюджет", value: "$175–225 млн" },
        { label: "Студия", value: "Pixar Animation Studios" },
        { label: "Настроение", value: "Музыкально, ярко, трогательно" },
        { label: "Темы", value: "Семья, память, мечта" },
      ],
      cast: [
        { name: "Мигель", role: "Мальчик, который хочет играть музыку" },
        { name: "Гектор", role: "Весёлый проводник с важной тайной" },
        { name: "Мама Коко", role: "Сердце семейной истории" },
        { name: "Эрнесто де ла Крус", role: "Кумир, за блеском которого скрыто не всё" },
      ],
      players: [
        {
          id: "factorios-679486",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/679486",
        },
      ],
    },
  {
      id: 47,
      kinopoiskId: 280172,
      slug: "how-to-train-your-dragon",
      title: "Как приручить дракона",
      originalTitle: "How to Train Your Dragon",
      searchTitles: ["как приручить дракона", "иккинг", "беззубик", "how to train your dragon", "dreamworks", "мультфильмы"],
      type: "Мультфильм",
      year: "2010",
      rating: 8.1,
      genres: ["Анимация", "Приключения", "Семейный", "Фэнтези", "Экшен"],
      poster: "https://upload.wikimedia.org/wikipedia/ru/thumb/a/a3/How_to_Train_Your_Dragon.jpg/250px-How_to_Train_Your_Dragon.jpg",
      description:
        "Парень-викинг и дракон доказывают деревне, что дружба иногда сильнее традиций и громких топоров.",
      trailerUrl: "https://www.youtube.com/embed/oKiYuIsPxYk",
      longDescription:
        "«Как приручить дракона» — мультфильм 2010 года в жанрах Анимация, Приключения, Семейный, где парень-викинг и дракон доказывают деревне, что дружба иногда сильнее традиций и громких топоров. Иккинг живёт среди викингов, которые привыкли сражаться с драконами. Но встреча с Беззубиком меняет всё: вместо врага он видит живое существо, друга и шанс изменить будущее своего народа. Проект студии DreamWorks Animation делает ставку на цельную атмосферу, аккуратный темп и детали, которые постепенно раскрывают главную идею. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2010" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "98 мин" },
        { label: "Бюджет", value: "$165 млн" },
        { label: "Студия", value: "DreamWorks Animation" },
        { label: "Настроение", value: "Приключенчески, тепло, зрелищно" },
        { label: "Темы", value: "Дружба, доверие, смелость" },
      ],
      cast: [
        { name: "Иккинг", role: "Юный викинг, который думает иначе" },
        { name: "Беззубик", role: "Дракон, который становится другом" },
        { name: "Астрид", role: "Сильная и внимательная союзница" },
        { name: "Стоик", role: "Отец Иккинга и вождь деревни" },
      ],
      players: [
        {
          id: "factorios-280172",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/280172",
        },
      ],
    },
  {
      id: 48,
      kinopoiskId: 326,
      slug: "the-shawshank-redemption",
      title: "Побег из Шоушенка",
      originalTitle: "The Shawshank Redemption",
      searchTitles: ["побег из шоушенка", "шоушенк", "shawshank redemption", "shawshank"],
      type: "Фильм",
      year: "1994",
      rating: 9.3,
      genres: ["Драма", "Криминал"],
      poster: "https://image.tmdb.org/t/p/w500/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg",
      description: "История надежды, дружбы и внутренней свободы за стенами тюрьмы.",
      trailerUrl: "https://www.youtube.com/embed/PLl99DlL6b4",
      longDescription:
        "«Побег из Шоушенка» — фильм 1994 года в жанрах Драма, Криминал, где история надежды, дружбы и внутренней свободы за стенами тюрьмы. Банкир Энди Дюфрейн попадает в тюрьму Шоушенк и сталкивается с системой, которая пытается стереть личность. Его спокойствие, ум и дружба с Рэдом превращают мрачную историю в фильм о надежде, которая работает тише, чем молоток, но сильнее стены. Работа Frank Darabont и команды Castle Rock Entertainment чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "1994" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "142 мин" },
        { label: "Студия", value: "Castle Rock Entertainment" },
        { label: "Режиссёр", value: "Frank Darabont" },
        { label: "Основа", value: "Повесть Stephen King" },
        { label: "Темы", value: "Надежда, дружба, свобода" },
      ],
      cast: [
        { name: "Tim Robbins", role: "Энди Дюфрейн" },
        { name: "Morgan Freeman", role: "Эллис «Рэд» Реддинг" },
        { name: "Bob Gunton", role: "Начальник тюрьмы Нортон" },
        { name: "William Sadler", role: "Хейвуд" },
        { name: "Clancy Brown", role: "Капитан Хэдли" },
      ],
      players: [
        {
          id: "factorios-326",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/326",
        },
      ],
    },
  {
      id: 49,
      kinopoiskId: 448,
      slug: "forrest-gump",
      title: "Форрест Гамп",
      originalTitle: "Forrest Gump",
      searchTitles: ["форрест гамп", "форест гамп", "forrest gump", "гамп"],
      type: "Фильм",
      year: "1994",
      rating: 8.8,
      genres: ["Драма", "Романтика", "Комедия"],
      poster: "https://image.tmdb.org/t/p/w500/arw2vcBveWOVZr6pxd9XTd1TdQa.jpg",
      description: "Трогательная история человека, который проходит через эпоху с открытым сердцем.",
      trailerUrl: "https://www.youtube.com/embed/bLvqoHBptjg",
      longDescription:
        "«Форрест Гамп» — фильм 1994 года в жанрах Драма, Романтика, Комедия, где трогательная история человека, который проходит через эпоху с открытым сердцем. Форрест Гамп видит мир проще многих, но именно это помогает ему прожить удивительную жизнь. Он оказывается рядом с большими событиями истории, сохраняет верность близким и доказывает: доброта иногда быстрее любой стратегии. Работа Robert Zemeckis и команды Paramount Pictures чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "1994" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "142 мин" },
        { label: "Студия", value: "Paramount Pictures" },
        { label: "Режиссёр", value: "Robert Zemeckis" },
        { label: "Основа", value: "Роман Winston Groom" },
        { label: "Темы", value: "Судьба, любовь, доброта" },
      ],
      cast: [
        { name: "Tom Hanks", role: "Форрест Гамп" },
        { name: "Robin Wright", role: "Дженни Карран" },
        { name: "Gary Sinise", role: "Лейтенант Дэн" },
        { name: "Mykelti Williamson", role: "Бабба" },
        { name: "Sally Field", role: "Миссис Гамп" },
      ],
      players: [
        {
          id: "factorios-448",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/448",
        },
      ],
    },
  {
      id: 50,
      kinopoiskId: 328,
      slug: "the-lord-of-the-rings-the-fellowship-of-the-ring",
      title: "Властелин колец: Братство кольца",
      originalTitle: "The Lord of the Rings: The Fellowship of the Ring",
      searchTitles: ["властелин колец", "братство кольца", "lord of the rings", "fellowship of the ring"],
      type: "Фильм",
      year: "2001",
      rating: 8.9,
      genres: ["Фэнтези", "Приключения", "Драма"],
      poster: "https://image.tmdb.org/t/p/w500/6oom5QYQ2yQTMJIbnvbkBL9cHo6.jpg",
      description: "Начало большого путешествия через Средиземье ради уничтожения кольца.",
      trailerUrl: "https://www.youtube.com/embed/V75dMMIW2B4",
      longDescription:
        "«Властелин колец: Братство кольца» — фильм 2001 года в жанрах Фэнтези, Приключения, Драма, где начало большого путешествия через Средиземье ради уничтожения кольца. Фродо получает кольцо, от которого зависит судьба Средиземья. Вместе с Братством он начинает путь, где дружба, смелость и маленький шаг вперёд оказываются важнее громких титулов и древних пророчеств. Работа Peter Jackson и команды New Line Cinema, WingNut Films чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2001" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "Новая Зеландия, США" },
        { label: "Длительность", value: "178 мин" },
        { label: "Студия", value: "New Line Cinema, WingNut Films" },
        { label: "Режиссёр", value: "Peter Jackson" },
        { label: "Основа", value: "Роман J. R. R. Tolkien" },
        { label: "Мир", value: "Средиземье" },
      ],
      cast: [
        { name: "Elijah Wood", role: "Фродо Бэггинс" },
        { name: "Ian McKellen", role: "Гэндальф" },
        { name: "Viggo Mortensen", role: "Арагорн" },
        { name: "Sean Astin", role: "Сэм" },
        { name: "Orlando Bloom", role: "Леголас" },
      ],
      players: [
        {
          id: "factorios-328",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/328",
        },
      ],
    },
  {
      id: 51,
      kinopoiskId: 5457899,
      slug: "the-wild-robot",
      title: "Дикий робот",
      originalTitle: "The Wild Robot",
      searchTitles: ["дикий робот", "wild robot", "робот роз", "роз"],
      type: "Мультфильм",
      year: "2024",
      rating: 8.2,
      genres: ["Анимация", "Приключения", "Семейный", "Фантастика"],
      poster: "https://image.tmdb.org/t/p/w500/wTnV3PCVW5O92JMrFvvrRcV39RU.jpg",
      description: "Робот оказывается на диком острове и учится понимать жизнь вокруг.",
      trailerUrl: "https://www.youtube.com/embed/67vbA5ZJdKQ",
      longDescription:
        "«Дикий робот» — мультфильм 2024 года в жанрах Анимация, Приключения, Семейный, где робот оказывается на диком острове и учится понимать жизнь вокруг. Робот ROZZUM попадает на необитаемый остров и пытается выжить среди животных. Постепенно она учится заботе, языку природы и дружбе, превращаясь из машины с инструкциями в героя с сердцем. Работа Chris Sanders и команды DreamWorks Animation чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "102 мин" },
        { label: "Студия", value: "DreamWorks Animation" },
        { label: "Режиссёр", value: "Chris Sanders" },
        { label: "Основа", value: "Книга Peter Brown" },
        { label: "Темы", value: "Забота, природа, адаптация" },
      ],
      cast: [
        { name: "Роз", role: "Робот, который учится жить среди природы" },
        { name: "Брайтбилл", role: "Гусёнок и важная связь Роз" },
        { name: "Финк", role: "Лис и неожиданный союзник" },
        { name: "Пинктейл", role: "Опытная мама-опоссум" },
        { name: "Жители острова", role: "Дикая, шумная и честная школа жизни" },
      ],
      players: [
        {
          id: "factorios-5457899",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5457899",
        },
      ],
    },
  {
      id: 52,
      kinopoiskId: 5102255,
      slug: "inside-out-2",
      title: "Головоломка 2",
      originalTitle: "Inside Out 2",
      searchTitles: ["головоломка 2", "inside out 2", "эмоции", "тревожность", "райли"],
      type: "Мультфильм",
      year: "2024",
      rating: 7.6,
      genres: ["Анимация", "Комедия", "Семейный", "Драма"],
      poster: "https://image.tmdb.org/t/p/w500/vpnVM9B6NMmQpWeZvzLvDESb2QY.jpg",
      description: "У Райли появляются новые эмоции, и в голове снова начинается ремонт без предупреждения.",
      trailerUrl: "https://www.youtube.com/embed/LEjhY15eCx0",
      longDescription:
        "«Головоломка 2» — мультфильм 2024 года в жанрах Анимация, Комедия, Семейный, где у Райли появляются новые эмоции, и в голове снова начинается ремонт без предупреждения. Райли взрослеет, а вместе с ней меняется и штаб эмоций. Радость, Печаль и старые знакомые сталкиваются с новыми чувствами, которые делают подростковый возраст сложным, смешным и очень узнаваемым. Работа Kelsey Mann и команды Pixar Animation Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "96 мин" },
        { label: "Студия", value: "Pixar Animation Studios" },
        { label: "Режиссёр", value: "Kelsey Mann" },
        { label: "Продолжение", value: "Головоломка" },
        { label: "Темы", value: "Взросление, эмоции, самооценка" },
      ],
      cast: [
        { name: "Райли", role: "Девочка, которая взрослеет" },
        { name: "Радость", role: "Эмоция, которая всё ещё хочет как лучше" },
        { name: "Печаль", role: "Эмоция, без которой не собрать себя" },
        { name: "Тревожность", role: "Новая эмоция с планами на всё сразу" },
        { name: "Зависть", role: "Новая участница внутренней команды" },
      ],
      players: [
        {
          id: "factorios-5102255",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5102255",
        },
      ],
    },
  {
      id: 53,
      kinopoiskId: 1388409,
      slug: "furiosa-a-mad-max-saga",
      title: "Фуриоса: Хроники Безумного Макса",
      originalTitle: "Furiosa: A Mad Max Saga",
      searchTitles: ["фуриоса", "furiosa", "безумный макс", "mad max saga"],
      type: "Фильм",
      year: "2024",
      rating: 7.5,
      genres: ["Экшен", "Приключения", "Фантастика"],
      poster: "https://image.tmdb.org/t/p/w500/iADOJ8Zymht2JPMoy3R7xceZprc.jpg",
      description: "История Фуриосы до Дороги ярости: пустошь, власть и выживание.",
      trailerUrl: "https://www.youtube.com/embed/XJMuhwVlca4",
      longDescription:
        "«Фуриоса: Хроники Безумного Макса» — фильм 2024 года в жанрах Экшен, Приключения, Фантастика, где история Фуриосы до Дороги ярости: пустошь, власть и выживание. Юная Фуриоса оказывается вырвана из родного места и попадает в жестокий мир пустоши. На пути к свободе ей приходится изучить правила силы, союзы и цену мести в мире, где бензин иногда звучит как валюта судьбы. Работа George Miller и команды Warner Bros., Village Roadshow чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "Австралия, США" },
        { label: "Длительность", value: "148 мин" },
        { label: "Студия", value: "Warner Bros., Village Roadshow" },
        { label: "Режиссёр", value: "George Miller" },
        { label: "Связь", value: "Приквел к Дороге ярости" },
        { label: "Настроение", value: "Пыльно, быстро, сурово" },
      ],
      cast: [
        { name: "Anya Taylor-Joy", role: "Фуриоса" },
        { name: "Chris Hemsworth", role: "Дементус" },
        { name: "Tom Burke", role: "Преторианец Джек" },
        { name: "Alyla Browne", role: "Юная Фуриоса" },
        { name: "Lachy Hulme", role: "Несмертный Джо" },
      ],
      players: [
        {
          id: "factorios-1388409",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1388409",
        },
      ],
    },
  {
      id: 54,
      kinopoiskId: 4887347,
      slug: "alien-romulus",
      title: "Чужой: Ромул",
      originalTitle: "Alien: Romulus",
      searchTitles: ["чужой ромул", "alien romulus", "чужой", "ксеноморф"],
      type: "Фильм",
      year: "2024",
      rating: 7.1,
      genres: ["Ужасы", "Фантастика", "Триллер"],
      poster: "https://image.tmdb.org/t/p/w500/b33nnKl1GSFbao4l3fZDDqsMx0F.jpg",
      description: "Космический хоррор о группе молодых людей и очень плохой находке.",
      trailerUrl: "https://www.youtube.com/embed/x0XDEhP4MQs",
      longDescription:
        "«Чужой: Ромул» — фильм 2024 года в жанрах Ужасы, Фантастика, Триллер, где космический хоррор о группе молодых людей и очень плохой находке. Группа молодых колонистов исследует заброшенную космическую станцию и сталкивается с угрозой, которую лучше было бы оставить в темноте. Фильм возвращает франшизу к тесным коридорам, саспенсу и ощущению, что космос не любит любопытных. Работа Fede Álvarez и команды 20th Century Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "119 мин" },
        { label: "Студия", value: "20th Century Studios" },
        { label: "Режиссёр", value: "Fede Álvarez" },
        { label: "Вселенная", value: "Alien" },
        { label: "Настроение", value: "Напряжённо, мрачно, клаустрофобно" },
      ],
      cast: [
        { name: "Cailee Spaeny", role: "Рейн" },
        { name: "David Jonsson", role: "Энди" },
        { name: "Archie Renaux", role: "Тайлер" },
        { name: "Isabela Merced", role: "Кей" },
        { name: "Ксеноморф", role: "Причина не заходить в странные коридоры" },
      ],
      players: [
        {
          id: "factorios-4887347",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/4887347",
        },
      ],
    },
  {
      id: 55,
      kinopoiskId: 963343,
      slug: "a-silent-voice",
      title: "Форма голоса",
      originalTitle: "A Silent Voice",
      searchTitles: ["форма голоса", "a silent voice", "koe no katachi", "голос формы"],
      type: "Аниме",
      year: "2016",
      rating: 8.1,
      genres: ["Аниме", "Драма", "Школа"],
      poster: "https://image.tmdb.org/t/p/w500/tuFaWiqX0TXoWu7DGNcmX3UW7sT.jpg",
      description: "Школьная драма о вине, взрослении и попытке наладить связь.",
      trailerUrl: "https://www.youtube.com/embed/nfK6UgLra7g",
      longDescription:
        "«Форма голоса» — аниме 2016 года в жанрах Аниме, Драма, Школа, где школьная драма о вине, взрослении и попытке наладить связь. Сёя пытается исправить ошибки прошлого и снова встретиться с Сёко, девочкой, над которой когда-то издевался. Это тихая, эмоциональная история о принятии, ответственности и сложном пути к прощению. Работа Naoko Yamada и команды Kyoto Animation чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Аниме держится на эмоциях, мире и развитии персонажей, а не только на динамичных сценах. Такое описание помогает понять, чего ждать от просмотра: не только завязку, но и настроение, конфликт, темп и те детали, которые делают историю заметной в своей категории.",
      facts: [
        { label: "Год", value: "2016" },
        { label: "Тип", value: "Аниме" },
        { label: "Страна", value: "Япония" },
        { label: "Длительность", value: "130 мин" },
        { label: "Студия", value: "Kyoto Animation" },
        { label: "Режиссёр", value: "Naoko Yamada" },
        { label: "Основа", value: "Манга Yoshitoki Ōima" },
        { label: "Темы", value: "Прощение, вина, общение" },
      ],
      cast: [
        { name: "Сёя Исида", role: "Парень, который пытается измениться" },
        { name: "Сёко Нисимия", role: "Девочка, с которой он хочет восстановить связь" },
        { name: "Юдзуру Нисимия", role: "Сестра Сёко" },
        { name: "Наока Уэно", role: "Одноклассница с непростым характером" },
        { name: "Томохиро Нагацука", role: "Друг, который появляется очень вовремя" },
      ],
      players: [
        { id: "player-1", name: "Плеер 1", embedUrl: "" },
        { id: "player-2", name: "Плеер 2", embedUrl: "" },
      ],
    },
  {
      id: 56,
      kinopoiskId: 370,
      slug: "spirited-away",
      title: "Унесённые призраками",
      originalTitle: "Spirited Away",
      searchTitles: ["унесенные призраками", "унесённые призраками", "spirited away", "тихиро", "хаку"],
      type: "Аниме",
      year: "2001",
      rating: 8.6,
      genres: ["Аниме", "Фэнтези", "Приключения"],
      poster: "https://image.tmdb.org/t/p/w500/39wmItIWsg5sZMyRUHLkWBcuVCM.jpg",
      description: "Волшебное путешествие девочки в мир духов, где нужно найти смелость.",
      trailerUrl: "https://www.youtube.com/embed/ByXuk9QqQkk",
      longDescription:
        "«Унесённые призраками» — аниме 2001 года в жанрах Аниме, Фэнтези, Приключения, где волшебное путешествие девочки в мир духов, где нужно найти смелость. Тихиро попадает в загадочный мир духов и должна найти способ спасти родителей. История смешивает сказку, взросление и невероятную атмосферу, где каждый новый персонаж будто пришёл из сна, который слишком хорошо нарисовали. Работа Hayao Miyazaki и команды Studio Ghibli чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Аниме держится на эмоциях, мире и развитии персонажей, а не только на динамичных сценах. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2001" },
        { label: "Тип", value: "Аниме" },
        { label: "Страна", value: "Япония" },
        { label: "Длительность", value: "125 мин" },
        { label: "Студия", value: "Studio Ghibli" },
        { label: "Режиссёр", value: "Hayao Miyazaki" },
        { label: "Формат", value: "Полнометражное аниме" },
        { label: "Темы", value: "Смелость, взросление, память" },
      ],
      cast: [
        { name: "Тихиро Огино", role: "Девочка, которая учится быть смелой" },
        { name: "Хаку", role: "Таинственный союзник" },
        { name: "Юбаба", role: "Хозяйка купален" },
        { name: "Безликий", role: "Дух, которому очень нужна связь" },
        { name: "Камадзи", role: "Хранитель котельной" },
      ],
      players: [
        { id: "player-1", name: "Плеер 1", embedUrl: "" },
        { id: "player-2", name: "Плеер 2", embedUrl: "" },
      ],
    },
  {
      id: 57,
      kinopoiskId: 49166,
      slug: "coraline",
      title: "Коралина в Стране Кошмаров",
      originalTitle: "Coraline",
      searchTitles: ["коралина", "coraline", "страна кошмаров", "кукольная анимация"],
      type: "Мультфильм",
      year: "2009",
      rating: 7.8,
      genres: ["Анимация", "Фэнтези", "Приключения", "Мистика"],
      poster: "https://image.tmdb.org/t/p/w500/4jeFXQYytChdZYE9JYO7Un87IlW.jpg",
      description: "Кукольная сказка с мрачной атмосферой и очень подозрительной идеальной реальностью.",
      trailerUrl: "https://www.youtube.com/embed/m9bOpeuvNwY",
      longDescription:
        "«Коралина в Стране Кошмаров» — мультфильм 2009 года в жанрах Анимация, Фэнтези, Приключения, где кукольная сказка с мрачной атмосферой и очень подозрительной идеальной реальностью. Коралина находит дверь в альтернативный мир, где всё кажется ярче и лучше. Но чем дольше она там остаётся, тем яснее становится: идеальная версия дома может просить слишком дорогую цену. Работа Henry Selick и команды Laika чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Мультфильм остаётся лёгким по подаче, но сохраняет характеры, юмор и эмоциональную линию. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2009" },
        { label: "Тип", value: "Мультфильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "100 мин" },
        { label: "Студия", value: "Laika" },
        { label: "Режиссёр", value: "Henry Selick" },
        { label: "Основа", value: "Повесть Neil Gaiman" },
        { label: "Формат", value: "Покадровая анимация" },
      ],
      cast: [
        { name: "Коралина Джонс", role: "Девочка с любопытством сильнее страха" },
        { name: "Другая Мама", role: "Слишком идеальная хозяйка другого мира" },
        { name: "Кот", role: "Проводник и независимый эксперт по странностям" },
        { name: "Уайби", role: "Сосед и неожиданный помощник" },
        { name: "Другой мир", role: "Место, где уют быстро становится ловушкой" },
      ],
      players: [
        {
          id: "factorios-49166",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/49166",
        },
      ],
    },
  {
      id: 58,
      kinopoiskId: 279548,
      slug: "planet-earth",
      title: "Планета Земля",
      originalTitle: "Planet Earth",
      searchTitles: ["планета земля", "planet earth", "bbc earth", "природа", "документальный"],
      type: "Документальный",
      year: "2006",
      rating: 9.4,
      genres: ["Документальный", "Природа"],
      poster: "https://kinogo.media/uploads/posts/2021-10/1634926941_iphone360_279548.jpg",
      posterFallbacks: [
        "https://upload.wikimedia.org/wikipedia/en/thumb/7/7f/Planet_Earth_DVD_cover.jpg/330px-Planet_Earth_DVD_cover.jpg"
      ],
      description: "Классический документальный проект BBC о природе и самых удивительных местах планеты.",
      trailerUrl: "https://www.youtube.com/embed/lMta7k46JWE",
      longDescription:
        "«Планета Земля» — документальный проект 2006 года в жанрах Документальный, Природа, где классический документальный проект BBC о природе и самых удивительных местах планеты. «Планета Земля» показывает разные экосистемы и редкие моменты жизни дикой природы. Это документальное путешествие, где настоящие пейзажи выглядят так, будто природа сама решила снять дорогой блокбастер без спецэффектов. Работа David Attenborough и команды BBC Natural History Unit чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Документальный формат работает на погружение и помогает внимательнее смотреть на реальные темы. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2006" },
        { label: "Тип", value: "Документальный" },
        { label: "Страна", value: "Великобритания" },
        { label: "Длительность", value: "около 50 мин / серия" },
        { label: "Студия", value: "BBC Natural History Unit" },
        { label: "Рассказчик", value: "David Attenborough" },
        { label: "Серий", value: "11" },
        { label: "Темы", value: "Природа, экосистемы, животные" },
      ],
      cast: [
        { name: "David Attenborough", role: "Рассказчик" },
        { name: "BBC Earth", role: "Съёмочная команда" },
        { name: "Дикая природа", role: "Главный герой проекта" },
        { name: "Горы, океаны и леса", role: "Ключевые локации" },
        { name: "Планета Земля", role: "Главная тема проекта" },
      ],
      players: [
        {
          id: "factorios-279548",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/279548",
        },
      ],
    },
  {
    "slug": "gladiator",
    kinopoiskId: 474,
    "title": "Гладиатор",
    "originalTitle": "Gladiator",
    "searchTitles": [
      "гладиатор",
      "gladiator",
      "максимус",
      "рим"
    ],
    "type": "Фильм",
    "year": "2000",
    "rating": 8.5,
    "genres": [
      "История",
      "Драма",
      "Экшен",
      "Приключения"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/ty8TGRuvJLPUmAR1H1nRIsgwvim.jpg",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/8/8d/Gladiator_ver1.jpg"
    ],
    "description": "Историческая драма о генерале, который теряет всё и выходит на арену ради справедливости.",
    "trailerUrl": "https://www.youtube.com/embed/P5ieIbInFpg",
    "longDescription": "Максимус был верным генералом Рима, но предательство лишает его семьи, статуса и будущего. На арене Колизея он превращает борьбу за выживание в вызов императорской власти и легенду о чести.",
    "facts": [
      {
        "label": "Год",
        "value": "2000"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "США, Великобритания"
      },
      {
        "label": "Длительность",
        "value": "155 мин"
      },
      {
        "label": "Студия",
        "value": "DreamWorks Pictures, Universal Pictures"
      },
      {
        "label": "Режиссёр",
        "value": "Ridley Scott"
      },
      {
        "label": "Настроение",
        "value": "Эпично, драматично, масштабно"
      },
      {
        "label": "Темы",
        "value": "Месть, честь, власть"
      }
    ],
    "cast": [
      {
        "name": "Russell Crowe",
        "role": "Максимус"
      },
      {
        "name": "Joaquin Phoenix",
        "role": "Коммод"
      },
      {
        "name": "Connie Nielsen",
        "role": "Луцилла"
      },
      {
        "name": "Oliver Reed",
        "role": "Проксимо"
      },
      {
        "name": "Richard Harris",
        "role": "Марк Аврелий"
      }
    ],
    players: [
      {
        id: "factorios-474",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/474",
      },
    ],
    "id": 59
  },
  {
    "slug": "pulp-fiction",
    kinopoiskId: 342,
    "title": "Криминальное чтиво",
    "originalTitle": "Pulp Fiction",
    "searchTitles": [
      "криминальное чтиво",
      "pulp fiction",
      "тарантино",
      "винсент и джулс"
    ],
    "type": "Фильм",
    "year": "1994",
    "rating": 8.9,
    "genres": [
      "Криминал",
      "Драма",
      "Комедия"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/8/82/Pulp_Fiction_cover.jpg"
    ],
    "description": "Нелинейная криминальная классика с диалогами, которые давно ушли в цитаты.",
    "trailerUrl": "https://www.youtube.com/embed/s7EdQ4FqbhY",
    "longDescription": "Несколько историй из криминального Лос-Анджелеса переплетаются вокруг случайностей, странных решений и людей, которые слишком уверены, что контролируют ситуацию. Фильм держится на ритме, стиле и разговорах, где каждое слово работает на атмосферу.",
    "facts": [
      {
        "label": "Год",
        "value": "1994"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "154 мин"
      },
      {
        "label": "Студия",
        "value": "Miramax"
      },
      {
        "label": "Режиссёр",
        "value": "Quentin Tarantino"
      },
      {
        "label": "Настроение",
        "value": "Стильно, иронично, криминально"
      },
      {
        "label": "Темы",
        "value": "Случайность, мораль, поп-культура"
      }
    ],
    "cast": [
      {
        "name": "John Travolta",
        "role": "Винсент Вега"
      },
      {
        "name": "Samuel L. Jackson",
        "role": "Джулс Уиннфилд"
      },
      {
        "name": "Uma Thurman",
        "role": "Миа Уоллес"
      },
      {
        "name": "Bruce Willis",
        "role": "Бутч Куллидж"
      },
      {
        "name": "Ving Rhames",
        "role": "Марселлас Уоллес"
      }
    ],
    players: [
      {
        id: "factorios-342",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/342",
      },
    ],
    "id": 60
  },
  {
    "slug": "fight-club",
    kinopoiskId: 361,
    "title": "Бойцовский клуб",
    "originalTitle": "Fight Club",
    "searchTitles": [
      "бойцовский клуб",
      "fight club",
      "тайлер дерден"
    ],
    "type": "Фильм",
    "year": "1999",
    "rating": 8.8,
    "genres": [
      "Драма",
      "Триллер"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/f/fc/Fight_Club_poster.jpg"
    ],
    "description": "Психологическая история о пустоте, бунте и правилах, о которых все всё равно говорят.",
    "trailerUrl": "https://www.youtube.com/embed/qtRKdVHc-cE",
    "longDescription": "Безымянный герой застрял в рутине и бессоннице, пока знакомство с Тайлером Дерденом не открывает ему новый способ чувствовать себя живым. Но личный протест быстро вырастает в опасную систему, которую уже трудно остановить.",
    "facts": [
      {
        "label": "Год",
        "value": "1999"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "США, Германия"
      },
      {
        "label": "Длительность",
        "value": "139 мин"
      },
      {
        "label": "Студия",
        "value": "20th Century Fox, Regency Enterprises"
      },
      {
        "label": "Режиссёр",
        "value": "David Fincher"
      },
      {
        "label": "Настроение",
        "value": "Мрачно, нервно, провокационно"
      },
      {
        "label": "Темы",
        "value": "Идентичность, потребление, контроль"
      }
    ],
    "cast": [
      {
        "name": "Edward Norton",
        "role": "Рассказчик"
      },
      {
        "name": "Brad Pitt",
        "role": "Тайлер Дерден"
      },
      {
        "name": "Helena Bonham Carter",
        "role": "Марла Сингер"
      },
      {
        "name": "Meat Loaf",
        "role": "Роберт Полсон"
      },
      {
        "name": "Jared Leto",
        "role": "Ангельское лицо"
      }
    ],
    players: [
      {
        id: "factorios-361",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/361",
      },
    ],
    "id": 61
  },
  {
    "slug": "se7en",
    kinopoiskId: 377,
    "title": "Семь",
    "originalTitle": "Se7en",
    "searchTitles": [
      "семь",
      "seven",
      "se7en",
      "финчер",
      "детектив"
    ],
    "type": "Фильм",
    "year": "1995",
    "rating": 8.6,
    "genres": [
      "Триллер",
      "Криминал",
      "Драма"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/191nKfP0ehp3uIvWqgPbFmI4lv9.jpg",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/6/68/Seven_%28movie%29_poster.jpg"
    ],
    "description": "Мрачный детектив о двух напарниках и серии преступлений, построенных как страшная головоломка.",
    "trailerUrl": "https://www.youtube.com/embed/znmZoVkCjpI",
    "longDescription": "Опытный детектив Сомерсет и молодой Миллс расследуют цепочку преступлений, связанных с семью грехами. Город будто сам становится участником дела: дождливым, уставшим и полным тревожных подсказок.",
    "facts": [
      {
        "label": "Год",
        "value": "1995"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "127 мин"
      },
      {
        "label": "Студия",
        "value": "New Line Cinema"
      },
      {
        "label": "Режиссёр",
        "value": "David Fincher"
      },
      {
        "label": "Настроение",
        "value": "Мрачно, напряжённо, детективно"
      },
      {
        "label": "Темы",
        "value": "Справедливость, вина, одержимость"
      }
    ],
    "cast": [
      {
        "name": "Brad Pitt",
        "role": "Дэвид Миллс"
      },
      {
        "name": "Morgan Freeman",
        "role": "Уильям Сомерсет"
      },
      {
        "name": "Gwyneth Paltrow",
        "role": "Трейси Миллс"
      },
      {
        "name": "Kevin Spacey",
        "role": "Джон Доу"
      },
      {
        "name": "R. Lee Ermey",
        "role": "Капитан полиции"
      }
    ],
    players: [
      {
        id: "factorios-377",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/377",
      },
    ],
    "id": 62
  },
  {
    "slug": "the-godfather",
    kinopoiskId: 325,
    "title": "Крёстный отец",
    "originalTitle": "The Godfather",
    "searchTitles": [
      "крестный отец",
      "крёстный отец",
      "godfather",
      "корлеоне"
    ],
    "type": "Фильм",
    "year": "1972",
    "rating": 9.2,
    "genres": [
      "Криминал",
      "Драма"
    ],
    "poster": "https://avatars.mds.yandex.net/get-kinopoisk-image/10703959/ebf237d7-64a3-4b75-98f1-d228d54658e5/220x330",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/1/1c/Godfather_ver1.jpg"
    ],
    "description": "Криминальная сага о семье Корлеоне, власти и цене наследия.",
    "trailerUrl": "https://www.youtube.com/embed/sY1S34973zA",
    "longDescription": "Семья Корлеоне живёт по своим правилам, где честь, бизнес и насилие опасно близки. Майкл сначала держится в стороне от дел семьи, но обстоятельства постепенно превращают его в человека, от которого зависит будущее клана.",
    "facts": [
      {
        "label": "Год",
        "value": "1972"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "175 мин"
      },
      {
        "label": "Студия",
        "value": "Paramount Pictures"
      },
      {
        "label": "Режиссёр",
        "value": "Francis Ford Coppola"
      },
      {
        "label": "Настроение",
        "value": "Величественно, напряжённо, классически"
      },
      {
        "label": "Темы",
        "value": "Семья, власть, наследие"
      }
    ],
    "cast": [
      {
        "name": "Marlon Brando",
        "role": "Вито Корлеоне"
      },
      {
        "name": "Al Pacino",
        "role": "Майкл Корлеоне"
      },
      {
        "name": "James Caan",
        "role": "Сонни Корлеоне"
      },
      {
        "name": "Diane Keaton",
        "role": "Кей Адамс"
      },
      {
        "name": "Robert Duvall",
        "role": "Том Хейген"
      }
    ],
    players: [
      {
        id: "factorios-325",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/325",
      },
    ],
    "id": 63
  },
  {
    "slug": "the-green-mile",
    kinopoiskId: 435,
    "title": "Зелёная миля",
    "originalTitle": "The Green Mile",
    "searchTitles": [
      "зеленая миля",
      "зелёная миля",
      "green mile",
      "джон коффи"
    ],
    "type": "Фильм",
    "year": "1999",
    "rating": 8.6,
    "genres": [
      "Драма",
      "Фэнтези",
      "Криминал"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/8VG8fDNiy50H4FedGwdSVUPoaJe.jpg",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/c/ce/Green_mile.jpg"
    ],
    "description": "Трогательная драма о надзирателях, заключённом и чуде, которое трудно объяснить.",
    "trailerUrl": "https://www.youtube.com/embed/Ki4haFrqSrw",
    "longDescription": "Пол Эджкомб работает в тюремном блоке смертников и привык не удивляться людям. Но появление Джона Коффи меняет его взгляд на добро, страх и чудеса, которые могут прийти в самое тяжёлое место.",
    "facts": [
      {
        "label": "Год",
        "value": "1999"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "189 мин"
      },
      {
        "label": "Студия",
        "value": "Warner Bros., Castle Rock Entertainment"
      },
      {
        "label": "Режиссёр",
        "value": "Frank Darabont"
      },
      {
        "label": "Настроение",
        "value": "Трогательно, мистически, человечно"
      },
      {
        "label": "Темы",
        "value": "Сострадание, вина, чудо"
      }
    ],
    "cast": [
      {
        "name": "Tom Hanks",
        "role": "Пол Эджкомб"
      },
      {
        "name": "Michael Clarke Duncan",
        "role": "Джон Коффи"
      },
      {
        "name": "David Morse",
        "role": "Брут Хауэлл"
      },
      {
        "name": "Sam Rockwell",
        "role": "Уильям Уортон"
      },
      {
        "name": "Bonnie Hunt",
        "role": "Джан Эджкомб"
      }
    ],
    players: [
      {
        id: "factorios-435",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/435",
      },
    ],
    "id": 64
  },
  {
    "slug": "whiplash",
    kinopoiskId: 725190,
    "title": "Одержимость",
    "originalTitle": "Whiplash",
    "searchTitles": [
      "одержимость",
      "whiplash",
      "барабанщик",
      "джаз"
    ],
    "type": "Фильм",
    "year": "2014",
    "rating": 8.5,
    "genres": [
      "Драма",
      "Музыка"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/7fn624j5lj3xTme2SgiLCeuedmO.jpg",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/0/01/Whiplash_poster.jpg"
    ],
    "description": "Жёсткая музыкальная драма о таланте, давлении и цене идеального темпа.",
    "trailerUrl": "https://www.youtube.com/embed/7d_jQycdQGo",
    "longDescription": "Молодой барабанщик Эндрю хочет стать великим, но встреча с преподавателем Флетчером превращает обучение в психологическое испытание. Фильм звучит как дуэль: громко, точно и без права на фальшивую ноту.",
    "facts": [
      {
        "label": "Год",
        "value": "2014"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "106 мин"
      },
      {
        "label": "Студия",
        "value": "Bold Films, Blumhouse Productions"
      },
      {
        "label": "Режиссёр",
        "value": "Damien Chazelle"
      },
      {
        "label": "Настроение",
        "value": "Нервно, энергично, музыкально"
      },
      {
        "label": "Темы",
        "value": "Талант, дисциплина, давление"
      }
    ],
    "cast": [
      {
        "name": "Miles Teller",
        "role": "Эндрю Ниман"
      },
      {
        "name": "J. K. Simmons",
        "role": "Теренс Флетчер"
      },
      {
        "name": "Melissa Benoist",
        "role": "Николь"
      },
      {
        "name": "Paul Reiser",
        "role": "Джим Ниман"
      },
      {
        "name": "Austin Stowell",
        "role": "Райан"
      }
    ],
    players: [
      {
        id: "factorios-725190",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/725190",
      },
    ],
    "id": 65
  },
  {
    "slug": "parasite",
    kinopoiskId: 1043758,
    "title": "Паразиты",
    "originalTitle": "Parasite",
    "searchTitles": [
      "паразиты",
      "parasite",
      "кино корея",
      "бон джун хо"
    ],
    "type": "Фильм",
    "year": "2019",
    "rating": 8.5,
    "genres": [
      "Драма",
      "Триллер",
      "Комедия"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/5/53/Parasite_%282019_film%29.png"
    ],
    "description": "Социальный триллер, где чужой дом становится сценой для очень неудобной правды.",
    "trailerUrl": "https://www.youtube.com/embed/5xH0HfJHsaY",
    "longDescription": "Семья Кимов постепенно устраивается работать в богатый дом, используя смекалку и риск. Но за красивым фасадом прячется больше слоёв, чем кажется, и каждая лестница в этом фильме ведёт к новой правде о неравенстве.",
    "facts": [
      {
        "label": "Год",
        "value": "2019"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "Южная Корея"
      },
      {
        "label": "Длительность",
        "value": "132 мин"
      },
      {
        "label": "Студия",
        "value": "Barunson E&A"
      },
      {
        "label": "Режиссёр",
        "value": "Bong Joon-ho"
      },
      {
        "label": "Настроение",
        "value": "Умно, напряжённо, сатирично"
      },
      {
        "label": "Темы",
        "value": "Классы, семья, выживание"
      }
    ],
    "cast": [
      {
        "name": "Song Kang-ho",
        "role": "Ким Ки-тэк"
      },
      {
        "name": "Choi Woo-shik",
        "role": "Ки-у"
      },
      {
        "name": "Park So-dam",
        "role": "Ки-джон"
      },
      {
        "name": "Jang Hye-jin",
        "role": "Чхун-сук"
      },
      {
        "name": "Lee Sun-kyun",
        "role": "Пак Дон-ик"
      }
    ],
    players: [
      {
        id: "factorios-1043758",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1043758",
      },
    ],
    "id": 66
  },
  {
    "slug": "joker-2019",
    kinopoiskId: 1048334,
    "title": "Джокер",
    "originalTitle": "Joker",
    "searchTitles": [
      "джокер",
      "joker",
      "артур флек",
      "dc"
    ],
    "type": "Фильм",
    "year": "2019",
    "rating": 8.4,
    "genres": [
      "Драма",
      "Криминал",
      "Триллер"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg",
    "posterFallbacks": [
      "https://upload.wikimedia.org/wikipedia/en/e/e1/Joker_%282019_film%29_poster.jpg"
    ],
    "description": "Мрачная история Артура Флека и города, который не умеет слышать слабых.",
    "trailerUrl": "https://www.youtube.com/embed/zAGVQLHvwOY",
    "longDescription": "Артур Флек пытается быть комиком и удержаться на плаву в безразличном Готэме. Его путь постепенно превращается в историю о боли, одиночестве и опасной силе образа, который город сам помогает создать.",
    "facts": [
      {
        "label": "Год",
        "value": "2019"
      },
      {
        "label": "Тип",
        "value": "Фильм"
      },
      {
        "label": "Страна",
        "value": "США, Канада"
      },
      {
        "label": "Длительность",
        "value": "122 мин"
      },
      {
        "label": "Студия",
        "value": "Warner Bros., DC Films"
      },
      {
        "label": "Режиссёр",
        "value": "Todd Phillips"
      },
      {
        "label": "Настроение",
        "value": "Мрачно, психологически, тревожно"
      },
      {
        "label": "Темы",
        "value": "Одиночество, образ, общество"
      }
    ],
    "cast": [
      {
        "name": "Joaquin Phoenix",
        "role": "Артур Флек / Джокер"
      },
      {
        "name": "Robert De Niro",
        "role": "Мюррей Франклин"
      },
      {
        "name": "Zazie Beetz",
        "role": "Софи Дюмонд"
      },
      {
        "name": "Frances Conroy",
        "role": "Пенни Флек"
      },
      {
        "name": "Brett Cullen",
        "role": "Томас Уэйн"
      }
    ],
    players: [
      {
        id: "factorios-1048334",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1048334",
      },
    ],
    "id": 67
  },
  {
    "slug": "chernobyl",
    kinopoiskId: 1227803,
    "title": "Чернобыль",
    "originalTitle": "Chernobyl",
    "searchTitles": [
      "чернобыль",
      "chernobyl",
      "hbo",
      "авария"
    ],
    "type": "Сериал",
    "year": "2019",
    "rating": 9.3,
    "genres": [
      "Драма",
      "История",
      "Мини-сериал"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/hlLXt2tOPT6RRnjiUmoxyG1LTFi.jpg",
    "description": "Мини-сериал о катастрофе, решениях людей и цене молчания.",
    "trailerUrl": "https://www.youtube.com/embed/s9APLXM9Ei8",
    "longDescription": "После взрыва на Чернобыльской АЭС учёные, ликвидаторы и чиновники оказываются перед реальностью, которую нельзя отменить приказом. Сериал показывает не только катастрофу, но и борьбу фактов против страха и политического удобства.",
    "facts": [
      {
        "label": "Год",
        "value": "2019"
      },
      {
        "label": "Тип",
        "value": "Сериал"
      },
      {
        "label": "Страна",
        "value": "США, Великобритания"
      },
      {
        "label": "Длительность",
        "value": "60–72 мин / серия"
      },
      {
        "label": "Студия",
        "value": "HBO, Sky UK"
      },
      {
        "label": "Создатель",
        "value": "Craig Mazin"
      },
      {
        "label": "Настроение",
        "value": "Сдержанно, напряжённо, исторично"
      },
      {
        "label": "Темы",
        "value": "Правда, ответственность, последствия"
      }
    ],
    "cast": [
      {
        "name": "Jared Harris",
        "role": "Валерий Легасов"
      },
      {
        "name": "Stellan Skarsgård",
        "role": "Борис Щербина"
      },
      {
        "name": "Emily Watson",
        "role": "Ульяна Хомюк"
      },
      {
        "name": "Paul Ritter",
        "role": "Анатолий Дятлов"
      },
      {
        "name": "Jessie Buckley",
        "role": "Людмила Игнатенко"
      }
    ],
    players: [
      {
        id: "factorios-1227803",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1227803",
      },
    ],
    "id": 68
  },
  {
    "slug": "sherlock",
    kinopoiskId: 502838,
    "title": "Шерлок",
    "originalTitle": "Sherlock",
    "searchTitles": [
      "шерлок",
      "sherlock",
      "холмс",
      "ватсон"
    ],
    "type": "Сериал",
    "year": "2010",
    "rating": 9.1,
    "genres": [
      "Детектив",
      "Криминал",
      "Драма"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/7WTsnHkbA0FaG6R9twfFde0I9hl.jpg",
    "description": "Современная версия Холмса, где дедукция работает быстрее уведомлений на телефоне.",
    "trailerUrl": "https://www.youtube.com/embed/qlcWFoNqZHc",
    "longDescription": "Шерлок Холмс и доктор Ватсон расследуют дела в современном Лондоне, где классическая дедукция встречается с технологиями, медиа и очень странными преступниками. Сериал делает знакомого героя быстрым, остроумным и опасно наблюдательным.",
    "facts": [
      {
        "label": "Год",
        "value": "2010"
      },
      {
        "label": "Тип",
        "value": "Сериал"
      },
      {
        "label": "Страна",
        "value": "Великобритания"
      },
      {
        "label": "Длительность",
        "value": "около 90 мин / серия"
      },
      {
        "label": "Студия",
        "value": "BBC"
      },
      {
        "label": "Создатели",
        "value": "Steven Moffat, Mark Gatiss"
      },
      {
        "label": "Настроение",
        "value": "Остроумно, детективно, динамично"
      },
      {
        "label": "Темы",
        "value": "Логика, дружба, загадки"
      }
    ],
    "cast": [
      {
        "name": "Benedict Cumberbatch",
        "role": "Шерлок Холмс"
      },
      {
        "name": "Martin Freeman",
        "role": "Джон Ватсон"
      },
      {
        "name": "Andrew Scott",
        "role": "Джим Мориарти"
      },
      {
        "name": "Mark Gatiss",
        "role": "Майкрофт Холмс"
      },
      {
        "name": "Una Stubbs",
        "role": "Миссис Хадсон"
      }
    ],
    players: [
      {
        id: "factorios-502838",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/502838",
      },
    ],
    "id": 69
  },
  {
    "slug": "better-call-saul",
    kinopoiskId: 796660,
    "title": "Лучше звоните Солу",
    "originalTitle": "Better Call Saul",
    "searchTitles": [
      "лучше звоните солу",
      "better call saul",
      "сол гудман",
      "джимми макгилл"
    ],
    "type": "Сериал",
    "year": "2015",
    "rating": 9.0,
    "genres": [
      "Драма",
      "Криминал"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/fC2HDm5t0kHl7mTm7jxMR31b7by.jpg",
    "description": "История превращения Джимми Макгилла в адвоката, которого лучше не недооценивать.",
    "trailerUrl": "https://www.youtube.com/embed/HN4oydykJFc",
    "longDescription": "Джимми Макгилл пытается построить карьеру юриста честно, хитро и иногда слишком творчески. Сериал показывает медленную, точную трансформацию человека, который умеет говорить красиво, но всё чаще выбирает опасные обходные пути.",
    "facts": [
      {
        "label": "Год",
        "value": "2015"
      },
      {
        "label": "Тип",
        "value": "Сериал"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "46–69 мин / серия"
      },
      {
        "label": "Студия",
        "value": "AMC, Sony Pictures Television"
      },
      {
        "label": "Создатели",
        "value": "Vince Gilligan, Peter Gould"
      },
      {
        "label": "Настроение",
        "value": "Медленно, умно, драматично"
      },
      {
        "label": "Темы",
        "value": "Выбор, амбиции, мораль"
      }
    ],
    "cast": [
      {
        "name": "Bob Odenkirk",
        "role": "Джимми Макгилл / Сол Гудман"
      },
      {
        "name": "Rhea Seehorn",
        "role": "Ким Уэкслер"
      },
      {
        "name": "Jonathan Banks",
        "role": "Майк Эрмантраут"
      },
      {
        "name": "Michael McKean",
        "role": "Чак Макгилл"
      },
      {
        "name": "Giancarlo Esposito",
        "role": "Густаво Фринг"
      }
    ],
    players: [
      {
        id: "factorios-796660",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/796660",
      },
    ],
    "id": 70
  },
  {
    "slug": "the-boys",
    kinopoiskId: 460586,
    "title": "Пацаны",
    "originalTitle": "The Boys",
    "searchTitles": [
      "пацаны",
      "the boys",
      "homelander",
      "хоумлендер",
      "супергерои"
    ],
    "type": "Сериал",
    "year": "2019",
    "rating": 8.7,
    "genres": [
      "Экшен",
      "Сатира",
      "Драма",
      "Супергерои"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/stTEycfG9928HYGEISBFaG1ngjM.jpg",
    "description": "Сатирический сериал о мире, где супергерои стали брендами, а бренды — почти властью.",
    "trailerUrl": "https://www.youtube.com/embed/M1bhOaLV4FU",
    "longDescription": "В мире, где супергерои работают на корпорацию и живут как знаменитости, группа обычных людей пытается показать их настоящую сторону. Сериал смешивает экшен, сатиру и мрачный взгляд на культ популярности.",
    "facts": [
      {
        "label": "Год",
        "value": "2019"
      },
      {
        "label": "Тип",
        "value": "Сериал"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "55–68 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Amazon Studios, Sony Pictures Television"
      },
      {
        "label": "Создатель",
        "value": "Eric Kripke"
      },
      {
        "label": "Настроение",
        "value": "Дерзко, сатирично, жёстко"
      },
      {
        "label": "Темы",
        "value": "Власть, медиа, ответственность"
      }
    ],
    "cast": [
      {
        "name": "Karl Urban",
        "role": "Билли Бутчер"
      },
      {
        "name": "Jack Quaid",
        "role": "Хьюи Кэмпбелл"
      },
      {
        "name": "Antony Starr",
        "role": "Хоумлендер"
      },
      {
        "name": "Erin Moriarty",
        "role": "Старлайт"
      },
      {
        "name": "Laz Alonso",
        "role": "Молоко матери"
      }
    ],
    players: [
      {
        id: "factorios-460586",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/460586",
      },
    ],
    "id": 71
  },
  {
    "slug": "peaky-blinders",
    kinopoiskId: 716587,
    "title": "Острые козырьки",
    "originalTitle": "Peaky Blinders",
    "searchTitles": [
      "острые козырьки",
      "peaky blinders",
      "томас шелби",
      "шелби"
    ],
    "type": "Сериал",
    "year": "2013",
    "rating": 8.8,
    "genres": [
      "Криминал",
      "Драма",
      "История"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/vUUqzWa2LnHIVqkaKVlVGkVcZIW.jpg",
    "description": "Криминальная сага о семье Шелби, амбициях и очень опасном стиле.",
    "trailerUrl": "https://www.youtube.com/embed/oVzVdvGIC7U",
    "longDescription": "После Первой мировой войны Томас Шелби превращает семейную банду в растущую силу Бирмингема. В сериале политика, бизнес и криминал идут рядом, а каждый шаг вверх требует новой сделки с совестью.",
    "facts": [
      {
        "label": "Год",
        "value": "2013"
      },
      {
        "label": "Тип",
        "value": "Сериал"
      },
      {
        "label": "Страна",
        "value": "Великобритания"
      },
      {
        "label": "Длительность",
        "value": "55–65 мин / серия"
      },
      {
        "label": "Студия",
        "value": "BBC"
      },
      {
        "label": "Создатель",
        "value": "Steven Knight"
      },
      {
        "label": "Настроение",
        "value": "Стильно, мрачно, криминально"
      },
      {
        "label": "Темы",
        "value": "Семья, власть, амбиции"
      }
    ],
    "cast": [
      {
        "name": "Cillian Murphy",
        "role": "Томас Шелби"
      },
      {
        "name": "Paul Anderson",
        "role": "Артур Шелби"
      },
      {
        "name": "Helen McCrory",
        "role": "Полли Грей"
      },
      {
        "name": "Sophie Rundle",
        "role": "Ада Шелби"
      },
      {
        "name": "Tom Hardy",
        "role": "Альфи Соломонс"
      }
    ],
    players: [
      {
        id: "factorios-716587",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/716587",
      },
    ],
    "id": 72
  },
  {
    "slug": "dark",
    kinopoiskId: 1032606,
    "title": "Тьма",
    "originalTitle": "Dark",
    "searchTitles": [
      "тьма",
      "dark",
      "винден",
      "путешествие во времени"
    ],
    "type": "Сериал",
    "year": "2017",
    "rating": 8.7,
    "genres": [
      "Фантастика",
      "Драма",
      "Детектив"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/apbrbWs8M9lyOpJYU5WXrpFbk1Z.jpg",
    "description": "Немецкая фантастическая загадка, где семейные тайны путаются со временем.",
    "trailerUrl": "https://www.youtube.com/embed/rrwycJ08PSA",
    "longDescription": "В маленьком городе Винден исчезновение ребёнка открывает цепочку событий, связанную с несколькими поколениями. Сериал превращает путешествия во времени в семейный лабиринт, где каждое решение отзывается далеко вперёд и назад.",
    "facts": [
      {
        "label": "Год",
        "value": "2017"
      },
      {
        "label": "Тип",
        "value": "Сериал"
      },
      {
        "label": "Страна",
        "value": "Германия"
      },
      {
        "label": "Длительность",
        "value": "44–73 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Netflix, Wiedemann & Berg"
      },
      {
        "label": "Создатели",
        "value": "Baran bo Odar, Jantje Friese"
      },
      {
        "label": "Настроение",
        "value": "Мрачно, сложно, атмосферно"
      },
      {
        "label": "Темы",
        "value": "Время, семья, судьба"
      }
    ],
    "cast": [
      {
        "name": "Louis Hofmann",
        "role": "Йонас Канвальд"
      },
      {
        "name": "Lisa Vicari",
        "role": "Марта Нильсен"
      },
      {
        "name": "Maja Schöne",
        "role": "Ханна Канвальд"
      },
      {
        "name": "Oliver Masucci",
        "role": "Ульрих Нильсен"
      },
      {
        "name": "Andreas Pietschmann",
        "role": "Незнакомец"
      }
    ],
    players: [
      {
        id: "factorios-1032606",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1032606",
      },
    ],
    "id": 73
  },
  {
    "slug": "the-mandalorian",
    kinopoiskId: 1118138,
    "title": "Мандалорец",
    "originalTitle": "The Mandalorian",
    "searchTitles": [
      "мандалорец",
      "the mandalorian",
      "мандо",
      "гроґу",
      "грогу",
      "baby yoda"
    ],
    "type": "Сериал",
    "year": "2019",
    "rating": 8.7,
    "genres": [
      "Фантастика",
      "Приключения",
      "Экшен"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/sWgBv7LV2PRoQgkxwlibdGXKz1S.jpg",
    "description": "Космический вестерн о наёмнике, который неожиданно получает очень маленькую ответственность.",
    "trailerUrl": "https://www.youtube.com/embed/aOC8E8z_ifw",
    "longDescription": "Одинокий мандалорский охотник за головами выполняет задания на окраинах галактики, пока встреча с загадочным ребёнком не меняет его путь. Сериал соединяет дух приключений, вестерн и мир Star Wars без лишнего шума.",
    "facts": [
      {
        "label": "Год",
        "value": "2019"
      },
      {
        "label": "Тип",
        "value": "Сериал"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "30–50 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Lucasfilm"
      },
      {
        "label": "Создатель",
        "value": "Jon Favreau"
      },
      {
        "label": "Настроение",
        "value": "Приключенчески, космически, спокойно круто"
      },
      {
        "label": "Темы",
        "value": "Защита, честь, путь"
      }
    ],
    "cast": [
      {
        "name": "Pedro Pascal",
        "role": "Дин Джарин / Мандалорец"
      },
      {
        "name": "Grogu",
        "role": "Таинственный ребёнок"
      },
      {
        "name": "Carl Weathers",
        "role": "Гриф Карга"
      },
      {
        "name": "Gina Carano",
        "role": "Кара Дьюн"
      },
      {
        "name": "Giancarlo Esposito",
        "role": "Мофф Гидеон"
      }
    ],
    players: [
      {
        id: "factorios-1118138",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1118138",
      },
    ],
    "id": 74
  },
  {
    "slug": "arcane",
    kinopoiskId: 4445150,
    "title": "Аркейн",
    "originalTitle": "Arcane",
    "searchTitles": [
      "аркейн",
      "arcane",
      "league of legends",
      "джинкс",
      "вай"
    ],
    "type": "Сериал",
    "year": "2021",
    "rating": 9.0,
    "genres": [
      "Анимация",
      "Фэнтези",
      "Драма",
      "Экшен"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/fqldf2t8ztc9aiwn3k6mlX3tvRT.jpg",
    "description": "Анимационная драма о двух городах, двух сёстрах и цене прогресса.",
    "trailerUrl": "https://www.youtube.com/embed/fXmAurh012s",
    "longDescription": "Пилтовер и Заун живут рядом, но разделены статусом, технологиями и обидами. История Вай и Джинкс показывает, как личная травма и политический конфликт могут сломать связь, которая казалась неразрушимой.",
    "facts": [
      {
        "label": "Год",
        "value": "2021"
      },
      {
        "label": "Тип",
        "value": "Сериал"
      },
      {
        "label": "Страна",
        "value": "США, Франция"
      },
      {
        "label": "Длительность",
        "value": "39–44 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Riot Games, Fortiche"
      },
      {
        "label": "Создатели",
        "value": "Christian Linke, Alex Yee"
      },
      {
        "label": "Настроение",
        "value": "Красиво, драматично, зрелищно"
      },
      {
        "label": "Темы",
        "value": "Сёстры, прогресс, раскол"
      }
    ],
    "cast": [
      {
        "name": "Вай",
        "role": "Сильная и упрямая защитница"
      },
      {
        "name": "Джинкс",
        "role": "Хаотичная героиня с болью внутри"
      },
      {
        "name": "Джейс",
        "role": "Изобретатель и политик"
      },
      {
        "name": "Виктор",
        "role": "Учёный, ищущий новый путь"
      },
      {
        "name": "Кейтлин",
        "role": "Следовательница из Пилтовера"
      }
    ],
    players: [
      {
        id: "factorios-4445150",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/4445150",
      },
    ],
    "id": 75
  },
  {
    "slug": "death-note",
    "title": "Тетрадь смерти",
    "originalTitle": "Death Note",
    "searchTitles": [
      "тетрадь смерти",
      "death note",
      "лайт",
      "л",
      "рьюк"
    ],
    "type": "Аниме",
    "year": "2006",
    "rating": 8.9,
    "genres": [
      "Аниме",
      "Триллер",
      "Детектив",
      "Сверхъестественное"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/iigTJJskR1PcjjXqxdyJwVB3BoU.jpg",
    "description": "Интеллектуальная дуэль о школьнике, тетради и власти решать чужие судьбы.",
    "trailerUrl": "https://www.youtube.com/embed/NlJZ-YgAt-c",
    "longDescription": "Лайт Ягами находит тетрадь, способную убивать людей, чьи имена в неё записаны. Его идея справедливости быстро сталкивается с расследованием загадочного L, и история превращается в шахматную партию между двумя гениями.",
    "facts": [
      {
        "label": "Год",
        "value": "2006"
      },
      {
        "label": "Тип",
        "value": "Аниме"
      },
      {
        "label": "Страна",
        "value": "Япония"
      },
      {
        "label": "Длительность",
        "value": "23 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Madhouse"
      },
      {
        "label": "Оригинал",
        "value": "Манга Tsugumi Ohba и Takeshi Obata"
      },
      {
        "label": "Настроение",
        "value": "Напряжённо, интеллектуально, мрачно"
      },
      {
        "label": "Темы",
        "value": "Власть, справедливость, контроль"
      }
    ],
    "cast": [
      {
        "name": "Лайт Ягами",
        "role": "Владелец тетради"
      },
      {
        "name": "L",
        "role": "Гениальный детектив"
      },
      {
        "name": "Рюк",
        "role": "Синигами-наблюдатель"
      },
      {
        "name": "Миса Аманэ",
        "role": "Айдол и союзница Лайта"
      },
      {
        "name": "Соичиро Ягами",
        "role": "Отец Лайта и полицейский"
      }
    ],
    "players": [
      {
        "id": "player-1",
        "name": "Плеер 1",
        "embedUrl": ""
      },
      {
        "id": "player-2",
        "name": "Плеер 2",
        "embedUrl": ""
      },
      {
        "id": "player-3",
        "name": "Плеер 3",
        "embedUrl": ""
      }
    ],
    "id": 76
  },
  {
    "slug": "jujutsu-kaisen",
    "title": "Магическая битва",
    "originalTitle": "Jujutsu Kaisen",
    "searchTitles": [
      "магическая битва",
      "jujutsu kaisen",
      "дзюдзюцу кайсен",
      "юдзи",
      "годжо"
    ],
    "type": "Аниме",
    "year": "2020",
    "rating": 8.6,
    "genres": [
      "Аниме",
      "Экшен",
      "Фэнтези",
      "Сверхъестественное"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/fHpKWq9ayzSk8nSwqRuaAUemRKh.jpg",
    "description": "Динамичное аниме о проклятиях, магии и учениках, которым рано расслабляться.",
    "trailerUrl": "https://www.youtube.com/embed/pkKu9hLT-t8",
    "longDescription": "Юдзи Итадори оказывается связан с могущественным проклятием и поступает в школу магов, где учатся бороться с опасными сущностями. Аниме быстро переключается между юмором, боевой постановкой и серьёзными ставками.",
    "facts": [
      {
        "label": "Год",
        "value": "2020"
      },
      {
        "label": "Тип",
        "value": "Аниме"
      },
      {
        "label": "Страна",
        "value": "Япония"
      },
      {
        "label": "Длительность",
        "value": "24 мин / серия"
      },
      {
        "label": "Студия",
        "value": "MAPPA"
      },
      {
        "label": "Оригинал",
        "value": "Манга Gege Akutami"
      },
      {
        "label": "Настроение",
        "value": "Быстро, эффектно, сверхъестественно"
      },
      {
        "label": "Темы",
        "value": "Дружба, долг, проклятия"
      }
    ],
    "cast": [
      {
        "name": "Юдзи Итадори",
        "role": "Ученик магической школы"
      },
      {
        "name": "Мегуми Фусигуро",
        "role": "Спокойный и сильный маг"
      },
      {
        "name": "Нобара Кугисаки",
        "role": "Уверенная боевая союзница"
      },
      {
        "name": "Сатору Годжо",
        "role": "Наставник с пугающей силой"
      },
      {
        "name": "Сукуна",
        "role": "Король проклятий"
      }
    ],
    "players": [
      {
        "id": "player-1",
        "name": "Плеер 1",
        "embedUrl": ""
      },
      {
        "id": "player-2",
        "name": "Плеер 2",
        "embedUrl": ""
      },
      {
        "id": "player-3",
        "name": "Плеер 3",
        "embedUrl": ""
      }
    ],
    "id": 77
  },
  {
    "slug": "fullmetal-alchemist-brotherhood",
    "title": "Стальной алхимик: Братство",
    "originalTitle": "Fullmetal Alchemist: Brotherhood",
    "searchTitles": [
      "стальной алхимик",
      "fullmetal alchemist",
      "brotherhood",
      "эдвард элрик"
    ],
    "type": "Аниме",
    "year": "2009",
    "rating": 9.1,
    "genres": [
      "Аниме",
      "Приключения",
      "Фэнтези",
      "Драма"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/5ZFUEOULaVml7pQuXxhpR2SmVUw.jpg",
    "description": "История двух братьев, алхимии и закона равноценного обмена.",
    "trailerUrl": "https://www.youtube.com/embed/2uq34TeWEdQ",
    "longDescription": "Эдвард и Альфонс Элрики ищут способ вернуть потерянное после трагического эксперимента. Их путь раскрывает не только правила алхимии, но и большую политическую тайну, где цена силы всегда оказывается личной.",
    "facts": [
      {
        "label": "Год",
        "value": "2009"
      },
      {
        "label": "Тип",
        "value": "Аниме"
      },
      {
        "label": "Страна",
        "value": "Япония"
      },
      {
        "label": "Длительность",
        "value": "24 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Bones"
      },
      {
        "label": "Оригинал",
        "value": "Манга Hiromu Arakawa"
      },
      {
        "label": "Настроение",
        "value": "Эпично, драматично, приключенчески"
      },
      {
        "label": "Темы",
        "value": "Семья, цена силы, искупление"
      }
    ],
    "cast": [
      {
        "name": "Эдвард Элрик",
        "role": "Стальной алхимик"
      },
      {
        "name": "Альфонс Элрик",
        "role": "Брат Эдварда в доспехах"
      },
      {
        "name": "Рой Мустанг",
        "role": "Огненный алхимик"
      },
      {
        "name": "Уинри Рокбелл",
        "role": "Механик и близкая подруга"
      },
      {
        "name": "Скар",
        "role": "Мститель с тяжёлым прошлым"
      }
    ],
    "players": [
      {
        "id": "player-1",
        "name": "Плеер 1",
        "embedUrl": ""
      },
      {
        "id": "player-2",
        "name": "Плеер 2",
        "embedUrl": ""
      },
      {
        "id": "player-3",
        "name": "Плеер 3",
        "embedUrl": ""
      }
    ],
    "id": 78
  },
  {
    "slug": "one-piece",
    "title": "Ван-Пис",
    "originalTitle": "One Piece",
    "searchTitles": [
      "ван пис",
      "ван-пис",
      "one piece",
      "луффи",
      "пираты"
    ],
    "type": "Аниме",
    "year": "1999",
    "rating": 9.0,
    "genres": [
      "Аниме",
      "Приключения",
      "Экшен",
      "Комедия"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/cMD9Ygz11zjJzAovURpO75Qg7rT.jpg",
    "description": "Большое пиратское приключение о мечтах, команде и поиске легендарного сокровища.",
    "trailerUrl": "https://www.youtube.com/embed/S8_YwFLCh4U",
    "longDescription": "Монки Д. Луффи собирает команду, чтобы отправиться к Гранд Лайн и найти сокровище One Piece. За весёлым приключением скрывается огромный мир, где дружба, свобода и мечты важнее любой карты.",
    "facts": [
      {
        "label": "Год",
        "value": "1999"
      },
      {
        "label": "Тип",
        "value": "Аниме"
      },
      {
        "label": "Страна",
        "value": "Япония"
      },
      {
        "label": "Длительность",
        "value": "24 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Toei Animation"
      },
      {
        "label": "Оригинал",
        "value": "Манга Eiichiro Oda"
      },
      {
        "label": "Настроение",
        "value": "Весело, масштабно, приключенчески"
      },
      {
        "label": "Темы",
        "value": "Свобода, дружба, мечта"
      }
    ],
    "cast": [
      {
        "name": "Монки Д. Луффи",
        "role": "Капитан Пиратов Соломенной Шляпы"
      },
      {
        "name": "Ророноа Зоро",
        "role": "Мечник команды"
      },
      {
        "name": "Нами",
        "role": "Навигатор"
      },
      {
        "name": "Санджи",
        "role": "Кок и боец"
      },
      {
        "name": "Усопп",
        "role": "Стрелок и рассказчик"
      }
    ],
    "players": [
      {
        "id": "player-1",
        "name": "Плеер 1",
        "embedUrl": ""
      },
      {
        "id": "player-2",
        "name": "Плеер 2",
        "embedUrl": ""
      },
      {
        "id": "player-3",
        "name": "Плеер 3",
        "embedUrl": ""
      }
    ],
    "id": 79
  },
  {
    "slug": "chainsaw-man",
    "title": "Человек-бензопила",
    "originalTitle": "Chainsaw Man",
    "searchTitles": [
      "человек бензопила",
      "человек-бензопила",
      "chainsaw man",
      "дэнджи",
      "почита"
    ],
    "type": "Аниме",
    "year": "2022",
    "rating": 8.5,
    "genres": [
      "Аниме",
      "Экшен",
      "Фэнтези",
      "Драма"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/npdB6eFzizki0WaZ1OvKcJrWe97.jpg",
    "description": "Безумное и энергичное аниме о парне, демонах и мечте о нормальной жизни.",
    "trailerUrl": "https://www.youtube.com/embed/v4yLeNt-kCU",
    "longDescription": "Дэнджи живёт в долгах и охотится на демонов вместе с Почитой, пока обстоятельства не превращают его в Человека-бензопилу. История сочетает экшен, абсурдный юмор и очень человеческое желание просто жить лучше.",
    "facts": [
      {
        "label": "Год",
        "value": "2022"
      },
      {
        "label": "Тип",
        "value": "Аниме"
      },
      {
        "label": "Страна",
        "value": "Япония"
      },
      {
        "label": "Длительность",
        "value": "24 мин / серия"
      },
      {
        "label": "Студия",
        "value": "MAPPA"
      },
      {
        "label": "Оригинал",
        "value": "Манга Tatsuki Fujimoto"
      },
      {
        "label": "Настроение",
        "value": "Дико, энергично, странно трогательно"
      },
      {
        "label": "Темы",
        "value": "Мечты, выживание, доверие"
      }
    ],
    "cast": [
      {
        "name": "Дэнджи",
        "role": "Парень, ставший Человеком-бензопилой"
      },
      {
        "name": "Почита",
        "role": "Демон-бензопила и друг"
      },
      {
        "name": "Макима",
        "role": "Загадочная руководительница"
      },
      {
        "name": "Аки Хаякава",
        "role": "Охотник на демонов"
      },
      {
        "name": "Пауэр",
        "role": "Демон крови с ярким характером"
      }
    ],
    "players": [
      {
        "id": "player-1",
        "name": "Плеер 1",
        "embedUrl": ""
      },
      {
        "id": "player-2",
        "name": "Плеер 2",
        "embedUrl": ""
      },
      {
        "id": "player-3",
        "name": "Плеер 3",
        "embedUrl": ""
      }
    ],
    "id": 80
  },
  {
    "slug": "cyberpunk-edgerunners",
    "title": "Киберпанк: Бегущие по краю",
    "originalTitle": "Cyberpunk: Edgerunners",
    "searchTitles": [
      "киберпанк",
      "cyberpunk edgerunners",
      "бегущие по краю",
      "дэвид мартинес"
    ],
    "type": "Аниме",
    "year": "2022",
    "rating": 8.6,
    "genres": [
      "Аниме",
      "Фантастика",
      "Экшен",
      "Драма"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/7jSWOc6jWSw5hZ78HB8Hw3pJxuk.jpg",
    "description": "Неоновая история Найт-Сити о скорости, мечтах и цене улучшений.",
    "trailerUrl": "https://www.youtube.com/embed/JtqIas3bYhg",
    "longDescription": "Дэвид Мартинес попадает в мир наёмников, имплантов и больших рисков. Найт-Сити обещает быстрый подъём, но каждая новая возможность там почти всегда требует слишком дорогой оплаты.",
    "facts": [
      {
        "label": "Год",
        "value": "2022"
      },
      {
        "label": "Тип",
        "value": "Аниме"
      },
      {
        "label": "Страна",
        "value": "Япония, Польша"
      },
      {
        "label": "Длительность",
        "value": "24–27 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Studio Trigger, CD Projekt Red"
      },
      {
        "label": "Основа",
        "value": "Вселенная Cyberpunk 2077"
      },
      {
        "label": "Настроение",
        "value": "Неоново, быстро, трагично"
      },
      {
        "label": "Темы",
        "value": "Амбиции, город, цена силы"
      }
    ],
    "cast": [
      {
        "name": "Дэвид Мартинес",
        "role": "Парень, который хочет вырваться выше"
      },
      {
        "name": "Люси",
        "role": "Нетраннер и ключевая союзница"
      },
      {
        "name": "Мэйн",
        "role": "Лидер команды"
      },
      {
        "name": "Ребекка",
        "role": "Боевая и резкая участница команды"
      },
      {
        "name": "Киви",
        "role": "Опытная нетраннерша"
      }
    ],
    "players": [
      {
        "id": "player-1",
        "name": "Плеер 1",
        "embedUrl": ""
      },
      {
        "id": "player-2",
        "name": "Плеер 2",
        "embedUrl": ""
      },
      {
        "id": "player-3",
        "name": "Плеер 3",
        "embedUrl": ""
      }
    ],
    "id": 81
  },
  {
    "slug": "vinland-saga",
    "title": "Сага о Винланде",
    "originalTitle": "Vinland Saga",
    "searchTitles": [
      "сага о винланде",
      "vinland saga",
      "торфинн",
      "викинги"
    ],
    "type": "Аниме",
    "year": "2019",
    "rating": 8.8,
    "genres": [
      "Аниме",
      "История",
      "Драма",
      "Приключения"
    ],
    "poster": "https://images.kinorium.com/movie/poster/2060815/w1500_51470371.jpg",
    "description": "Историческая аниме-драма о мести, взрослении и поиске настоящей свободы.",
    "trailerUrl": "https://www.youtube.com/embed/f8JrZ7Q_p-8",
    "longDescription": "Торфинн растёт в мире викингов, войн и личной мести. Но чем дальше идёт его путь, тем сильнее история смещается от битв к вопросу: что значит жить свободно и не повторять круг насилия.",
    "facts": [
      {
        "label": "Год",
        "value": "2019"
      },
      {
        "label": "Тип",
        "value": "Аниме"
      },
      {
        "label": "Страна",
        "value": "Япония"
      },
      {
        "label": "Длительность",
        "value": "24 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Wit Studio, MAPPA"
      },
      {
        "label": "Оригинал",
        "value": "Манга Makoto Yukimura"
      },
      {
        "label": "Настроение",
        "value": "Сурово, исторично, драматично"
      },
      {
        "label": "Темы",
        "value": "Месть, свобода, взросление"
      }
    ],
    "cast": [
      {
        "name": "Торфинн",
        "role": "Юный воин, ищущий свой путь"
      },
      {
        "name": "Аскеладд",
        "role": "Хитрый лидер наёмников"
      },
      {
        "name": "Торс",
        "role": "Отец Торфинна"
      },
      {
        "name": "Кнуд",
        "role": "Принц с непростой судьбой"
      },
      {
        "name": "Торкель",
        "role": "Сильнейший воин и любитель битв"
      }
    ],
    "players": [
      {
        "id": "player-1",
        "name": "Плеер 1",
        "embedUrl": ""
      },
      {
        "id": "player-2",
        "name": "Плеер 2",
        "embedUrl": ""
      },
      {
        "id": "player-3",
        "name": "Плеер 3",
        "embedUrl": ""
      }
    ],
    "id": 82
  },
  {
    "slug": "cowboy-bebop",
    "title": "Ковбой Бибоп",
    "originalTitle": "Cowboy Bebop",
    "searchTitles": [
      "ковбой бибоп",
      "cowboy bebop",
      "спайк",
      "джаз",
      "космос"
    ],
    "type": "Аниме",
    "year": "1998",
    "rating": 8.9,
    "genres": [
      "Аниме",
      "Фантастика",
      "Приключения",
      "Драма"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/xDiXDfZwC6XYC6fxHI1jl3A3Ill.jpg",
    "description": "Космический нуар с джазом, охотниками за головами и прошлым, от которого не улететь.",
    "trailerUrl": "https://www.youtube.com/embed/RI08P5SaJNU",
    "longDescription": "Экипаж корабля Bebop берётся за разные задания по всей Солнечной системе. За лёгким стилем и музыкой скрываются одиночество, старые ошибки и истории людей, которые постоянно пытаются догнать завтрашний день.",
    "facts": [
      {
        "label": "Год",
        "value": "1998"
      },
      {
        "label": "Тип",
        "value": "Аниме"
      },
      {
        "label": "Страна",
        "value": "Япония"
      },
      {
        "label": "Длительность",
        "value": "24 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Sunrise"
      },
      {
        "label": "Режиссёр",
        "value": "Shinichirō Watanabe"
      },
      {
        "label": "Настроение",
        "value": "Стильно, джазово, меланхолично"
      },
      {
        "label": "Темы",
        "value": "Прошлое, свобода, одиночество"
      }
    ],
    "cast": [
      {
        "name": "Спайк Шпигель",
        "role": "Охотник за головами с прошлым"
      },
      {
        "name": "Джет Блэк",
        "role": "Капитан Bebop"
      },
      {
        "name": "Фэй Валентайн",
        "role": "Авантюристка с долгами"
      },
      {
        "name": "Эд",
        "role": "Гениальная хакерша"
      },
      {
        "name": "Эйн",
        "role": "Очень умный пёс"
      }
    ],
    "players": [
      {
        "id": "player-1",
        "name": "Плеер 1",
        "embedUrl": ""
      },
      {
        "id": "player-2",
        "name": "Плеер 2",
        "embedUrl": ""
      },
      {
        "id": "player-3",
        "name": "Плеер 3",
        "embedUrl": ""
      }
    ],
    "id": 83
  },
  {
    "slug": "kung-fu-panda",
    kinopoiskId: 103734,
    "title": "Кунг-фу Панда",
    "originalTitle": "Kung Fu Panda",
    "searchTitles": [
      "кунг фу панда",
      "kung fu panda",
      "по",
      "панда"
    ],
    "type": "Мультфильм",
    "year": "2008",
    "rating": 7.6,
    "genres": [
      "Анимация",
      "Комедия",
      "Приключения",
      "Семейный"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/wWt4JYXTg5Wr3xBW2phBrMKgp3x.jpg",
    "description": "История ленивого мечтателя По, который внезапно получает шанс стать воином.",
    "trailerUrl": "https://www.youtube.com/embed/PXi3Mv6KMzY",
    "longDescription": "По обожает лапшу и кунг-фу, но сам не похож на легендарного героя. Когда его неожиданно выбирают Воином Дракона, ему приходится доказать, что сила может прятаться там, где её никто не ищет.",
    "facts": [
      {
        "label": "Год",
        "value": "2008"
      },
      {
        "label": "Тип",
        "value": "Мультфильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "92 мин"
      },
      {
        "label": "Студия",
        "value": "DreamWorks Animation"
      },
      {
        "label": "Режиссёры",
        "value": "John Stevenson, Mark Osborne"
      },
      {
        "label": "Настроение",
        "value": "Весело, тепло, боевито"
      },
      {
        "label": "Темы",
        "value": "Самопринятие, вера, мастерство"
      }
    ],
    "cast": [
      {
        "name": "По",
        "role": "Панда, который мечтает о кунг-фу"
      },
      {
        "name": "Шифу",
        "role": "Строгий наставник"
      },
      {
        "name": "Тигрица",
        "role": "Сильная участница Пятёрки"
      },
      {
        "name": "Тай Лунг",
        "role": "Опасный противник"
      },
      {
        "name": "Мастер Угвей",
        "role": "Мудрый учитель"
      }
    ],
    players: [
      {
        id: "factorios-103734",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/103734",
      },
    ],
    "id": 84
  },
  {
    "slug": "zootopia",
    kinopoiskId: 775276,
    "title": "Зверополис",
    "originalTitle": "Zootopia",
    "searchTitles": [
      "зверополис",
      "zootopia",
      "зутопия",
      "джуди хоппс",
      "ник уайлд"
    ],
    "type": "Мультфильм",
    "year": "2016",
    "rating": 8.0,
    "genres": [
      "Анимация",
      "Комедия",
      "Приключения",
      "Детектив"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/hlK0e0wAQ3VLuJcsfIYPvb4JVud.jpg",
    "description": "Детективная история в городе животных, где маленькая крольчиха берётся за большое дело.",
    "trailerUrl": "https://www.youtube.com/embed/jWM0ct-OLsM",
    "longDescription": "Джуди Хоппс приезжает в Зверополис, чтобы стать настоящим полицейским, но быстро понимает: мечта требует больше, чем энтузиазм. Вместе с хитрым Ником Уайлдом она расследует дело, которое меняет взгляд города на самого себя.",
    "facts": [
      {
        "label": "Год",
        "value": "2016"
      },
      {
        "label": "Тип",
        "value": "Мультфильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "108 мин"
      },
      {
        "label": "Студия",
        "value": "Walt Disney Animation Studios"
      },
      {
        "label": "Режиссёры",
        "value": "Byron Howard, Rich Moore"
      },
      {
        "label": "Настроение",
        "value": "Ярко, смешно, детективно"
      },
      {
        "label": "Темы",
        "value": "Предрассудки, дружба, смелость"
      }
    ],
    "cast": [
      {
        "name": "Джуди Хоппс",
        "role": "Крольчиха-полицейская"
      },
      {
        "name": "Ник Уайлд",
        "role": "Хитрый лис и неожиданный напарник"
      },
      {
        "name": "Буйволсон",
        "role": "Начальник полиции"
      },
      {
        "name": "Газелле",
        "role": "Поп-звезда города"
      },
      {
        "name": "Леодор Златогрив",
        "role": "Мэр Зверополиса"
      }
    ],
    players: [
      {
        id: "factorios-775276",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/775276",
      },
    ],
    "id": 85
  },
  {
    "slug": "moana",
    kinopoiskId: 837530,
    "title": "Моана",
    "originalTitle": "Moana",
    "searchTitles": [
      "моана",
      "moana",
      "мауи",
      "океан"
    ],
    "type": "Мультфильм",
    "year": "2016",
    "rating": 7.6,
    "genres": [
      "Анимация",
      "Приключения",
      "Семейный",
      "Музыка"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/4JeejGugONWpJkbnvL12hVoYEDa.jpg",
    "description": "Музыкальное приключение о девушке, океане и поиске своего пути.",
    "trailerUrl": "https://www.youtube.com/embed/LKFuXETZUsI",
    "longDescription": "Моана отправляется за риф, чтобы спасти свой остров и понять, кем она хочет быть. На пути ей помогает полубог Мауи, а главным наставником становится сам океан — довольно нестандартный, но эффектный коуч.",
    "facts": [
      {
        "label": "Год",
        "value": "2016"
      },
      {
        "label": "Тип",
        "value": "Мультфильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "107 мин"
      },
      {
        "label": "Студия",
        "value": "Walt Disney Animation Studios"
      },
      {
        "label": "Режиссёры",
        "value": "Ron Clements, John Musker"
      },
      {
        "label": "Настроение",
        "value": "Ярко, музыкально, приключенчески"
      },
      {
        "label": "Темы",
        "value": "Семья, путь, смелость"
      }
    ],
    "cast": [
      {
        "name": "Моана",
        "role": "Дочь вождя и будущая путешественница"
      },
      {
        "name": "Мауи",
        "role": "Полубог с большим эго"
      },
      {
        "name": "Тала",
        "role": "Бабушка Моаны"
      },
      {
        "name": "Таматоа",
        "role": "Краб, который слишком любит блеск"
      },
      {
        "name": "Океан",
        "role": "Самый водный помощник"
      }
    ],
    players: [
      {
        id: "factorios-837530",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/837530",
      },
    ],
    "id": 86
  },
  {
    "slug": "the-incredibles",
    kinopoiskId: 38903,
    "title": "Суперсемейка",
    "originalTitle": "The Incredibles",
    "searchTitles": [
      "суперсемейка",
      "the incredibles",
      "мистер исключительный",
      "pixar"
    ],
    "type": "Мультфильм",
    "year": "2004",
    "rating": 8.0,
    "genres": [
      "Анимация",
      "Экшен",
      "Комедия",
      "Семейный"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/2LqaLgk4Z226KkgPJuiOQ58wvrm.jpg",
    "description": "Семейная супергеройская история о том, что спасать мир проще, когда дома есть поддержка.",
    "trailerUrl": "https://www.youtube.com/embed/-UaGUdNJdRQ",
    "longDescription": "Семья Парр пытается жить обычной жизнью после запрета супергероев, но прошлое и новые угрозы быстро возвращают их в дело. Мультфильм смешивает экшен, семейную драму и отличный ретро-стиль.",
    "facts": [
      {
        "label": "Год",
        "value": "2004"
      },
      {
        "label": "Тип",
        "value": "Мультфильм"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "115 мин"
      },
      {
        "label": "Студия",
        "value": "Pixar Animation Studios"
      },
      {
        "label": "Режиссёр",
        "value": "Brad Bird"
      },
      {
        "label": "Настроение",
        "value": "Динамично, семейно, супергеройски"
      },
      {
        "label": "Темы",
        "value": "Семья, принятие, команда"
      }
    ],
    "cast": [
      {
        "name": "Боб Парр",
        "role": "Мистер Исключительный"
      },
      {
        "name": "Хелен Парр",
        "role": "Эластика"
      },
      {
        "name": "Виолетта",
        "role": "Дочь с силовыми полями"
      },
      {
        "name": "Шастик",
        "role": "Очень быстрый сын"
      },
      {
        "name": "Синдром",
        "role": "Злодей с обидой и гаджетами"
      }
    ],
    players: [
      {
        id: "factorios-38903",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/38903",
      },
    ],
    "id": 87
  },
  {
    "slug": "cosmos-a-spacetime-odyssey",
    kinopoiskId: 762381,
    "title": "Космос: Пространство и время",
    "originalTitle": "Cosmos: A Spacetime Odyssey",
    "searchTitles": [
      "космос пространство и время",
      "cosmos",
      "нил деграсс тайсон",
      "документальный космос"
    ],
    "type": "Документальный",
    "year": "2014",
    "rating": 9.3,
    "genres": [
      "Документальный",
      "Наука",
      "Космос"
    ],
    "poster": "https://kinogo.online/uploads/posts/2021-03/1615665601-1144240884.jpg",
    "description": "Документальное путешествие по Вселенной, науке и месту человека в огромном космосе.",
    "trailerUrl": "https://www.youtube.com/embed/XFF2ECZ8m1A",
    "longDescription": "Нил Деграсс Тайсон ведёт зрителя через историю науки, строение Вселенной и идеи, которые изменили наше понимание мира. Проект объясняет сложные вещи через визуальные образы и чувство удивления.",
    "facts": [
      {
        "label": "Год",
        "value": "2014"
      },
      {
        "label": "Тип",
        "value": "Документальный"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "около 44 мин / серия"
      },
      {
        "label": "Студия",
        "value": "Cosmos Studios, Fuzzy Door Productions"
      },
      {
        "label": "Ведущий",
        "value": "Neil deGrasse Tyson"
      },
      {
        "label": "Настроение",
        "value": "Познавательно, красиво, масштабно"
      },
      {
        "label": "Темы",
        "value": "Космос, наука, история идей"
      }
    ],
    "cast": [
      {
        "name": "Neil deGrasse Tyson",
        "role": "Ведущий"
      },
      {
        "name": "Ann Druyan",
        "role": "Автор и продюсер"
      },
      {
        "name": "Carl Sagan",
        "role": "Духовное наследие проекта"
      },
      {
        "name": "Корабль воображения",
        "role": "Визуальный проводник"
      },
      {
        "name": "Вселенная",
        "role": "Главная тема"
      }
    ],
    players: [
      {
        id: "factorios-762381",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/762381",
      },
    ],
    "id": 88
  },
    {
    "slug": "the-last-dance",
    kinopoiskId: 1162628,
    "title": "Последний танец",
    "originalTitle": "The Last Dance",
    "searchTitles": [
      "последний танец",
      "the last dance",
      "майкл джордан",
      "chicago bulls"
    ],
    "type": "Документальный",
    "year": "2020",
    "rating": 9.1,
    "genres": [
      "Документальный",
      "Спорт",
      "Биография"
    ],
    "poster": "https://image.tmdb.org/t/p/w500/zU0htwkhNvBQdVSIKB9s6hgVeFK.jpg",
    "description": "Документальный сериал о Майкле Джордане, Chicago Bulls и сезоне, ставшем легендой.",
    "trailerUrl": "https://www.youtube.com/embed/N9Z9JtNcCWY",
    "longDescription": "Проект возвращает зрителя в финальный чемпионский сезон Chicago Bulls и показывает, как строилась одна из самых известных спортивных династий. Это история таланта, давления, лидерства и команды, которая стала символом эпохи.",
    "facts": [
      {
        "label": "Год",
        "value": "2020"
      },
      {
        "label": "Тип",
        "value": "Документальный"
      },
      {
        "label": "Страна",
        "value": "США"
      },
      {
        "label": "Длительность",
        "value": "около 50 мин / серия"
      },
      {
        "label": "Студия",
        "value": "ESPN Films, Netflix"
      },
      {
        "label": "Режиссёр",
        "value": "Jason Hehir"
      },
      {
        "label": "Настроение",
        "value": "Динамично, спортивно, ностальгично"
      },
      {
        "label": "Темы",
        "value": "Лидерство, команда, победа"
      }
    ],
    "cast": [
      {
        "name": "Michael Jordan",
        "role": "Главный герой"
      },
      {
        "name": "Scottie Pippen",
        "role": "Игрок Chicago Bulls"
      },
      {
        "name": "Dennis Rodman",
        "role": "Игрок Chicago Bulls"
      },
      {
        "name": "Phil Jackson",
        "role": "Тренер"
      },
      {
        "name": "Chicago Bulls",
        "role": "Команда эпохи"
      }
    ],
    players: [
      {
        id: "factorios-1162628",
        name: "Основной",
        embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1162628",
      },
    ],
    "id": 90
  },
    {
      id: 92,
      kinopoiskId: 826050,
      slug: "scorpion",
      title: "Скорпион",
      originalTitle: "Scorpion",
      searchTitles: ["Скорпион", "Scorpion"],
      type: "Сериал",
      year: "2014 - 2018",
      rating: 7,
      genres: [
        "Боевик",
        "Триллер",
        "Драма",
        "Криминал",
      ],
      poster: "https://kinopoisk-ru.clstorage.net/2a95Th371/ce5fd6dh031/9C3Jy3slmvceAtTBAgdMaA3T7Ev5QhuB-Qxj2-8i3oj_tcRKPTkOiHomYozQy71zd3cihjkMsqduTj_qGBXe5XT-yNyp4s1iCZAGQQFSDe9IEDsbfJAOEP5ItI046RKC8z-Yw7LzBoNid_EcFtxqZqdnNQQ9GvSiq9KxbAxZjfv67oeKsX0S_BHTGEWJRI_lFJRnTKlF1gbrDKFVoKPeDrG710s4O81A6HAy3QfU6SfnpzoOvdSsrKrYv_DIUgV5fOWEQz0yH_WQ1NPJy04LL9JTZI3vDZEBa4ujnWqgnoa9eZPIPLvGAms5t5fDVCtl5uBwgnXbJe6qE300QtbJOXzmT4-8_lO-kVXeRw-LR2ySUywL4cJYBuoK494laJiOfjlURfO9S0Gqdz3ZSNDor6VvfMR1nK1nLl7wOUMcBnl2KULD939a9d4amkrASwXmUpIjhCgOXE7mQqgb6KYcBvq620W1_8fB6zdx3cdVoWEv6TqPNJLpaCYX_3ZO1QQ9vm5LQn-3Uz_QGt4MRA2Nahsb44ciBt7Eaw2gEuCikwQw_t5OeP1CCKVzfZkGWiohrWb7TT2Zr6tuFnK6DthLsjjsDM6_vJF3FFyZTwxECK1cHeQCKUcfRisFKd2lJdeLN3TSwP-zzUxsv7GZDtVsL6Hju040kimurtR0eEUfTXl-pkoLfjXSeljc2EHDxYlgFZzgwurGnMFpAK2TLKoYALp1XoS2tA-L7_rwEk0YoGxtr78DvBElr-dVsv-F2U30seLLQ3-_EPyfEBdDC0QE7Z_Z4Mqny1FCo0fiEqhvU8-wtFQFNjtOjGf69pFBH2zk5GW3jjhSIihsX754z5HB8njhgs97Nxo3FliWTQWFRaTQHGiNIgZbCWiOa1OpppRCPv9UA77wTovjdH7Xg1-kZGio-Mv7GarqJBl4PQrViXx1qsnJ-zqVMBqZEI2IS4fqnFknj-_Jm4hjhi-UKOYeQHm2nI1-Oc5CobQ52AdSqGOlbv2E81xuaqXZ9blLmUe-ce2LAfZymnpR3deCAk6AZ94Sro0kiVCAKcSs1Knj2Mu595WCunDHgqe-MpxF36nnZu2_C_pV5uotEXC6SxlOsLpug8e-MtL1XtCbBEfLxiBbFW2Pow-eAOrML9Zna5cIeHmSSju7QUKoM33TwNij4KYqfgu7niqoL9x_cExWzvRwKkoKNnfa8B-bGMLDB0xi0hPvhSnPEIXjg2NSKmvVhrYz20s_8EZPbPg4FUNd6i3sKjpPvRNn5qJdtHXOkAl0N6yPzfM23XyTnNYIRwyHJZSSbsVsB9SBZo7iEeeum0r-P9UNcjpNBKLxv90DGCLtp-02AvAeYmukl7T1i1FHcXyjREb_upT0W9sQQwUKRqxV2ibDYAsXyGwGJVRt4JwLM76ey7N5jUJrOTeaBhXr5C6nfcq80OqgZBYw90XYDTL46EwF8XBbfZJQ38iJQgOiH5Pow6INX8YnCKCVZqqVhv73Uwq3dc5JYrq-mAncomQh7vsPPBrtJOYfPvgL0c929aCAQ_n3Wn8QGZECyAvE7d4cJYjiyZJI4UCsFewmFgj989sL_fyFxOP3-FEO2KPnZGD_ijuTLagjm3OxC1HPePXhz4xzvtpyFtxcycrNS6IXXmXELkJShGcAqFXh5xsKMrZTDTg3zMUlvneUSVfubOTptoVwWeznKxb8uEyfQz147IOKsfdbNR_VVkpExY6sHdvuC6AGU4avAuBYJCMZiD111o78uMIFKLn-F4maa-ahaX6D_5VmZC_dv7TOHwmzcCbAxLy6GvhSF1cJiczE4xUUKAVnDlfBaMrsm6fmWYf_OZeFdvWKh2pwPhxNEqKv524_RDRcKusvWXi3y55IOzStC4M58ts8mZfazIWCwWSfnG3CZ0ebBqPLpFToIpQO-LWbizrygcFpsPASTltlaWihP8t8UKpm71Y9sYjfTj34LIyMcnPc8xPU28uFC4ijFNXozKlN2k6rx2pR4CIXyjZ9GoH8P0WAIvl2EUSfrajmbrfCPZDiYGyX9neGlYd1-usNRPa1Ev1fEpDLQsDOrBzUpkwmCdEN6MTk0-3n0QO29FfDPDDFx6y5uZKE0ujpr-v_yvBRb67j3Dq-wlEMNDBkC0l6fZtykRNbCE2EDyOcUyfIrgiUTywPYRLgIFnM-nOciTBxjkIr-HjTjNUtZqjgdEa0niNn5lZ79EwYTji6LoXJvLLTfBeZ2cGEBo3m0NJtwKLPl8LnBSVY7SJWw3B0l80yugoN7Hp3HcDWIWAtLz5L-1wmr6bUsD1FGE_2MiXIBPo8kLUf05ZPA8yBapvWbUUuQdBG50ovkOYikcvz_luK_TXJxeU5uFLOGivo6OY-SnTSK-8mHDJ3AhmOs_itD4I0uFx4UlcTicFCyGCXla7Lp8rUSuePodImr1dJ-_MTBPI3DAcn8T1fR9Xjo6Zm_QXyWurtb5k1f8RSjHJ14ceF_DqUdZOXGcULTQlmXFEkj-cCV89hwyOe56YTQXqynMM8eEYIa_j8lQBUoixtKTKN_FIn7mzVu34FmgP8eS3Ij3w4VX2SHBkMyU2JIJRcZABuydNB50AoWeFol0w48xbL8DWOhaI5_1FO0KptaSvzS3Kbqatlk_cwAh1AMvypR417fZf2nFhXS48EjCBSWmBC70ETRC-HJVztqFiJc7sSwXA9zcvkNvgcRFSibG_htwp_1iyv4ln_OExeTHzyJAzKu_OYf5RTXgNLigkvlNZkRW6CGwLvCiTRoupUSjKyFgg2-MuKozvx1YETZOBnrz8AMpYmoKCc_HFFUE-492RFS_I4FbRQkRfAQgcArROaaQ9jyJBGIM3j2KQtH8kyMpOCt7kHhKyzNB-AV2EhZ651Q7IeqWdsVPY0ih7Msr_tg84081z8Ud_ZzIQNhqXaEK6MKgKbjq5CZ9Am6hxBNj_dgbSwggsv-Xndg1PqqahgNwO41q5oKw",
      posterFallbacks: [],
      description: "Динамичный сериал о команде гениальных специалистов, которые решают самые опасные и сложные кризисы для правительства и обычных людей, используя интеллект там, где бессильны обычные методы.",
      trailerUrl: "https://www.youtube.com/watch?v=vkQo84TxzHA",
      longDescription: "«Скорпион» — сериал 2014 - 2018 года в жанрах Боевик, Триллер, Драма, где динамичный сериал о команде гениальных специалистов, которые решают самые опасные и сложные кризисы для правительства и обычных людей, используя интеллект там, где бессильны обычные методы. Захватывающий американский сериал в жанре драмы, боевика и техно-триллера о команде выдающихся гениев во главе с Уолтером О’Брайеном, обладающим одним из самых высоких IQ в мире. Вместе они работают на правительство США и берутся за самые сложные и опасные миссии: предотвращают кибератаки, спасают людей во время катастроф, взломов, авиакризисов и международных угроз.",
      facts: [
        { label: "Год", value: "2014 - 2018" },
        { label: "Тип", value: "Сериал" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "43 Минуты серия" },
        { label: "Студия", value: "CBS Television Studios" },
        { label: "Режиссёр", value: "Сэм Хилл" },
      ],
      cast: [
        { name: "Elyes Gabel", role: "Уолтер О’Брайен" },
        { name: "Katharine McPhee", role: "Пейдж Динин" },
        { name: "Eddie Kaye Thomas", role: "Тоби Кёртис" },
        { name: "Jadyn Wong", role: "Хэппи Куинн" },
        { name: "Ari Stidham", role: "Сильвестр Додд" },
        { name: "Robert Patrick", role: "Кэб Галло" },
        { name: "Riley B. Smith", role: "Ральф Динин" },
      ],
      players: [
        {
          id: "factorios-826050",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/826050",
        },
      ],
    },
  {
      id: 93,
      kinopoiskId: 1008444,
      slug: "deadpool-and-wolverine",
      title: "Дэдпул и Росомаха",
      originalTitle: "Deadpool & Wolverine",
      searchTitles: ["дэдпул", "дедпул", "росомаха", "wolverine", "deadpool", "deadpool and wolverine"],
      type: "Фильм",
      year: "2024",
      rating: 7.6,
      genres: ["Экшен", "Комедия", "Фантастика"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/4/4c/Deadpool_%26_Wolverine_poster.jpg/250px-Deadpool_%26_Wolverine_poster.jpg",
      description: "Дэдпул и Росомаха в шумном, дерзком супергеройском приключении.",
      trailerUrl: "https://www.youtube.com/embed/73_1biulkYk",
      longDescription:
        "«Дэдпул и Росомаха» — фильм 2024 года в жанрах Экшен, Комедия, Фантастика, где дэдпул и Росомаха в шумном, дерзком супергеройском приключении. Уэйд Уилсон пытается жить спокойнее, но судьба снова тащит его в хаос мультивселенной. Вместе с Логаном ему приходится пройти через опасную миссию, где шутки, когти и разрушенные планы идут строго по расписанию. Работа Shawn Levy и команды Marvel Studios, Maximum Effort, 21 Laps Entertainment чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "128 мин" },
        { label: "Студия", value: "Marvel Studios, Maximum Effort, 21 Laps Entertainment" },
        { label: "Дистрибьютор", value: "Walt Disney Studios Motion Pictures" },
        { label: "Режиссёр", value: "Shawn Levy" },
        { label: "Вселенная", value: "Marvel Cinematic Universe" },
      ],
      cast: [
        { name: "Ryan Reynolds", role: "Уэйд Уилсон / Дэдпул" },
        { name: "Hugh Jackman", role: "Логан / Росомаха" },
        { name: "Emma Corrin", role: "Кассандра Нова" },
        { name: "Matthew Macfadyen", role: "Мистер Парадокс" },
        { name: "Morena Baccarin", role: "Ванесса" },
        { name: "Rob Delaney", role: "Питер" },
      ],
      players: [
        {
          id: "factorios-1008444",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1008444",
        },
      ],
    },
  {
      id: 94,
      kinopoiskId: 1338024,
      slug: "kingdom-of-the-planet-of-the-apes",
      title: "Планета обезьян: Новое царство",
      originalTitle: "Kingdom of the Planet of the Apes",
      searchTitles: ["планета обезьян", "новое царство", "обезьяны", "kingdom of the planet of the apes"],
      type: "Фильм",
      year: "2024",
      rating: 6.9,
      genres: ["Фантастика", "Экшен", "Приключения"],
      poster: "https://upload.wikimedia.org/wikipedia/en/c/cf/Kingdom_of_the_Planet_of_the_Apes_poster.jpg",
      description: "Новая глава мира, где наследие Цезаря стало легендой.",
      trailerUrl: "https://www.youtube.com/embed/XtFI7SNtVpY",
      longDescription:
        "«Планета обезьян: Новое царство» — фильм 2024 года в жанрах Фантастика, Экшен, Приключения, где новая глава мира, где наследие Цезаря стало легендой. Спустя поколения после правления Цезаря молодой Ноа отправляется в путь, который заставляет его иначе взглянуть на прошлое обезьян и людей. Новый лидер пытается построить империю, а герои ищут правду среди руин старого мира. Работа Wes Ball и команды 20th Century Studios, Oddball Entertainment чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "145 мин" },
        { label: "Студия", value: "20th Century Studios, Oddball Entertainment" },
        { label: "Дистрибьютор", value: "20th Century Studios" },
        { label: "Режиссёр", value: "Wes Ball" },
        { label: "Серия", value: "Planet of the Apes" },
      ],
      cast: [
        { name: "Owen Teague", role: "Ноа" },
        { name: "Freya Allan", role: "Мэй" },
        { name: "Kevin Durand", role: "Проксимус Цезарь" },
        { name: "Peter Macon", role: "Рака" },
        { name: "William H. Macy", role: "Треватан" },
      ],
      players: [
        {
          id: "factorios-1338024",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1338024",
        },
      ],
    },
  {
      id: 95,
      kinopoiskId: 927494,
      slug: "bad-boys-ride-or-die",
      title: "Плохие парни до конца",
      originalTitle: "Bad Boys: Ride or Die",
      searchTitles: ["плохие парни", "плохие парни до конца", "bad boys", "ride or die"],
      type: "Фильм",
      year: "2024",
      rating: 6.5,
      genres: ["Экшен", "Комедия", "Криминал"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/8/8b/Bad_Boys_Ride_or_Die_%282024%29_poster.jpg/250px-Bad_Boys_Ride_or_Die_%282024%29_poster.jpg",
      description: "Майами, напарники и дело, где отступать уже поздно.",
      trailerUrl: "https://www.youtube.com/embed/hRFY_Fesa9Q",
      longDescription:
        "«Плохие парни до конца» — фильм 2024 года в жанрах Экшен, Комедия, Криминал, где майами, напарники и дело, где отступать уже поздно. Майк Лоури и Маркус Бёрнетт снова оказываются в эпицентре опасного расследования. Когда прошлое их команды ставят под сомнение, старым напарникам приходится действовать быстро, громко и очень по-плохому. Работа Adil El Arbi, Bilall Fallah и команды Columbia Pictures, Westbrook Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "115 мин" },
        { label: "Студия", value: "Columbia Pictures, Westbrook Studios" },
        { label: "Дистрибьютор", value: "Sony Pictures Releasing" },
        { label: "Режиссёры", value: "Adil El Arbi, Bilall Fallah" },
        { label: "Настроение", value: "Динамично, криминально, иронично" },
      ],
      cast: [
        { name: "Will Smith", role: "Майк Лоури" },
        { name: "Martin Lawrence", role: "Маркус Бёрнетт" },
        { name: "Vanessa Hudgens", role: "Келли" },
        { name: "Alexander Ludwig", role: "Дорн" },
        { name: "Paola Núñez", role: "Рита Секада" },
        { name: "Eric Dane", role: "Макграт" },
      ],
      players: [
        {
          id: "factorios-927494",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/927494",
        },
      ],
    },
  {
      id: 96,
      kinopoiskId: 535243,
      slug: "the-fall-guy",
      title: "Каскадёры",
      originalTitle: "The Fall Guy",
      searchTitles: ["каскадеры", "каскадёры", "the fall guy", "фол гай"],
      type: "Фильм",
      year: "2024",
      rating: 6.9,
      genres: ["Экшен", "Комедия", "Романтика"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/1/1f/The_Fall_Guy_%282024%29_poster.jpg/250px-The_Fall_Guy_%282024%29_poster.jpg",
      description: "Каскадёр возвращается на съёмки и случайно попадает в заговор.",
      trailerUrl: "https://www.youtube.com/embed/j7jPnwVGdZ8",
      longDescription:
        "«Каскадёры» — фильм 2024 года в жанрах Экшен, Комедия, Романтика, где каскадёр возвращается на съёмки и случайно попадает в заговор. Кольт Сиверс привык падать, взрываться и вставать после дубля, но новое задание выходит далеко за рамки кино. Чтобы спасти фильм бывшей девушки, ему нужно найти пропавшую звезду и не превратить реальную жизнь в самый дорогой трюк карьеры. Работа David Leitch и команды Universal Pictures, 87North Productions чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "126 мин" },
        { label: "Студия", value: "Universal Pictures, 87North Productions" },
        { label: "Дистрибьютор", value: "Universal Pictures" },
        { label: "Режиссёр", value: "David Leitch" },
        { label: "Тема", value: "Кино, трюки, закулисье" },
      ],
      cast: [
        { name: "Ryan Gosling", role: "Кольт Сиверс" },
        { name: "Emily Blunt", role: "Джоди Морено" },
        { name: "Aaron Taylor-Johnson", role: "Том Райдер" },
        { name: "Hannah Waddingham", role: "Гейл Мейер" },
        { name: "Winston Duke", role: "Дэн Такер" },
        { name: "Stephanie Hsu", role: "Альма Милан" },
      ],
      players: [
        {
          id: "factorios-535243",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/535243",
        },
      ],
    },
  {
      id: 97,
      kinopoiskId: 4902648,
      slug: "godzilla-x-kong-the-new-empire",
      title: "Годзилла и Конг: Новая империя",
      originalTitle: "Godzilla x Kong: The New Empire",
      searchTitles: ["годзилла", "конг", "новая империя", "godzilla", "kong", "new empire"],
      type: "Фильм",
      year: "2024",
      rating: 6.1,
      genres: ["Фантастика", "Экшен", "Приключения"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/b/be/Godzilla_x_kong_the_new_empire_poster.jpg/250px-Godzilla_x_kong_the_new_empire_poster.jpg",
      description: "Два титана сталкиваются с новой угрозой из глубин мира.",
      trailerUrl: "https://www.youtube.com/embed/c0AkaHWg2OI",
      longDescription:
        "«Годзилла и Конг: Новая империя» — фильм 2024 года в жанрах Фантастика, Экшен, Приключения, где два титана сталкиваются с новой угрозой из глубин мира. Годзилла и Конг вынуждены столкнуться с силой, которая угрожает не только людям, но и самим титанам. История раскрывает новые тайны Полой Земли и древнюю борьбу, спрятанную под поверхностью знакомого мира. Работа Adam Wingard и команды Legendary Pictures чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "115 мин" },
        { label: "Студия", value: "Legendary Pictures" },
        { label: "Дистрибьютор", value: "Warner Bros. Pictures" },
        { label: "Режиссёр", value: "Adam Wingard" },
        { label: "Вселенная", value: "Monsterverse" },
      ],
      cast: [
        { name: "Rebecca Hall", role: "Доктор Айлин Эндрюс" },
        { name: "Brian Tyree Henry", role: "Берни Хейс" },
        { name: "Dan Stevens", role: "Трэппер" },
        { name: "Kaylee Hottle", role: "Джиа" },
        { name: "Alex Ferns", role: "Микаэль" },
        { name: "Fala Chen", role: "Иви" },
      ],
      players: [
        {
          id: "factorios-4902648",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/4902648",
        },
      ],
    },
  {
      id: 98,
      kinopoiskId: 4766559,
      slug: "venom-the-last-dance",
      title: "Веном: Последний танец",
      originalTitle: "Venom: The Last Dance",
      searchTitles: ["веном", "последний танец", "venom", "the last dance"],
      type: "Фильм",
      year: "2024",
      rating: 6.0,
      genres: ["Фантастика", "Экшен", "Приключения"],
      poster: "https://upload.wikimedia.org/wikipedia/en/a/a3/Venom_The_Last_Dance_Poster.jpg",
      description: "Эдди и Веном бегут от угроз сразу из двух миров.",
      trailerUrl: "https://www.youtube.com/embed/HyIyd9joTTc",
      longDescription:
        "«Веном: Последний танец» — фильм 2024 года в жанрах Фантастика, Экшен, Приключения, где эдди и Веном бегут от угроз сразу из двух миров. Эдди Брок и Веном становятся целью охоты и вынуждены скрываться, пока давление вокруг них растёт. Их связь проходит проверку, а финальная глава превращается в историю о выборе, доверии и хаосе симбиота. Работа Kelly Marcel и команды Columbia Pictures, Marvel Entertainment чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "109 мин" },
        { label: "Студия", value: "Columbia Pictures, Marvel Entertainment" },
        { label: "Дистрибьютор", value: "Sony Pictures Releasing" },
        { label: "Режиссёр", value: "Kelly Marcel" },
        { label: "Серия", value: "Venom" },
      ],
      cast: [
        { name: "Tom Hardy", role: "Эдди Брок / Веном" },
        { name: "Chiwetel Ejiofor", role: "Рекс Стрикленд" },
        { name: "Juno Temple", role: "Доктор Тедди Пейн" },
        { name: "Rhys Ifans", role: "Мартин" },
        { name: "Stephen Graham", role: "Патрик Маллиган" },
        { name: "Peggy Lu", role: "Миссис Чен" },
      ],
      players: [
        {
          id: "factorios-4766559",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/4766559",
        },
      ],
    },
  {
      id: 99,
      kinopoiskId: 1451347,
      slug: "a-quiet-place-day-one",
      title: "Тихое место: День первый",
      originalTitle: "A Quiet Place: Day One",
      searchTitles: ["тихое место", "день первый", "a quiet place", "day one"],
      type: "Фильм",
      year: "2024",
      rating: 6.3,
      genres: ["Ужасы", "Фантастика", "Драма"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/e/e7/A_Quiet_Place_Day_One_%282024%29_poster.jpg/250px-A_Quiet_Place_Day_One_%282024%29_poster.jpg",
      description: "Первый день вторжения, когда шум стал главным врагом.",
      trailerUrl: "https://www.youtube.com/embed/YPY7J-flzE8",
      longDescription:
        "«Тихое место: День первый» — фильм 2024 года в жанрах Ужасы, Фантастика, Драма, где первый день вторжения, когда шум стал главным врагом. Нью-Йорк погружается в хаос в день появления существ, которые охотятся на звук. Самира и случайные спутники пытаются выжить в городе, где привычные правила исчезают, а тишина становится единственным шансом. Работа Michael Sarnoski и команды Paramount Pictures, Platinum Dunes чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "99 мин" },
        { label: "Студия", value: "Paramount Pictures, Platinum Dunes" },
        { label: "Дистрибьютор", value: "Paramount Pictures" },
        { label: "Режиссёр", value: "Michael Sarnoski" },
        { label: "Серия", value: "A Quiet Place" },
      ],
      cast: [
        { name: "Lupita Nyong'o", role: "Самира" },
        { name: "Joseph Quinn", role: "Эрик" },
        { name: "Alex Wolff", role: "Рубен" },
        { name: "Djimon Hounsou", role: "Анри" },
        { name: "Eliane Umuhire", role: "Зена" },
      ],
      players: [
        {
          id: "factorios-1451347",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1451347",
        },
      ],
    },
  {
      id: 100,
      kinopoiskId: 5388362,
      slug: "twisters",
      title: "Твистеры",
      originalTitle: "Twisters",
      searchTitles: ["твистеры", "смерчи", "twisters", "twister"],
      type: "Фильм",
      year: "2024",
      rating: 6.5,
      genres: ["Экшен", "Приключения", "Триллер"],
      poster: "https://upload.wikimedia.org/wikipedia/en/2/24/Twisters_Official_US_Theatrical_Poster.jpg",
      description: "Охотники за торнадо возвращаются в сезон большой опасности.",
      trailerUrl: "https://www.youtube.com/embed/wdok0rZdmx4",
      longDescription:
        "«Твистеры» — фильм 2024 года в жанрах Экшен, Приключения, Триллер, где охотники за торнадо возвращаются в сезон большой опасности. Кейт Купер возвращается к изучению торнадо после болезненного прошлого и сталкивается с харизматичным охотником за бурями Тайлером Оуэнсом. Когда сезон становится всё опаснее, наука, риск и адреналин сходятся в одной точке. Работа Lee Isaac Chung и команды Universal Pictures, Warner Bros., Amblin Entertainment чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "122 мин" },
        { label: "Студия", value: "Universal Pictures, Warner Bros., Amblin Entertainment" },
        { label: "Дистрибьютор", value: "Universal Pictures / Warner Bros. Pictures" },
        { label: "Режиссёр", value: "Lee Isaac Chung" },
        { label: "Тема", value: "Стихия, риск, погоня за бурей" },
      ],
      cast: [
        { name: "Daisy Edgar-Jones", role: "Кейт Купер" },
        { name: "Glen Powell", role: "Тайлер Оуэнс" },
        { name: "Anthony Ramos", role: "Хави" },
        { name: "Brandon Perea", role: "Бун" },
        { name: "Maura Tierney", role: "Кэти" },
      ],
      players: [
        {
          id: "factorios-5388362",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5388362",
        },
      ],
    },
  {
      id: 101,
      kinopoiskId: 1207839,
      slug: "gladiator-ii",
      title: "Гладиатор 2",
      originalTitle: "Gladiator II",
      searchTitles: ["гладиатор", "гладиатор 2", "gladiator", "gladiator ii"],
      type: "Фильм",
      year: "2024",
      rating: 6.5,
      genres: ["История", "Драма", "Экшен"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/0/04/Gladiator_II_%282024%29_poster.jpg/250px-Gladiator_II_%282024%29_poster.jpg",
      description: "Новая борьба за честь и власть на арене Рима.",
      trailerUrl: "https://www.youtube.com/embed/4rgYUipGJNo",
      longDescription:
        "«Гладиатор 2» — фильм 2024 года в жанрах История, Драма, Экшен, где новая борьба за честь и власть на арене Рима. Луций оказывается втянут в жестокий мир Колизея после того, как его дом захватывают силы Рима. Чтобы вернуть себе силу и смысл, ему приходится обратиться к прошлому и понять, что честь на арене стоит дороже победы. Работа Ridley Scott и команды Scott Free Productions, Red Wagon Entertainment чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2024" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "Великобритания, США" },
        { label: "Длительность", value: "148 мин" },
        { label: "Студия", value: "Scott Free Productions, Red Wagon Entertainment" },
        { label: "Дистрибьютор", value: "Paramount Pictures" },
        { label: "Режиссёр", value: "Ridley Scott" },
        { label: "Основа", value: "Продолжение фильма Gladiator" },
      ],
      cast: [
        { name: "Paul Mescal", role: "Луций" },
        { name: "Pedro Pascal", role: "Марк Акаций" },
        { name: "Denzel Washington", role: "Макрин" },
        { name: "Joseph Quinn", role: "Гета" },
        { name: "Fred Hechinger", role: "Каракалла" },
        { name: "Connie Nielsen", role: "Луцилла" },
      ],
      players: [
        {
          id: "factorios-1207839",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1207839",
        },
      ],
    },
  {
      id: 102,
      kinopoiskId: 997647,
      slug: "superman-2025",
      title: "Супермен",
      originalTitle: "Superman",
      searchTitles: ["супермен", "superman", "clark kent", "кларк кент"],
      type: "Фильм",
      year: "2025",
      rating: 7.2,
      genres: ["Фантастика", "Экшен", "Приключения"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/3/32/Superman_%282025_film%29_poster.jpg/250px-Superman_%282025_film%29_poster.jpg",
      description: "Новый старт Супермена в мире, которому всё ещё нужна надежда.",
      trailerUrl: "https://www.youtube.com/embed/Ox8ZLF6cGM0",
      longDescription:
        "«Супермен» — фильм 2025 года в жанрах Фантастика, Экшен, Приключения, где новый старт Супермена в мире, которому всё ещё нужна надежда. Кларк Кент пытается соединить своё криптонское происхождение с человеческим воспитанием и остаться символом доброты в мире, который стал намного циничнее. Новый Супермен открывает первую главу обновлённой вселенной DC. Работа James Gunn и команды DC Studios, Troll Court Entertainment, The Safran Company чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2025" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "129 мин" },
        { label: "Студия", value: "DC Studios, Troll Court Entertainment, The Safran Company" },
        { label: "Дистрибьютор", value: "Warner Bros. Pictures" },
        { label: "Режиссёр", value: "James Gunn" },
        { label: "Вселенная", value: "DC Universe" },
      ],
      cast: [
        { name: "David Corenswet", role: "Кларк Кент / Супермен" },
        { name: "Rachel Brosnahan", role: "Лоис Лейн" },
        { name: "Nicholas Hoult", role: "Лекс Лютор" },
        { name: "Edi Gathegi", role: "Мистер Террифик" },
        { name: "Nathan Fillion", role: "Гай Гарднер" },
        { name: "Isabela Merced", role: "Хоукгёрл" },
      ],
      players: [
        {
          id: "factorios-997647",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/997647",
        },
      ],
    },
  {
      id: 103,
      kinopoiskId: 5001443,
      slug: "thunderbolts",
      title: "Громовержцы",
      originalTitle: "Thunderbolts*",
      searchTitles: ["громовержцы", "thunderbolts", "thunderbolts*", "новые мстители", "new avengers"],
      type: "Фильм",
      year: "2025",
      rating: 7.2,
      genres: ["Экшен", "Приключения", "Фантастика"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/9/90/Thunderbolts%2A_poster.jpg/250px-Thunderbolts%2A_poster.jpg",
      description: "Команда антигероев получает шанс на опасное искупление.",
      trailerUrl: "https://www.youtube.com/embed/-sAOWhvheK8",
      longDescription:
        "«Громовержцы» — фильм 2025 года в жанрах Экшен, Приключения, Фантастика, где команда антигероев получает шанс на опасное искупление. Елена Белова и группа неоднозначных героев оказываются втянуты в миссию, где им приходится работать вместе, хотя доверие — не их сильная сторона. Это история о людях с тяжёлым прошлым, которые пытаются выбраться из чужой игры. Работа Jake Schreier и команды Marvel Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2025" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "127 мин" },
        { label: "Студия", value: "Marvel Studios" },
        { label: "Дистрибьютор", value: "Walt Disney Studios Motion Pictures" },
        { label: "Режиссёр", value: "Jake Schreier" },
        { label: "Вселенная", value: "Marvel Cinematic Universe" },
      ],
      cast: [
        { name: "Florence Pugh", role: "Елена Белова" },
        { name: "Sebastian Stan", role: "Баки Барнс" },
        { name: "Wyatt Russell", role: "Джон Уокер" },
        { name: "David Harbour", role: "Красный Страж" },
        { name: "Lewis Pullman", role: "Боб" },
        { name: "Julia Louis-Dreyfus", role: "Валентина Аллегра де Фонтейн" },
      ],
      players: [
        {
          id: "factorios-5001443",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/5001443",
        },
      ],
    },
  {
      id: 104,
      kinopoiskId: 1287545,
      slug: "the-fantastic-four-first-steps",
      title: "Фантастическая четвёрка: Первые шаги",
      originalTitle: "The Fantastic Four: First Steps",
      searchTitles: ["фантастическая четверка", "фантастическая четвёрка", "первые шаги", "fantastic four", "first steps"],
      type: "Фильм",
      year: "2025",
      rating: 7.0,
      genres: ["Фантастика", "Экшен", "Приключения"],
      poster: "https://upload.wikimedia.org/wikipedia/en/thumb/1/13/The_Fantastic_Four_First_Steps_poster.jpg/250px-The_Fantastic_Four_First_Steps_poster.jpg",
      description: "Marvel представляет Первую семью в ретрофутуристичном мире.",
      trailerUrl: "https://www.youtube.com/embed/18QQWa5MEcs",
      longDescription:
        "«Фантастическая четвёрка: Первые шаги» — фильм 2025 года в жанрах Фантастика, Экшен, Приключения, где marvel представляет Первую семью в ретрофутуристичном мире. Рид Ричардс, Сью Шторм, Джонни Шторм и Бен Гримм защищают Землю в мире с эстетикой космической эпохи. Семейная связь становится их главным оружием, когда планете угрожает космическая сила огромного масштаба. Работа Matt Shakman и команды Marvel Studios чувствуется в подаче: история не выглядит случайным набором сцен, а собирается в цельное настроение с понятным ритмом. Фильм раскрывается через атмосферу, темп и детали, поэтому смотреть его интереснее не фоном, а внимательно. На странице KinoLuma собраны краткая карточка, жанры, рейтинг, трейлер, актёры и дополнительные сведения, чтобы перед просмотром быстро понять атмосферу, темп и настроение этой истории.",
      facts: [
        { label: "Год", value: "2025" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "114 мин" },
        { label: "Студия", value: "Marvel Studios" },
        { label: "Дистрибьютор", value: "Walt Disney Studios Motion Pictures" },
        { label: "Режиссёр", value: "Matt Shakman" },
        { label: "Вселенная", value: "Marvel Cinematic Universe" },
      ],
      cast: [
        { name: "Pedro Pascal", role: "Рид Ричардс / Мистер Фантастик" },
        { name: "Vanessa Kirby", role: "Сью Шторм / Невидимая женщина" },
        { name: "Ebon Moss-Bachrach", role: "Бен Гримм / Существо" },
        { name: "Joseph Quinn", role: "Джонни Шторм / Человек-факел" },
        { name: "Julia Garner", role: "Шалла-Бал / Серебряный Сёрфер" },
        { name: "Ralph Ineson", role: "Галактус" },
      ],
      players: [
        {
          id: "factorios-1287545",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/1287545",
        },
      ],
    },

  {
      id: 105,
      tmdbId: 64688,
      imdbId: "tt1232829",
      slug: "21-jump-street",
      kinopoiskId: 413080,
      title: "Мачо и ботан",
      originalTitle: "21 Jump Street",
      searchTitles: ["мачо и ботан", "21 jump street", "джамп стрит", "мачо и ботан 1"],
      type: "Фильм",
      year: "2012",
      rating: 7.2,
      genres: ["Комедия", "Боевик", "Криминал"],
      countries: ["США"],
      poster: getTmdbPoster({ tmdbId: 64688, imdbId: "tt1232829", title: "Мачо и ботан", originalTitle: "21 Jump Street", year: "2012", type: "Фильм" }),
      description: "Два молодых полицейских идут под прикрытием в школу, чтобы раскрыть дело о новой опасной партии наркотиков.",
      trailerUrl: "",
      longDescription:
        "«Мачо и ботан» — комедийный боевик 2012 года о двух напарниках, которым приходится вернуться в школьную среду под прикрытием. Фильм держится на контрасте характеров, быстрых шутках и полицейской истории, где расследование постоянно сталкивается с подростковыми правилами, комплексами и неожиданной сменой ролей. На KinoLuma карточка подготовлена без выдуманных идентификаторов и с нейтральным описанием: если нужны точные внешние ID или плеер, их можно добавить вручную через админку.",
      facts: [
        { label: "Год", value: "2012" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "109 мин" },
        { label: "Режиссёр", value: "Phil Lord, Christopher Miller" },
      ],
      cast: [
        { name: "Jonah Hill", role: "Мортон Шмидт" },
        { name: "Channing Tatum", role: "Грег Дженко" },
        { name: "Brie Larson", role: "Молли" },
        { name: "Dave Franco", role: "Эрик" },
        { name: "Ice Cube", role: "Капитан Диксон" },
      ],
      players: [
        {
          id: "factorios-413080",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/413080",
        },
      ],
    },
  {
      id: 106,
      tmdbId: 187017,
      imdbId: "tt2294449",
      slug: "22-jump-street",
      kinopoiskId: 672899,
      title: "Мачо и ботан 2",
      originalTitle: "22 Jump Street",
      searchTitles: ["мачо и ботан 2", "22 jump street", "джамп стрит 2"],
      type: "Фильм",
      year: "2014",
      rating: 7.0,
      genres: ["Комедия", "Боевик", "Криминал"],
      countries: ["США"],
      poster: getTmdbPoster({ tmdbId: 187017, imdbId: "tt2294449", title: "Мачо и ботан 2", originalTitle: "22 Jump Street", year: "2014", type: "Фильм" }),
      description: "Шмидт и Дженко снова работают под прикрытием, но теперь расследование переносит их в колледж.",
      trailerUrl: "",
      longDescription:
        "«Мачо и ботан 2» — продолжение комедийного боевика о напарниках Шмидте и Дженко. На этот раз герои отправляются в колледж, где расследование снова смешивается с дружбой, конфликтами, абсурдными ситуациями и пародией на жанр полицейского кино. Карточка KinoLuma оставляет плееры пустыми до ручного добавления embed-ссылок в админке, чтобы не подставлять случайные источники вместо проверенного плеера.",
      facts: [
        { label: "Год", value: "2014" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "112 мин" },
        { label: "Режиссёр", value: "Phil Lord, Christopher Miller" },
      ],
      cast: [
        { name: "Jonah Hill", role: "Мортон Шмидт" },
        { name: "Channing Tatum", role: "Грег Дженко" },
        { name: "Ice Cube", role: "Капитан Диксон" },
        { name: "Peter Stormare", role: "Призрак" },
        { name: "Jillian Bell", role: "Мерседес" },
      ],
      players: [
        {
          id: "factorios-672899",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/672899",
        },
      ],
    },
  {
      id: 107,
      tmdbId: 18785,
      imdbId: "tt1119646",
      slug: "the-hangover",
      kinopoiskId: 426004,
      title: "Мальчишник в Вегасе",
      originalTitle: "The Hangover",
      searchTitles: ["мальчишник в вегасе", "the hangover", "похмелье"],
      type: "Фильм",
      year: "2009",
      rating: 7.7,
      genres: ["Комедия"],
      countries: ["США"],
      poster: getTmdbPoster({ tmdbId: 18785, imdbId: "tt1119646", title: "Мальчишник в Вегасе", originalTitle: "The Hangover", year: "2009", type: "Фильм" }),
      description: "После бурной ночи в Лас-Вегасе друзья просыпаются без памяти и пытаются найти пропавшего жениха.",
      trailerUrl: "",
      longDescription:
        "«Мальчишник в Вегасе» — комедия 2009 года о компании друзей, чей праздник в Лас-Вегасе превращается в хаотичное расследование собственных вчерашних поступков. Герои собирают события по уликам, пытаются найти жениха и успеть к свадьбе. Описание на KinoLuma сделано нейтрально и без лишних подробностей: карточку можно расширить через редактор фильма, добавив проверенный плеер, постер, факты или дополнительные поля.",
      facts: [
        { label: "Год", value: "2009" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "100 мин" },
        { label: "Режиссёр", value: "Todd Phillips" },
      ],
      cast: [
        { name: "Bradley Cooper", role: "Фил" },
        { name: "Ed Helms", role: "Стю" },
        { name: "Zach Galifianakis", role: "Алан" },
        { name: "Justin Bartha", role: "Даг" },
        { name: "Heather Graham", role: "Джейд" },
      ],
      players: [
        {
          id: "factorios-426004",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/426004",
        },
      ],
    },
  {
      id: 108,
      tmdbId: 193893,
      imdbId: "tt1924435",
      slug: "lets-be-cops",
      kinopoiskId: 760469,
      title: "Типа копы",
      originalTitle: "Let's Be Cops",
      searchTitles: ["типа копы", "let's be cops", "lets be cops"],
      type: "Фильм",
      year: "2014",
      rating: 6.4,
      genres: ["Комедия", "Боевик", "Криминал"],
      countries: ["США"],
      poster: getTmdbPoster({ tmdbId: 193893, imdbId: "tt1924435", title: "Типа копы", originalTitle: "Let's Be Cops", year: "2014", type: "Фильм" }),
      description: "Два друга случайно становятся местными знаменитостями после вечеринки в полицейской форме, но игра быстро становится опасной.",
      trailerUrl: "",
      longDescription:
        "«Типа копы» — комедийный боевик 2014 года о двух друзьях, которые надевают полицейскую форму для вечеринки и неожиданно оказываются в центре внимания. Когда шутка начинает выглядеть слишком убедительно, героям приходится разбираться с настоящими проблемами и последствиями своей роли. Карточка добавлена в безопасном формате: плееры пустые, а факты не расширяются догадками без проверки.",
      facts: [
        { label: "Год", value: "2014" },
        { label: "Тип", value: "Фильм" },
        { label: "Страна", value: "США" },
        { label: "Длительность", value: "104 мин" },
        { label: "Режиссёр", value: "Luke Greenfield" },
      ],
      cast: [
        { name: "Jake Johnson", role: "Райан" },
        { name: "Damon Wayans Jr.", role: "Джастин" },
        { name: "Nina Dobrev", role: "Джози" },
        { name: "Rob Riggle", role: "Сигарс" },
        { name: "Keegan-Michael Key", role: "Пупа" },
      ],
      players: [
        {
          id: "factorios-760469",
          name: "Основной",
          embedUrl: "https://tarantino.factorios.live/show/kinopoisk/760469",
        },
      ],
    },

  {
    id: 109,
    kinopoiskId: 409424,
    imdbId: "tt1160419",
    slug: "dune-2021",
    title: "Дюна",
    originalTitle: "Dune: Part One",
    searchTitles: ["дюна", "dune: part one", "dune 2021"],
    type: "Фильм",
    year: "2021",
    rating: 7.7,
    genres: ["Фантастика", "Приключения", "Драма"],
    countries: ["США", "Канада"],
    poster: getTmdbPoster({ imdbId: "tt1160419", title: "Дюна", originalTitle: "Dune: Part One", year: "2021", type: "Фильм" }),
    description: "Дом Атрейдесов получает власть над пустынной планетой Арракис, где решается судьба редчайшего ресурса во вселенной.",
    trailerUrl: "",
    longDescription: "«Дюна» — фильм 2021 года в жанрах Фантастика, Приключения, Драма. Дом Атрейдесов получает власть над пустынной планетой Арракис, где решается судьба редчайшего ресурса во вселенной. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Канада" },
      { label: "Режиссёр", value: "Denis Villeneuve" },
      { label: "Жанры", value: "Фантастика, Приключения, Драма" },
    ],
    cast: [
      { name: "Timothée Chalamet", role: "Пол Атрейдес" },
      { name: "Rebecca Ferguson", role: "Леди Джессика" },
      { name: "Oscar Isaac", role: "Лето Атрейдес" },
      { name: "Zendaya", role: "Чани" },
      { name: "Jason Momoa", role: "Дункан Айдахо" },
    ],
  },
  {
    id: 110,
    kinopoiskId: 251733,
    imdbId: "tt0499549",
    slug: "avatar",
    title: "Аватар",
    originalTitle: "Avatar",
    searchTitles: ["аватар", "avatar"],
    type: "Фильм",
    year: "2009",
    rating: 7.9,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0499549", title: "Аватар", originalTitle: "Avatar", year: "2009", type: "Фильм" }),
    description: "Бывший морпех на планете Пандора оказывается между военной миссией людей и миром народа нави.",
    trailerUrl: "",
    longDescription: "«Аватар» — фильм 2009 года в жанрах Фантастика, Приключения, Боевик. Бывший морпех на планете Пандора оказывается между военной миссией людей и миром народа нави. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2009" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "James Cameron" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
    ],
    cast: [
      { name: "Sam Worthington", role: "Джейк Салли" },
      { name: "Zoe Saldaña", role: "Нейтири" },
      { name: "Sigourney Weaver", role: "Грейс" },
      { name: "Stephen Lang", role: "Куоритч" },
    ],
  },
  {
    id: 111,
    kinopoiskId: 2213,
    imdbId: "tt0120338",
    slug: "titanic",
    title: "Титаник",
    originalTitle: "Titanic",
    searchTitles: ["титаник", "titanic"],
    type: "Фильм",
    year: "1997",
    rating: 8.4,
    genres: ["Драма", "Мелодрама", "История"],
    countries: ["США", "Мексика"],
    poster: getTmdbPoster({ imdbId: "tt0120338", title: "Титаник", originalTitle: "Titanic", year: "1997", type: "Фильм" }),
    description: "История любви Джека и Розы разворачивается на фоне первого и последнего рейса легендарного лайнера.",
    trailerUrl: "",
    longDescription: "«Титаник» — фильм 1997 года в жанрах Драма, Мелодрама, История. История любви Джека и Розы разворачивается на фоне первого и последнего рейса легендарного лайнера. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1997" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Мексика" },
      { label: "Режиссёр", value: "James Cameron" },
      { label: "Жанры", value: "Драма, Мелодрама, История" },
    ],
    cast: [
      { name: "Leonardo DiCaprio", role: "Джек" },
      { name: "Kate Winslet", role: "Роза" },
      { name: "Billy Zane", role: "Кэл" },
      { name: "Kathy Bates", role: "Молли Браун" },
    ],
  },
  {
    id: 112,
    kinopoiskId: 312,
    imdbId: "tt0167261",
    slug: "the-lord-of-the-rings-the-two-towers",
    title: "Властелин колец: Две крепости",
    originalTitle: "The Lord of the Rings: The Two Towers",
    searchTitles: ["властелин колец: две крепости", "the lord of the rings: the two towers", "the lord of the rings the two towers"],
    type: "Фильм",
    year: "2002",
    rating: 8.6,
    genres: ["Фэнтези", "Приключения", "Драма"],
    countries: ["Новая Зеландия", "США"],
    poster: getTmdbPoster({ imdbId: "tt0167261", title: "Властелин колец: Две крепости", originalTitle: "The Lord of the Rings: The Two Towers", year: "2002", type: "Фильм" }),
    description: "Братство распалось, но путь к Мордорy продолжается, а Средиземье готовится к большой войне.",
    trailerUrl: "",
    longDescription: "«Властелин колец: Две крепости» — фильм 2002 года в жанрах Фэнтези, Приключения, Драма. Братство распалось, но путь к Мордорy продолжается, а Средиземье готовится к большой войне. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2002" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Новая Зеландия, США" },
      { label: "Режиссёр", value: "Peter Jackson" },
      { label: "Жанры", value: "Фэнтези, Приключения, Драма" },
    ],
    cast: [
      { name: "Elijah Wood", role: "Фродо" },
      { name: "Ian McKellen", role: "Гэндальф" },
      { name: "Viggo Mortensen", role: "Арагорн" },
      { name: "Orlando Bloom", role: "Леголас" },
    ],
  },
  {
    id: 113,
    kinopoiskId: 3498,
    imdbId: "tt0167260",
    slug: "the-lord-of-the-rings-the-return-of-the-king",
    title: "Властелин колец: Возвращение короля",
    originalTitle: "The Lord of the Rings: The Return of the King",
    searchTitles: ["властелин колец: возвращение короля", "the lord of the rings: the return of the king", "the lord of the rings the return of the king"],
    type: "Фильм",
    year: "2003",
    rating: 8.7,
    genres: ["Фэнтези", "Приключения", "Драма"],
    countries: ["Новая Зеландия", "США"],
    poster: getTmdbPoster({ imdbId: "tt0167260", title: "Властелин колец: Возвращение короля", originalTitle: "The Lord of the Rings: The Return of the King", year: "2003", type: "Фильм" }),
    description: "Фродо и Сэм приближаются к Роковой горе, пока армии людей принимают решающую битву за Средиземье.",
    trailerUrl: "",
    longDescription: "«Властелин колец: Возвращение короля» — фильм 2003 года в жанрах Фэнтези, Приключения, Драма. Фродо и Сэм приближаются к Роковой горе, пока армии людей принимают решающую битву за Средиземье. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Новая Зеландия, США" },
      { label: "Режиссёр", value: "Peter Jackson" },
      { label: "Жанры", value: "Фэнтези, Приключения, Драма" },
    ],
    cast: [
      { name: "Elijah Wood", role: "Фродо" },
      { name: "Viggo Mortensen", role: "Арагорн" },
      { name: "Ian McKellen", role: "Гэндальф" },
      { name: "Sean Astin", role: "Сэм" },
    ],
  },
  {
    id: 114,
    kinopoiskId: 4374,
    imdbId: "tt0325980",
    slug: "pirates-of-the-caribbean-the-curse-of-the-black-pearl",
    title: "Пираты Карибского моря: Проклятие Черной жемчужины",
    originalTitle: "Pirates of the Caribbean: The Curse of the Black Pearl",
    searchTitles: ["пираты карибского моря: проклятие черной жемчужины", "pirates of the caribbean: the curse of the black pearl", "pirates of the caribbean the curse of the black pearl"],
    type: "Фильм",
    year: "2003",
    rating: 8.4,
    genres: ["Приключения", "Фэнтези", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0325980", title: "Пираты Карибского моря: Проклятие Черной жемчужины", originalTitle: "Pirates of the Caribbean: The Curse of the Black Pearl", year: "2003", type: "Фильм" }),
    description: "Капитан Джек Воробей и кузнец Уилл Тёрнер сталкиваются с проклятой командой пиратов.",
    trailerUrl: "",
    longDescription: "«Пираты Карибского моря: Проклятие Черной жемчужины» — фильм 2003 года в жанрах Приключения, Фэнтези, Боевик. Капитан Джек Воробей и кузнец Уилл Тёрнер сталкиваются с проклятой командой пиратов. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Gore Verbinski" },
      { label: "Жанры", value: "Приключения, Фэнтези, Боевик" },
    ],
    cast: [
      { name: "Johnny Depp", role: "Джек Воробей" },
      { name: "Orlando Bloom", role: "Уилл Тёрнер" },
      { name: "Keira Knightley", role: "Элизабет Суонн" },
      { name: "Geoffrey Rush", role: "Барбосса" },
    ],
  },
  {
    id: 115,
    kinopoiskId: 444,
    imdbId: "tt0103064",
    slug: "terminator-2-judgment-day",
    title: "Терминатор 2: Судный день",
    originalTitle: "Terminator 2: Judgment Day",
    searchTitles: ["терминатор 2: судный день", "terminator 2: judgment day", "terminator 2 judgment day"],
    type: "Фильм",
    year: "1991",
    rating: 8.3,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0103064", title: "Терминатор 2: Судный день", originalTitle: "Terminator 2: Judgment Day", year: "1991", type: "Фильм" }),
    description: "За Джоном Коннором охотится новый терминатор, а защитником мальчика становится машина из будущего.",
    trailerUrl: "",
    longDescription: "«Терминатор 2: Судный день» — фильм 1991 года в жанрах Фантастика, Боевик, Триллер. За Джоном Коннором охотится новый терминатор, а защитником мальчика становится машина из будущего. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1991" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "James Cameron" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Arnold Schwarzenegger", role: "Терминатор" },
      { name: "Linda Hamilton", role: "Сара Коннор" },
      { name: "Edward Furlong", role: "Джон Коннор" },
      { name: "Robert Patrick", role: "T-1000" },
    ],
  },
  {
    id: 116,
    kinopoiskId: 476,
    imdbId: "tt0088763",
    slug: "back-to-the-future",
    title: "Назад в будущее",
    originalTitle: "Back to the Future",
    searchTitles: ["назад в будущее", "back to the future"],
    type: "Фильм",
    year: "1985",
    rating: 8.6,
    genres: ["Фантастика", "Комедия", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0088763", title: "Назад в будущее", originalTitle: "Back to the Future", year: "1985", type: "Фильм" }),
    description: "Марти Макфлай случайно переносится в прошлое и должен спасти будущее собственной семьи.",
    trailerUrl: "",
    longDescription: "«Назад в будущее» — фильм 1985 года в жанрах Фантастика, Комедия, Приключения. Марти Макфлай случайно переносится в прошлое и должен спасти будущее собственной семьи. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1985" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Robert Zemeckis" },
      { label: "Жанры", value: "Фантастика, Комедия, Приключения" },
    ],
    cast: [
      { name: "Michael J. Fox", role: "Марти Макфлай" },
      { name: "Christopher Lloyd", role: "Док Браун" },
      { name: "Lea Thompson", role: "Лоррейн" },
      { name: "Crispin Glover", role: "Джордж" },
    ],
  },
  {
    id: 117,
    kinopoiskId: 386,
    imdbId: "tt0078748",
    slug: "alien",
    title: "Чужой",
    originalTitle: "Alien",
    searchTitles: ["чужой", "alien"],
    type: "Фильм",
    year: "1979",
    rating: 8.1,
    genres: ["Ужасы", "Фантастика", "Триллер"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt0078748", title: "Чужой", originalTitle: "Alien", year: "1979", type: "Фильм" }),
    description: "Экипаж космического корабля сталкивается с неизвестной формой жизни, которая превращает возвращение домой в борьбу за выживание.",
    trailerUrl: "",
    longDescription: "«Чужой» — фильм 1979 года в жанрах Ужасы, Фантастика, Триллер. Экипаж космического корабля сталкивается с неизвестной формой жизни, которая превращает возвращение домой в борьбу за выживание. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1979" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Режиссёр", value: "Ridley Scott" },
      { label: "Жанры", value: "Ужасы, Фантастика, Триллер" },
    ],
    cast: [
      { name: "Sigourney Weaver", role: "Рипли" },
      { name: "Tom Skerritt", role: "Даллас" },
      { name: "Ian Holm", role: "Эш" },
      { name: "John Hurt", role: "Кейн" },
    ],
  },
  {
    id: 118,
    kinopoiskId: 406,
    imdbId: "tt0090605",
    slug: "aliens",
    title: "Чужие",
    originalTitle: "Aliens",
    searchTitles: ["чужие", "aliens"],
    type: "Фильм",
    year: "1986",
    rating: 8.1,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0090605", title: "Чужие", originalTitle: "Aliens", year: "1986", type: "Фильм" }),
    description: "Рипли возвращается на планету, где колония людей перестала выходить на связь после встречи с ксеноморфами.",
    trailerUrl: "",
    longDescription: "«Чужие» — фильм 1986 года в жанрах Фантастика, Боевик, Триллер. Рипли возвращается на планету, где колония людей перестала выходить на связь после встречи с ксеноморфами. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1986" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "James Cameron" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Sigourney Weaver", role: "Рипли" },
      { name: "Michael Biehn", role: "Хикс" },
      { name: "Carrie Henn", role: "Ньют" },
      { name: "Bill Paxton", role: "Хадсон" },
    ],
  },
  {
    id: 119,
    kinopoiskId: 6303,
    imdbId: "tt0093773",
    slug: "predator",
    title: "Хищник",
    originalTitle: "Predator",
    searchTitles: ["хищник", "predator"],
    type: "Фильм",
    year: "1987",
    rating: 7.9,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0093773", title: "Хищник", originalTitle: "Predator", year: "1987", type: "Фильм" }),
    description: "Отряд спецназовцев в джунглях сталкивается с охотником с другой планеты.",
    trailerUrl: "",
    longDescription: "«Хищник» — фильм 1987 года в жанрах Фантастика, Боевик, Триллер. Отряд спецназовцев в джунглях сталкивается с охотником с другой планеты. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1987" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "John McTiernan" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Arnold Schwarzenegger", role: "Датч" },
      { name: "Carl Weathers", role: "Диллон" },
      { name: "Jesse Ventura", role: "Блейн" },
      { name: "Kevin Peter Hall", role: "Хищник" },
    ],
  },
  {
    id: 120,
    kinopoiskId: 81314,
    imdbId: "tt0407887",
    slug: "the-departed",
    title: "Отступники",
    originalTitle: "The Departed",
    searchTitles: ["отступники", "the departed"],
    type: "Фильм",
    year: "2006",
    rating: 8.5,
    genres: ["Триллер", "Драма", "Криминал"],
    countries: ["США", "Гонконг"],
    poster: getTmdbPoster({ imdbId: "tt0407887", title: "Отступники", originalTitle: "The Departed", year: "2006", type: "Фильм" }),
    description: "Полицейский под прикрытием и агент мафии в полиции пытаются раскрыть друг друга.",
    trailerUrl: "",
    longDescription: "«Отступники» — фильм 2006 года в жанрах Триллер, Драма, Криминал. Полицейский под прикрытием и агент мафии в полиции пытаются раскрыть друг друга. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2006" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Гонконг" },
      { label: "Режиссёр", value: "Martin Scorsese" },
      { label: "Жанры", value: "Триллер, Драма, Криминал" },
    ],
    cast: [
      { name: "Leonardo DiCaprio", role: "Билли Костиган" },
      { name: "Matt Damon", role: "Колин Салливан" },
      { name: "Jack Nicholson", role: "Фрэнк Костелло" },
      { name: "Mark Wahlberg", role: "Дигнам" },
    ],
  },
  {
    id: 121,
    kinopoiskId: 397667,
    imdbId: "tt1130884",
    slug: "shutter-island",
    title: "Остров проклятых",
    originalTitle: "Shutter Island",
    searchTitles: ["остров проклятых", "shutter island"],
    type: "Фильм",
    year: "2010",
    rating: 8.5,
    genres: ["Триллер", "Детектив", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt1130884", title: "Остров проклятых", originalTitle: "Shutter Island", year: "2010", type: "Фильм" }),
    description: "Маршал США расследует исчезновение пациентки из закрытой клиники на острове.",
    trailerUrl: "",
    longDescription: "«Остров проклятых» — фильм 2010 года в жанрах Триллер, Детектив, Драма. Маршал США расследует исчезновение пациентки из закрытой клиники на острове. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Martin Scorsese" },
      { label: "Жанры", value: "Триллер, Детектив, Драма" },
    ],
    cast: [
      { name: "Leonardo DiCaprio", role: "Тедди Дэниелс" },
      { name: "Mark Ruffalo", role: "Чак Оул" },
      { name: "Ben Kingsley", role: "Доктор Коули" },
      { name: "Michelle Williams", role: "Долорес" },
    ],
  },
  {
    id: 122,
    kinopoiskId: 462682,
    imdbId: "tt0993846",
    slug: "the-wolf-of-wall-street",
    title: "Волк с Уолл-стрит",
    originalTitle: "The Wolf of Wall Street",
    searchTitles: ["волк с уолл-стрит", "the wolf of wall street"],
    type: "Фильм",
    year: "2013",
    rating: 8.0,
    genres: ["Биография", "Комедия", "Криминал"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0993846", title: "Волк с Уолл-стрит", originalTitle: "The Wolf of Wall Street", year: "2013", type: "Фильм" }),
    description: "История брокера Джордана Белфорта показывает взлет, азарт и цену мира больших денег.",
    trailerUrl: "",
    longDescription: "«Волк с Уолл-стрит» — фильм 2013 года в жанрах Биография, Комедия, Криминал. История брокера Джордана Белфорта показывает взлет, азарт и цену мира больших денег. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Martin Scorsese" },
      { label: "Жанры", value: "Биография, Комедия, Криминал" },
    ],
    cast: [
      { name: "Leonardo DiCaprio", role: "Джордан Белфорт" },
      { name: "Jonah Hill", role: "Донни Азофф" },
      { name: "Margot Robbie", role: "Наоми" },
      { name: "Kyle Chandler", role: "Патрик Денэм" },
    ],
  },
  {
    id: 123,
    kinopoiskId: 586397,
    imdbId: "tt1853728",
    slug: "django-unchained",
    title: "Джанго освобождённый",
    originalTitle: "Django Unchained",
    searchTitles: ["джанго освобождённый", "django unchained"],
    type: "Фильм",
    year: "2012",
    rating: 8.2,
    genres: ["Вестерн", "Драма", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt1853728", title: "Джанго освобождённый", originalTitle: "Django Unchained", year: "2012", type: "Фильм" }),
    description: "Освобождённый раб Джанго вместе с охотником за головами отправляется спасать жену.",
    trailerUrl: "",
    longDescription: "«Джанго освобождённый» — фильм 2012 года в жанрах Вестерн, Драма, Боевик. Освобождённый раб Джанго вместе с охотником за головами отправляется спасать жену. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Quentin Tarantino" },
      { label: "Жанры", value: "Вестерн, Драма, Боевик" },
    ],
    cast: [
      { name: "Jamie Foxx", role: "Джанго" },
      { name: "Christoph Waltz", role: "Кинг Шульц" },
      { name: "Leonardo DiCaprio", role: "Кэлвин Кэнди" },
      { name: "Kerry Washington", role: "Брумхильда" },
    ],
  },
  {
    id: 124,
    kinopoiskId: 9691,
    imdbId: "tt0361748",
    slug: "inglourious-basterds",
    title: "Бесславные ублюдки",
    originalTitle: "Inglourious Basterds",
    searchTitles: ["бесславные ублюдки", "inglourious basterds"],
    type: "Фильм",
    year: "2009",
    rating: 8.0,
    genres: ["Военный", "Драма", "Комедия"],
    countries: ["США", "Германия"],
    poster: getTmdbPoster({ imdbId: "tt0361748", title: "Бесславные ублюдки", originalTitle: "Inglourious Basterds", year: "2009", type: "Фильм" }),
    description: "Группа бойцов и владелица кинотеатра готовят разные планы против нацистского командования.",
    trailerUrl: "",
    longDescription: "«Бесславные ублюдки» — фильм 2009 года в жанрах Военный, Драма, Комедия. Группа бойцов и владелица кинотеатра готовят разные планы против нацистского командования. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2009" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Германия" },
      { label: "Режиссёр", value: "Quentin Tarantino" },
      { label: "Жанры", value: "Военный, Драма, Комедия" },
    ],
    cast: [
      { name: "Brad Pitt", role: "Альдо Рейн" },
      { name: "Christoph Waltz", role: "Ганс Ланда" },
      { name: "Mélanie Laurent", role: "Шошанна" },
      { name: "Eli Roth", role: "Донни Доновиц" },
    ],
  },
  {
    id: 125,
    kinopoiskId: 522941,
    imdbId: "tt1663202",
    slug: "the-revenant",
    title: "Выживший",
    originalTitle: "The Revenant",
    searchTitles: ["выживший", "the revenant"],
    type: "Фильм",
    year: "2015",
    rating: 7.8,
    genres: ["Драма", "Приключения", "Вестерн"],
    countries: ["США", "Гонконг", "Тайвань"],
    poster: getTmdbPoster({ imdbId: "tt1663202", title: "Выживший", originalTitle: "The Revenant", year: "2015", type: "Фильм" }),
    description: "Охотник Хью Гласс выживает после нападения и отправляется через дикую природу ради мести.",
    trailerUrl: "",
    longDescription: "«Выживший» — фильм 2015 года в жанрах Драма, Приключения, Вестерн. Охотник Хью Гласс выживает после нападения и отправляется через дикую природу ради мести. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Гонконг, Тайвань" },
      { label: "Режиссёр", value: "Alejandro G. Iñárritu" },
      { label: "Жанры", value: "Драма, Приключения, Вестерн" },
    ],
    cast: [
      { name: "Leonardo DiCaprio", role: "Хью Гласс" },
      { name: "Tom Hardy", role: "Фицджеральд" },
      { name: "Domhnall Gleeson", role: "Эндрю Генри" },
      { name: "Will Poulter", role: "Бриджер" },
    ],
  },
  {
    id: 126,
    kinopoiskId: 4541,
    imdbId: "tt0120382",
    slug: "the-truman-show",
    title: "Шоу Трумана",
    originalTitle: "The Truman Show",
    searchTitles: ["шоу трумана", "the truman show"],
    type: "Фильм",
    year: "1998",
    rating: 8.3,
    genres: ["Драма", "Комедия", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0120382", title: "Шоу Трумана", originalTitle: "The Truman Show", year: "1998", type: "Фильм" }),
    description: "Труман живёт идеальной жизнью, не подозревая, что весь его мир построен для телешоу.",
    trailerUrl: "",
    longDescription: "«Шоу Трумана» — фильм 1998 года в жанрах Драма, Комедия, Фантастика. Труман живёт идеальной жизнью, не подозревая, что весь его мир построен для телешоу. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1998" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Peter Weir" },
      { label: "Жанры", value: "Драма, Комедия, Фантастика" },
    ],
    cast: [
      { name: "Jim Carrey", role: "Труман Бёрбанк" },
      { name: "Laura Linney", role: "Мерил" },
      { name: "Ed Harris", role: "Кристоф" },
      { name: "Noah Emmerich", role: "Марлон" },
    ],
  },
  {
    id: 127,
    kinopoiskId: 395,
    imdbId: "tt0167404",
    slug: "the-sixth-sense",
    title: "Шестое чувство",
    originalTitle: "The Sixth Sense",
    searchTitles: ["шестое чувство", "the sixth sense"],
    type: "Фильм",
    year: "1999",
    rating: 8.1,
    genres: ["Триллер", "Драма", "Детектив"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0167404", title: "Шестое чувство", originalTitle: "The Sixth Sense", year: "1999", type: "Фильм" }),
    description: "Детский психолог пытается помочь мальчику, который утверждает, что видит умерших людей.",
    trailerUrl: "",
    longDescription: "«Шестое чувство» — фильм 1999 года в жанрах Триллер, Драма, Детектив. Детский психолог пытается помочь мальчику, который утверждает, что видит умерших людей. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1999" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "M. Night Shyamalan" },
      { label: "Жанры", value: "Триллер, Драма, Детектив" },
    ],
    cast: [
      { name: "Bruce Willis", role: "Малкольм Кроу" },
      { name: "Haley Joel Osment", role: "Коул" },
      { name: "Toni Collette", role: "Линн" },
      { name: "Olivia Williams", role: "Анна" },
    ],
  },
  {
    id: 128,
    kinopoiskId: 345,
    imdbId: "tt0102926",
    slug: "the-silence-of-the-lambs",
    title: "Молчание ягнят",
    originalTitle: "The Silence of the Lambs",
    searchTitles: ["молчание ягнят", "the silence of the lambs"],
    type: "Фильм",
    year: "1991",
    rating: 8.3,
    genres: ["Триллер", "Криминал", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0102926", title: "Молчание ягнят", originalTitle: "The Silence of the Lambs", year: "1991", type: "Фильм" }),
    description: "Курсантка ФБР обращается к заключённому доктору Лектеру, чтобы найти опасного преступника.",
    trailerUrl: "",
    longDescription: "«Молчание ягнят» — фильм 1991 года в жанрах Триллер, Криминал, Драма. Курсантка ФБР обращается к заключённому доктору Лектеру, чтобы найти опасного преступника. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1991" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Jonathan Demme" },
      { label: "Жанры", value: "Триллер, Криминал, Драма" },
    ],
    cast: [
      { name: "Jodie Foster", role: "Кларисса Старлинг" },
      { name: "Anthony Hopkins", role: "Ганнибал Лектер" },
      { name: "Scott Glenn", role: "Джек Кроуфорд" },
      { name: "Ted Levine", role: "Баффало Билл" },
    ],
  },
  {
    id: 129,
    kinopoiskId: 371,
    imdbId: "tt0120815",
    slug: "saving-private-ryan",
    title: "Спасти рядового Райана",
    originalTitle: "Saving Private Ryan",
    searchTitles: ["спасти рядового райана", "saving private ryan"],
    type: "Фильм",
    year: "1998",
    rating: 8.2,
    genres: ["Военный", "Драма", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0120815", title: "Спасти рядового Райана", originalTitle: "Saving Private Ryan", year: "1998", type: "Фильм" }),
    description: "После высадки в Нормандии отряд получает приказ найти и вернуть домой единственного выжившего сына семьи Райан.",
    trailerUrl: "",
    longDescription: "«Спасти рядового Райана» — фильм 1998 года в жанрах Военный, Драма, Боевик. После высадки в Нормандии отряд получает приказ найти и вернуть домой единственного выжившего сына семьи Райан. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1998" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Steven Spielberg" },
      { label: "Жанры", value: "Военный, Драма, Боевик" },
    ],
    cast: [
      { name: "Tom Hanks", role: "Капитан Миллер" },
      { name: "Matt Damon", role: "Джеймс Райан" },
      { name: "Tom Sizemore", role: "Хорват" },
      { name: "Edward Burns", role: "Райбен" },
    ],
  },
  {
    id: 130,
    kinopoiskId: 355,
    imdbId: "tt0253474",
    slug: "the-pianist",
    title: "Пианист",
    originalTitle: "The Pianist",
    searchTitles: ["пианист", "the pianist"],
    type: "Фильм",
    year: "2002",
    rating: 8.5,
    genres: ["Драма", "Биография", "Военный"],
    countries: ["Франция", "Польша", "Германия"],
    poster: getTmdbPoster({ imdbId: "tt0253474", title: "Пианист", originalTitle: "The Pianist", year: "2002", type: "Фильм" }),
    description: "Польский пианист Владислав Шпильман пытается выжить в оккупированной Варшаве.",
    trailerUrl: "",
    longDescription: "«Пианист» — фильм 2002 года в жанрах Драма, Биография, Военный. Польский пианист Владислав Шпильман пытается выжить в оккупированной Варшаве. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2002" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Франция, Польша, Германия" },
      { label: "Режиссёр", value: "Roman Polanski" },
      { label: "Жанры", value: "Драма, Биография, Военный" },
    ],
    cast: [
      { name: "Adrien Brody", role: "Владислав Шпильман" },
      { name: "Thomas Kretschmann", role: "Вильм Хозенфельд" },
      { name: "Frank Finlay", role: "Отец" },
      { name: "Maureen Lipman", role: "Мать" },
    ],
  },
  {
    id: 131,
    kinopoiskId: 399,
    imdbId: "tt0112573",
    slug: "braveheart",
    title: "Храброе сердце",
    originalTitle: "Braveheart",
    searchTitles: ["храброе сердце", "braveheart"],
    type: "Фильм",
    year: "1995",
    rating: 8.3,
    genres: ["История", "Драма", "Военный"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0112573", title: "Храброе сердце", originalTitle: "Braveheart", year: "1995", type: "Фильм" }),
    description: "Уильям Уоллес становится символом борьбы Шотландии за свободу.",
    trailerUrl: "",
    longDescription: "«Храброе сердце» — фильм 1995 года в жанрах История, Драма, Военный. Уильям Уоллес становится символом борьбы Шотландии за свободу. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "1995" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Mel Gibson" },
      { label: "Жанры", value: "История, Драма, Военный" },
    ],
    cast: [
      { name: "Mel Gibson", role: "Уильям Уоллес" },
      { name: "Sophie Marceau", role: "Изабелла" },
      { name: "Patrick McGoohan", role: "Эдуард I" },
      { name: "Catherine McCormack", role: "Маррон" },
    ],
  },
  {
    id: 132,
    kinopoiskId: 689,
    imdbId: "tt0241527",
    slug: "harry-potter-and-the-sorcerers-stone",
    title: "Гарри Поттер и философский камень",
    originalTitle: "Harry Potter and the Sorcerer's Stone",
    searchTitles: ["гарри поттер и философский камень", "harry potter and the sorcerer's stone", "harry potter and the sorcerers stone"],
    type: "Фильм",
    year: "2001",
    rating: 8.3,
    genres: ["Фэнтези", "Приключения", "Семейный"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ imdbId: "tt0241527", title: "Гарри Поттер и философский камень", originalTitle: "Harry Potter and the Sorcerer's Stone", year: "2001", type: "Фильм" }),
    description: "Мальчик Гарри узнаёт, что он волшебник, и впервые отправляется в Хогвартс.",
    trailerUrl: "",
    longDescription: "«Гарри Поттер и философский камень» — фильм 2001 года в жанрах Фэнтези, Приключения, Семейный. Мальчик Гарри узнаёт, что он волшебник, и впервые отправляется в Хогвартс. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2001" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр", value: "Chris Columbus" },
      { label: "Жанры", value: "Фэнтези, Приключения, Семейный" },
    ],
    cast: [
      { name: "Daniel Radcliffe", role: "Гарри Поттер" },
      { name: "Rupert Grint", role: "Рон Уизли" },
      { name: "Emma Watson", role: "Гермиона Грейнджер" },
      { name: "Robbie Coltrane", role: "Хагрид" },
    ],
  },
  {
    id: 133,
    kinopoiskId: 688,
    imdbId: "tt0295297",
    slug: "harry-potter-and-the-chamber-of-secrets",
    title: "Гарри Поттер и Тайная комната",
    originalTitle: "Harry Potter and the Chamber of Secrets",
    searchTitles: ["гарри поттер и тайная комната", "harry potter and the chamber of secrets"],
    type: "Фильм",
    year: "2002",
    rating: 8.2,
    genres: ["Фэнтези", "Приключения", "Семейный"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ imdbId: "tt0295297", title: "Гарри Поттер и Тайная комната", originalTitle: "Harry Potter and the Chamber of Secrets", year: "2002", type: "Фильм" }),
    description: "Во втором году в Хогвартсе Гарри сталкивается с тайной комнатой и древней угрозой школы.",
    trailerUrl: "",
    longDescription: "«Гарри Поттер и Тайная комната» — фильм 2002 года в жанрах Фэнтези, Приключения, Семейный. Во втором году в Хогвартсе Гарри сталкивается с тайной комнатой и древней угрозой школы. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2002" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр", value: "Chris Columbus" },
      { label: "Жанры", value: "Фэнтези, Приключения, Семейный" },
    ],
    cast: [
      { name: "Daniel Radcliffe", role: "Гарри Поттер" },
      { name: "Rupert Grint", role: "Рон Уизли" },
      { name: "Emma Watson", role: "Гермиона" },
      { name: "Kenneth Branagh", role: "Локхарт" },
    ],
  },
  {
    id: 134,
    kinopoiskId: 322,
    imdbId: "tt0304141",
    slug: "harry-potter-and-the-prisoner-of-azkaban",
    title: "Гарри Поттер и узник Азкабана",
    originalTitle: "Harry Potter and the Prisoner of Azkaban",
    searchTitles: ["гарри поттер и узник азкабана", "harry potter and the prisoner of azkaban"],
    type: "Фильм",
    year: "2004",
    rating: 8.2,
    genres: ["Фэнтези", "Приключения", "Семейный"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ imdbId: "tt0304141", title: "Гарри Поттер и узник Азкабана", originalTitle: "Harry Potter and the Prisoner of Azkaban", year: "2004", type: "Фильм" }),
    description: "Побег Сириуса Блэка из Азкабана открывает Гарри новую часть семейной истории.",
    trailerUrl: "",
    longDescription: "«Гарри Поттер и узник Азкабана» — фильм 2004 года в жанрах Фэнтези, Приключения, Семейный. Побег Сириуса Блэка из Азкабана открывает Гарри новую часть семейной истории. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2004" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр", value: "Alfonso Cuarón" },
      { label: "Жанры", value: "Фэнтези, Приключения, Семейный" },
    ],
    cast: [
      { name: "Daniel Radcliffe", role: "Гарри Поттер" },
      { name: "Rupert Grint", role: "Рон Уизли" },
      { name: "Emma Watson", role: "Гермиона" },
      { name: "Gary Oldman", role: "Сириус Блэк" },
    ],
  },
  {
    id: 135,
    kinopoiskId: 263531,
    imdbId: "tt0848228",
    slug: "the-avengers",
    title: "Мстители",
    originalTitle: "The Avengers",
    searchTitles: ["мстители", "the avengers"],
    type: "Фильм",
    year: "2012",
    rating: 7.9,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0848228", title: "Мстители", originalTitle: "The Avengers", year: "2012", type: "Фильм" }),
    description: "Герои Marvel впервые собираются в команду, чтобы остановить вторжение Локи.",
    trailerUrl: "",
    longDescription: "«Мстители» — фильм 2012 года в жанрах Фантастика, Боевик, Приключения. Герои Marvel впервые собираются в команду, чтобы остановить вторжение Локи. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Joss Whedon" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
    ],
    cast: [
      { name: "Robert Downey Jr.", role: "Тони Старк" },
      { name: "Chris Evans", role: "Стив Роджерс" },
      { name: "Scarlett Johansson", role: "Наташа Романофф" },
      { name: "Chris Hemsworth", role: "Тор" },
    ],
  },
  {
    id: 136,
    kinopoiskId: 843649,
    imdbId: "tt4154756",
    slug: "avengers-infinity-war",
    title: "Мстители: Война бесконечности",
    originalTitle: "Avengers: Infinity War",
    searchTitles: ["мстители: война бесконечности", "avengers: infinity war", "avengers infinity war"],
    type: "Фильм",
    year: "2018",
    rating: 8.1,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt4154756", title: "Мстители: Война бесконечности", originalTitle: "Avengers: Infinity War", year: "2018", type: "Фильм" }),
    description: "Танос начинает собирать Камни Бесконечности, а герои разных миров пытаются его остановить.",
    trailerUrl: "",
    longDescription: "«Мстители: Война бесконечности» — фильм 2018 года в жанрах Фантастика, Боевик, Приключения. Танос начинает собирать Камни Бесконечности, а герои разных миров пытаются его остановить. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Anthony Russo, Joe Russo" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
    ],
    cast: [
      { name: "Robert Downey Jr.", role: "Тони Старк" },
      { name: "Chris Hemsworth", role: "Тор" },
      { name: "Josh Brolin", role: "Танос" },
      { name: "Chris Evans", role: "Стив Роджерс" },
    ],
  },
  {
    id: 137,
    kinopoiskId: 843650,
    imdbId: "tt4154796",
    slug: "avengers-endgame",
    title: "Мстители: Финал",
    originalTitle: "Avengers: Endgame",
    searchTitles: ["мстители: финал", "avengers: endgame", "avengers endgame"],
    type: "Фильм",
    year: "2019",
    rating: 7.9,
    genres: ["Фантастика", "Боевик", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt4154796", title: "Мстители: Финал", originalTitle: "Avengers: Endgame", year: "2019", type: "Фильм" }),
    description: "Оставшиеся герои ищут способ исправить последствия щелчка Таноса.",
    trailerUrl: "",
    longDescription: "«Мстители: Финал» — фильм 2019 года в жанрах Фантастика, Боевик, Драма. Оставшиеся герои ищут способ исправить последствия щелчка Таноса. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Anthony Russo, Joe Russo" },
      { label: "Жанры", value: "Фантастика, Боевик, Драма" },
    ],
    cast: [
      { name: "Robert Downey Jr.", role: "Тони Старк" },
      { name: "Chris Evans", role: "Стив Роджерс" },
      { name: "Scarlett Johansson", role: "Наташа Романофф" },
      { name: "Mark Ruffalo", role: "Брюс Бэннер" },
    ],
  },
  {
    id: 138,
    kinopoiskId: 61237,
    imdbId: "tt0371746",
    slug: "iron-man",
    title: "Железный человек",
    originalTitle: "Iron Man",
    searchTitles: ["железный человек", "iron man"],
    type: "Фильм",
    year: "2008",
    rating: 7.9,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0371746", title: "Железный человек", originalTitle: "Iron Man", year: "2008", type: "Фильм" }),
    description: "Миллиардер Тони Старк создаёт высокотехнологичный костюм и меняет собственный взгляд на оружейный бизнес.",
    trailerUrl: "",
    longDescription: "«Железный человек» — фильм 2008 года в жанрах Фантастика, Боевик, Приключения. Миллиардер Тони Старк создаёт высокотехнологичный костюм и меняет собственный взгляд на оружейный бизнес. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2008" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Jon Favreau" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
    ],
    cast: [
      { name: "Robert Downey Jr.", role: "Тони Старк" },
      { name: "Gwyneth Paltrow", role: "Пеппер Поттс" },
      { name: "Jeff Bridges", role: "Обадайя Стейн" },
      { name: "Terrence Howard", role: "Роуди" },
    ],
  },
  {
    id: 139,
    kinopoiskId: 689066,
    imdbId: "tt2015381",
    slug: "guardians-of-the-galaxy",
    title: "Стражи Галактики",
    originalTitle: "Guardians of the Galaxy",
    searchTitles: ["стражи галактики", "guardians of the galaxy"],
    type: "Фильм",
    year: "2014",
    rating: 7.8,
    genres: ["Фантастика", "Приключения", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt2015381", title: "Стражи Галактики", originalTitle: "Guardians of the Galaxy", year: "2014", type: "Фильм" }),
    description: "Неформальная команда космических авантюристов оказывается последней надеждой галактики.",
    trailerUrl: "",
    longDescription: "«Стражи Галактики» — фильм 2014 года в жанрах Фантастика, Приключения, Комедия. Неформальная команда космических авантюристов оказывается последней надеждой галактики. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "James Gunn" },
      { label: "Жанры", value: "Фантастика, Приключения, Комедия" },
    ],
    cast: [
      { name: "Chris Pratt", role: "Питер Квилл" },
      { name: "Zoe Saldaña", role: "Гамора" },
      { name: "Dave Bautista", role: "Дракс" },
      { name: "Vin Diesel", role: "Грут" },
    ],
  },
  {
    id: 140,
    kinopoiskId: 409600,
    imdbId: "tt1211837",
    slug: "doctor-strange",
    title: "Доктор Стрэндж",
    originalTitle: "Doctor Strange",
    searchTitles: ["доктор стрэндж", "doctor strange"],
    type: "Фильм",
    year: "2016",
    rating: 7.5,
    genres: ["Фэнтези", "Фантастика", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt1211837", title: "Доктор Стрэндж", originalTitle: "Doctor Strange", year: "2016", type: "Фильм" }),
    description: "Хирург Стивен Стрэндж после аварии открывает мир магии и других измерений.",
    trailerUrl: "",
    longDescription: "«Доктор Стрэндж» — фильм 2016 года в жанрах Фэнтези, Фантастика, Боевик. Хирург Стивен Стрэндж после аварии открывает мир магии и других измерений. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Scott Derrickson" },
      { label: "Жанры", value: "Фэнтези, Фантастика, Боевик" },
    ],
    cast: [
      { name: "Benedict Cumberbatch", role: "Стивен Стрэндж" },
      { name: "Chiwetel Ejiofor", role: "Мордо" },
      { name: "Rachel McAdams", role: "Кристин" },
      { name: "Tilda Swinton", role: "Древняя" },
    ],
  },
  {
    id: 141,
    kinopoiskId: 1309570,
    imdbId: "tt10872600",
    slug: "spider-man-no-way-home",
    title: "Человек-паук: Нет пути домой",
    originalTitle: "Spider-Man: No Way Home",
    searchTitles: ["человек-паук: нет пути домой", "spider-man: no way home", "spider man no way home"],
    type: "Фильм",
    year: "2021",
    rating: 7.9,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt10872600", title: "Человек-паук: Нет пути домой", originalTitle: "Spider-Man: No Way Home", year: "2021", type: "Фильм" }),
    description: "Питер Паркер просит Доктора Стрэнджа помочь с раскрытой личностью, но заклинание открывает путь гостям из других миров.",
    trailerUrl: "",
    longDescription: "«Человек-паук: Нет пути домой» — фильм 2021 года в жанрах Фантастика, Боевик, Приключения. Питер Паркер просит Доктора Стрэнджа помочь с раскрытой личностью, но заклинание открывает путь гостям из других миров. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Jon Watts" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
    ],
    cast: [
      { name: "Tom Holland", role: "Питер Паркер" },
      { name: "Zendaya", role: "ЭмДжей" },
      { name: "Benedict Cumberbatch", role: "Доктор Стрэндж" },
      { name: "Jacob Batalon", role: "Нед" },
    ],
  },
  {
    id: 142,
    kinopoiskId: 841700,
    imdbId: "tt3659388",
    slug: "the-martian",
    title: "Марсианин",
    originalTitle: "The Martian",
    searchTitles: ["марсианин", "the martian"],
    type: "Фильм",
    year: "2015",
    rating: 7.8,
    genres: ["Фантастика", "Приключения", "Драма"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt3659388", title: "Марсианин", originalTitle: "The Martian", year: "2015", type: "Фильм" }),
    description: "Астронавт Марк Уотни остаётся один на Марсе и пытается выжить до спасательной миссии.",
    trailerUrl: "",
    longDescription: "«Марсианин» — фильм 2015 года в жанрах Фантастика, Приключения, Драма. Астронавт Марк Уотни остаётся один на Марсе и пытается выжить до спасательной миссии. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Режиссёр", value: "Ridley Scott" },
      { label: "Жанры", value: "Фантастика, Приключения, Драма" },
    ],
    cast: [
      { name: "Matt Damon", role: "Марк Уотни" },
      { name: "Jessica Chastain", role: "Мелисса Льюис" },
      { name: "Kristen Wiig", role: "Энни" },
      { name: "Chiwetel Ejiofor", role: "Венкат Капур" },
    ],
  },
  {
    id: 143,
    kinopoiskId: 835086,
    imdbId: "tt1950186",
    slug: "ford-v-ferrari",
    title: "Ford против Ferrari",
    originalTitle: "Ford v Ferrari",
    searchTitles: ["ford против ferrari", "ford v ferrari"],
    type: "Фильм",
    year: "2019",
    rating: 8.2,
    genres: ["Биография", "Спорт", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt1950186", title: "Ford против Ferrari", originalTitle: "Ford v Ferrari", year: "2019", type: "Фильм" }),
    description: "Инженер Кэрролл Шелби и гонщик Кен Майлз пытаются создать машину, способную победить Ferrari в Ле-Мане.",
    trailerUrl: "",
    longDescription: "«Ford против Ferrari» — фильм 2019 года в жанрах Биография, Спорт, Драма. Инженер Кэрролл Шелби и гонщик Кен Майлз пытаются создать машину, способную победить Ferrari в Ле-Мане. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "James Mangold" },
      { label: "Жанры", value: "Биография, Спорт, Драма" },
    ],
    cast: [
      { name: "Matt Damon", role: "Кэрролл Шелби" },
      { name: "Christian Bale", role: "Кен Майлз" },
      { name: "Jon Bernthal", role: "Ли Якокка" },
      { name: "Caitríona Balfe", role: "Молли Майлз" },
    ],
  },
  {
    id: 144,
    kinopoiskId: 841081,
    imdbId: "tt3783958",
    slug: "la-la-land",
    title: "Ла-Ла Ленд",
    originalTitle: "La La Land",
    searchTitles: ["ла-ла ленд", "la la land"],
    type: "Фильм",
    year: "2016",
    rating: 7.9,
    genres: ["Мюзикл", "Мелодрама", "Драма"],
    countries: ["США", "Гонконг"],
    poster: getTmdbPoster({ imdbId: "tt3783958", title: "Ла-Ла Ленд", originalTitle: "La La Land", year: "2016", type: "Фильм" }),
    description: "Актриса и джазовый музыкант в Лос-Анджелесе пытаются совместить любовь и мечты о карьере.",
    trailerUrl: "",
    longDescription: "«Ла-Ла Ленд» — фильм 2016 года в жанрах Мюзикл, Мелодрама, Драма. Актриса и джазовый музыкант в Лос-Анджелесе пытаются совместить любовь и мечты о карьере. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Гонконг" },
      { label: "Режиссёр", value: "Damien Chazelle" },
      { label: "Жанры", value: "Мюзикл, Мелодрама, Драма" },
    ],
    cast: [
      { name: "Ryan Gosling", role: "Себастьян" },
      { name: "Emma Stone", role: "Миа" },
      { name: "John Legend", role: "Кит" },
      { name: "Rosemarie DeWitt", role: "Лора" },
    ],
  },
  {
    id: 145,
    kinopoiskId: 1188529,
    imdbId: "tt8946378",
    slug: "knives-out",
    title: "Достать ножи",
    originalTitle: "Knives Out",
    searchTitles: ["достать ножи", "knives out"],
    type: "Фильм",
    year: "2019",
    rating: 8.2,
    genres: ["Детектив", "Комедия", "Криминал"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt8946378", title: "Достать ножи", originalTitle: "Knives Out", year: "2019", type: "Фильм" }),
    description: "Детектив Бенуа Блан расследует смерть писателя в доме, где у каждого родственника есть свой мотив.",
    trailerUrl: "",
    longDescription: "«Достать ножи» — фильм 2019 года в жанрах Детектив, Комедия, Криминал. Детектив Бенуа Блан расследует смерть писателя в доме, где у каждого родственника есть свой мотив. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Rian Johnson" },
      { label: "Жанры", value: "Детектив, Комедия, Криминал" },
    ],
    cast: [
      { name: "Daniel Craig", role: "Бенуа Блан" },
      { name: "Ana de Armas", role: "Марта" },
      { name: "Chris Evans", role: "Рэнсом" },
      { name: "Jamie Lee Curtis", role: "Линда" },
    ],
  },
  {
    id: 146,
    kinopoiskId: 478052,
    imdbId: "tt1517268",
    slug: "barbie",
    title: "Барби",
    originalTitle: "Barbie",
    searchTitles: ["барби", "barbie"],
    type: "Фильм",
    year: "2023",
    rating: 7.1,
    genres: ["Комедия", "Приключения", "Фэнтези"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt1517268", title: "Барби", originalTitle: "Barbie", year: "2023", type: "Фильм" }),
    description: "Барби покидает идеальный Барбиленд и отправляется в реальный мир, где всё сложнее, чем на розовой открытке.",
    trailerUrl: "",
    longDescription: "«Барби» — фильм 2023 года в жанрах Комедия, Приключения, Фэнтези. Барби покидает идеальный Барбиленд и отправляется в реальный мир, где всё сложнее, чем на розовой открытке. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Режиссёр", value: "Greta Gerwig" },
      { label: "Жанры", value: "Комедия, Приключения, Фэнтези" },
    ],
    cast: [
      { name: "Margot Robbie", role: "Барби" },
      { name: "Ryan Gosling", role: "Кен" },
      { name: "America Ferrera", role: "Глория" },
      { name: "Ariana Greenblatt", role: "Саша" },
    ],
  },
  {
    id: 147,
    kinopoiskId: 1013343,
    imdbId: "tt6166392",
    slug: "wonka",
    title: "Вонка",
    originalTitle: "Wonka",
    searchTitles: ["вонка", "wonka"],
    type: "Фильм",
    year: "2023",
    rating: 7.2,
    genres: ["Мюзикл", "Фэнтези", "Комедия"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt6166392", title: "Вонка", originalTitle: "Wonka", year: "2023", type: "Фильм" }),
    description: "Молодой Вилли Вонка мечтает открыть шоколадную лавку и сталкивается с городским шоколадным картелем.",
    trailerUrl: "",
    longDescription: "«Вонка» — фильм 2023 года в жанрах Мюзикл, Фэнтези, Комедия. Молодой Вилли Вонка мечтает открыть шоколадную лавку и сталкивается с городским шоколадным картелем. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Режиссёр", value: "Paul King" },
      { label: "Жанры", value: "Мюзикл, Фэнтези, Комедия" },
    ],
    cast: [
      { name: "Timothée Chalamet", role: "Вилли Вонка" },
      { name: "Calah Lane", role: "Нудл" },
      { name: "Keegan-Michael Key", role: "Начальник полиции" },
      { name: "Hugh Grant", role: "Умпа-лумпа" },
    ],
  },
  {
    id: 148,
    kinopoiskId: 926540,
    imdbId: "tt4912910",
    slug: "mission-impossible-fallout",
    title: "Миссия невыполнима: Последствия",
    originalTitle: "Mission: Impossible - Fallout",
    searchTitles: ["миссия невыполнима: последствия", "mission: impossible - fallout", "mission impossible fallout"],
    type: "Фильм",
    year: "2018",
    rating: 7.3,
    genres: ["Боевик", "Триллер", "Приключения"],
    countries: ["США", "Китай", "Франция"],
    poster: getTmdbPoster({ imdbId: "tt4912910", title: "Миссия невыполнима: Последствия", originalTitle: "Mission: Impossible - Fallout", year: "2018", type: "Фильм" }),
    description: "Итан Хант пытается предотвратить катастрофу после проваленной операции и сталкивается с последствиями старых решений.",
    trailerUrl: "",
    longDescription: "«Миссия невыполнима: Последствия» — фильм 2018 года в жанрах Боевик, Триллер, Приключения. Итан Хант пытается предотвратить катастрофу после проваленной операции и сталкивается с последствиями старых решений. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Китай, Франция" },
      { label: "Режиссёр", value: "Christopher McQuarrie" },
      { label: "Жанры", value: "Боевик, Триллер, Приключения" },
    ],
    cast: [
      { name: "Tom Cruise", role: "Итан Хант" },
      { name: "Henry Cavill", role: "Огаст Уокер" },
      { name: "Ving Rhames", role: "Лютер" },
      { name: "Simon Pegg", role: "Бенджи" },
    ],
  },
  {
    id: 149,
    kinopoiskId: 749540,
    imdbId: "tt2802144",
    slug: "kingsman-the-secret-service",
    title: "Kingsman: Секретная служба",
    originalTitle: "Kingsman: The Secret Service",
    searchTitles: ["kingsman: секретная служба", "kingsman: the secret service", "kingsman the secret service", "кингсман", "секретная служба"],
    type: "Фильм",
    year: "2014",
    rating: 7.7,
    genres: ["Боевик", "Комедия", "Криминал", "Шпионаж"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ imdbId: "tt2802144", title: "Kingsman: Секретная служба", originalTitle: "Kingsman: The Secret Service", year: "2014", type: "Фильм" }),
    description: "Дерзкий шпионский боевик о парне с улицы, которого втягивают в элитную секретную службу с безупречными костюмами и очень жёсткими правилами.",
    trailerUrl: "",
    longDescription: "«Kingsman: Секретная служба» — первая большая глава франшизы и лучший вход в её тон: британский стиль, комиксная наглость, быстрый монтаж и агентская школа, где манеры важны не меньше реакции. Эггси получает шанс выбраться из обычной жизни, но обучение быстро становится не карьерным конкурсом, а проверкой характера. В карточке KinoLuma фильм теперь оформлен как полноценная часть франшизы: с жанрами, страной, режиссёром, студией, настроением и актёрским составом без технической шелухи для зрителя.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Длительность", value: "129 мин" },
      { label: "Студия", value: "Marv Films, Cloudy Productions, TSG Entertainment" },
      { label: "Франшиза", value: "Kingsman" },
      { label: "Режиссёр", value: "Мэттью Вон" },
      { label: "Настроение", value: "Стильно, дерзко, быстро" },
      { label: "Темы", value: "шпионская школа, выбор, класс, верность" },
    ],
    cast: [
      { name: "Тэрон Эджертон", role: "Эггси" },
      { name: "Колин Фёрт", role: "Гарри Харт" },
      { name: "Сэмюэл Л. Джексон", role: "Валентайн" },
      { name: "Марк Стронг", role: "Мерлин" },
      { name: "Софи Куксон", role: "Рокси" },
    ],
  },
  {
    id: 150,
    kinopoiskId: 1143242,
    imdbId: "tt8367814",
    slug: "the-gentlemen",
    title: "Джентльмены",
    originalTitle: "The Gentlemen",
    searchTitles: ["джентльмены", "the gentlemen"],
    type: "Фильм",
    year: "2019",
    rating: 8.5,
    genres: ["Криминал", "Комедия", "Боевик"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt8367814", title: "Джентльмены", originalTitle: "The Gentlemen", year: "2019", type: "Фильм" }),
    description: "Американский предприниматель в Лондоне пытается продать криминальную империю, но желающих вмешаться оказывается слишком много.",
    trailerUrl: "",
    longDescription: "«Джентльмены» — фильм 2019 года в жанрах Криминал, Комедия, Боевик. Американский предприниматель в Лондоне пытается продать криминальную империю, но желающих вмешаться оказывается слишком много. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Режиссёр", value: "Guy Ritchie" },
      { label: "Жанры", value: "Криминал, Комедия, Боевик" },
    ],
    cast: [
      { name: "Matthew McConaughey", role: "Микки Пирсон" },
      { name: "Charlie Hunnam", role: "Рэй" },
      { name: "Hugh Grant", role: "Флетчер" },
      { name: "Colin Farrell", role: "Тренер" },
    ],
  },
  {
    id: 151,
    kinopoiskId: 5424947,
    imdbId: "tt29355505",
    slug: "toy-story-5",
    title: "История игрушек 5",
    originalTitle: "Toy Story 5",
    searchTitles: ["история игрушек 5", "toy story 5"],
    type: "Мультфильм",
    year: "2026",
    rating: 0.0,
    genres: ["Мультфильм", "Фэнтези", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt29355505", title: "История игрушек 5", originalTitle: "Toy Story 5", year: "2026", type: "Мультфильм" }),
    description: "Вуди, Базз, Джесси и другие игрушки сталкиваются с новой угрозой для игры — вниманием ребёнка к цифровому устройству.",
    trailerUrl: "",
    longDescription: "«История игрушек 5» — мультфильм 2026 года в жанрах Мультфильм, Фэнтези, Драма. Вуди, Базз, Джесси и другие игрушки сталкиваются с новой угрозой для игры — вниманием ребёнка к цифровому устройству. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2026" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Andrew Stanton" },
      { label: "Жанры", value: "Мультфильм, Фэнтези, Драма" },
      { label: "Статус", value: "Ожидаемая премьера" },
    ],
    cast: [
      { name: "Tom Hanks", role: "Вуди" },
      { name: "Tim Allen", role: "Базз Лайтер" },
      { name: "Joan Cusack", role: "Джесси" },
    ],
  },
  {
    id: 152,
    kinopoiskId: 88124,
    imdbId: "tt0427340",
    slug: "masters-of-the-universe-2026",
    title: "Властелины вселенной",
    originalTitle: "Masters of the Universe",
    searchTitles: ["властелины вселенной", "masters of the universe", "masters of the universe 2026"],
    type: "Фильм",
    year: "2026",
    rating: 0.0,
    genres: ["Фантастика", "Фэнтези", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0427340", title: "Властелины вселенной", originalTitle: "Masters of the Universe", year: "2026", type: "Фильм" }),
    description: "Принц Адам возвращается к наследию Этернии и вступает в борьбу за силу, от которой зависит судьба его мира.",
    trailerUrl: "",
    longDescription: "«Властелины вселенной» — фильм 2026 года в жанрах Фантастика, Фэнтези, Боевик. Принц Адам возвращается к наследию Этернии и вступает в борьбу за силу, от которой зависит судьба его мира. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2026" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Travis Knight" },
      { label: "Жанры", value: "Фантастика, Фэнтези, Боевик" },
      { label: "Статус", value: "Ожидаемая премьера" },
    ],
    cast: [
      { name: "Nicholas Galitzine", role: "Принц Адам / Хи-Мен" },
    ],
  },
  {
    id: 153,
    kinopoiskId: 1040433,
    slug: "shrek-5",
    title: "Шрэк 5",
    originalTitle: "Shrek 5",
    searchTitles: ["шрэк 5", "shrek 5"],
    type: "Мультфильм",
    year: "2027",
    rating: 0.0,
    genres: ["Мультфильм", "Фэнтези", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ title: "Шрэк 5", originalTitle: "Shrek 5", year: "2027", type: "Мультфильм" }),
    description: "Шрэк, Осёл и Фиона возвращаются в новую главу сказочного мира, где привычный уют снова грозит превратиться в приключение.",
    trailerUrl: "",
    longDescription: "«Шрэк 5» — мультфильм 2027 года в жанрах Мультфильм, Фэнтези, Комедия. Шрэк, Осёл и Фиона возвращаются в новую главу сказочного мира, где привычный уют снова грозит превратиться в приключение. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2027" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Brad Ableson, Walt Dohrn, Conrad Vernon" },
      { label: "Жанры", value: "Мультфильм, Фэнтези, Комедия" },
      { label: "Статус", value: "Ожидаемая премьера" },
    ],
    cast: [
      { name: "Mike Myers", role: "Шрэк" },
      { name: "Eddie Murphy", role: "Осел" },
      { name: "Cameron Diaz", role: "Фиона" },
      { name: "Zendaya", role: "Новый персонаж" },
    ],
  },
  {
    id: 154,
    kinopoiskId: 5494049,
    slug: "spider-man-brand-new-day",
    title: "Человек-паук: Новый день",
    originalTitle: "Spider-Man: Brand New Day",
    searchTitles: ["человек-паук: новый день", "spider-man: brand new day", "spider man brand new day"],
    type: "Фильм",
    year: "2026",
    rating: 0.0,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ title: "Человек-паук: Новый день", originalTitle: "Spider-Man: Brand New Day", year: "2026", type: "Фильм" }),
    description: "Новая глава истории Питера Паркера после событий мультивселенной и утраты привычной жизни.",
    trailerUrl: "",
    longDescription: "«Человек-паук: Новый день» — фильм 2026 года в жанрах Фантастика, Боевик, Приключения. Новая глава истории Питера Паркера после событий мультивселенной и утраты привычной жизни. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2026" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Destin Daniel Cretton" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Статус", value: "Ожидаемая премьера" },
    ],
    cast: [
      { name: "Tom Holland", role: "Питер Паркер" },
    ],
  },
  {
    id: 155,
    kinopoiskId: 5437088,
    slug: "the-mandalorian-and-grogu",
    title: "Мандалорец и Грогу",
    originalTitle: "The Mandalorian & Grogu",
    searchTitles: ["мандалорец и грогу", "the mandalorian & grogu", "the mandalorian and grogu"],
    type: "Фильм",
    year: "2026",
    rating: 7.0,
    genres: ["Фантастика", "Фэнтези", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ title: "Мандалорец и Грогу", originalTitle: "The Mandalorian & Grogu", year: "2026", type: "Фильм" }),
    description: "Дин Джарин и Грогу отправляются в полнометражное приключение во вселенной «Звёздных войн».",
    trailerUrl: "",
    longDescription: "«Мандалорец и Грогу» — фильм 2026 года в жанрах Фантастика, Фэнтези, Боевик. Дин Джарин и Грогу отправляются в полнометражное приключение во вселенной «Звёздных войн». Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2026" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Jon Favreau" },
      { label: "Жанры", value: "Фантастика, Фэнтези, Боевик" },
    ],
    cast: [
      { name: "Pedro Pascal", role: "Мандалорец" },
    ],
  },
  {
    id: 156,
    kinopoiskId: 5927239,
    slug: "the-hunger-games-sunrise-on-the-reaping",
    title: "Голодные игры: Рассвет Жатвы",
    originalTitle: "The Hunger Games: Sunrise on the Reaping",
    searchTitles: ["голодные игры: рассвет жатвы", "the hunger games: sunrise on the reaping", "the hunger games sunrise on the reaping"],
    type: "Фильм",
    year: "2026",
    rating: 0.0,
    genres: ["Фантастика", "Боевик", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ title: "Голодные игры: Рассвет Жатвы", originalTitle: "The Hunger Games: Sunrise on the Reaping", year: "2026", type: "Фильм" }),
    description: "Молодой Хеймитч Эбернети становится участником 50-х Голодных игр, где шансы на выживание почти невозможны.",
    trailerUrl: "",
    longDescription: "«Голодные игры: Рассвет Жатвы» — фильм 2026 года в жанрах Фантастика, Боевик, Драма. Молодой Хеймитч Эбернети становится участником 50-х Голодных игр, где шансы на выживание почти невозможны. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2026" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Francis Lawrence" },
      { label: "Жанры", value: "Фантастика, Боевик, Драма" },
      { label: "Статус", value: "Ожидаемая премьера" },
    ],
    cast: [
      { name: "Joseph Zada", role: "Хеймитч Эбернети" },
    ],
  },
  {
    id: 157,
    kinopoiskId: 5060245,
    slug: "avengers-doomsday",
    title: "Мстители: Доктор Дум",
    originalTitle: "Avengers: Doomsday",
    searchTitles: ["мстители: доктор дум", "avengers: doomsday", "avengers doomsday"],
    type: "Фильм",
    year: "2026",
    rating: 0.0,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ title: "Мстители: Доктор Дум", originalTitle: "Avengers: Doomsday", year: "2026", type: "Фильм" }),
    description: "Герои разных команд Marvel объединяются перед угрозой Доктора Дума.",
    trailerUrl: "",
    longDescription: "«Мстители: Доктор Дум» — фильм 2026 года в жанрах Фантастика, Боевик, Приключения. Герои разных команд Marvel объединяются перед угрозой Доктора Дума. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2026" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Anthony Russo, Joe Russo" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Статус", value: "Ожидаемая премьера" },
    ],
    cast: [
      { name: "Robert Downey Jr.", role: "Доктор Дум" },
      { name: "Pedro Pascal", role: "Рид Ричардс" },
      { name: "Chris Hemsworth", role: "Тор" },
    ],
  },
  {
    id: 158,
    kinopoiskId: 5458743,
    slug: "dune-part-three",
    title: "Дюна: Часть третья",
    originalTitle: "Dune: Part Three",
    searchTitles: ["дюна: часть третья", "dune: part three", "dune part three"],
    type: "Фильм",
    year: "2026",
    rating: 0.0,
    genres: ["Фантастика", "Боевик", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ title: "Дюна: Часть третья", originalTitle: "Dune: Part Three", year: "2026", type: "Фильм" }),
    description: "Продолжение истории Пола Атрейдеса развивает последствия власти, пророчества и войны за Арракис.",
    trailerUrl: "",
    longDescription: "«Дюна: Часть третья» — фильм 2026 года в жанрах Фантастика, Боевик, Драма. Продолжение истории Пола Атрейдеса развивает последствия власти, пророчества и войны за Арракис. Карточка добавлена в KinoLuma без выдуманных фактов: если точной оценки ещё нет, рейтинг оставлен пустым, а варианты просмотра подключаются автоматически, когда они доступны в каталоге.",
    facts: [
      { label: "Год", value: "2026" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр", value: "Denis Villeneuve" },
      { label: "Жанры", value: "Фантастика, Боевик, Драма" },
      { label: "Статус", value: "Ожидаемая премьера" },
    ],
    cast: [
      { name: "Timothée Chalamet", role: "Пол Атрейдес" },
      { name: "Zendaya", role: "Чани" },
      { name: "Rebecca Ferguson", role: "Леди Джессика" },
      { name: "Anya Taylor-Joy", role: "Алия" },
    ],
  },
  {
    id: 159,
    kinopoiskId: 8408,
    tmdbId: 674,
    imdbId: "tt0330373",
    slug: "harry-potter-and-the-goblet-of-fire",
    title: "Гарри Поттер и Кубок огня",
    originalTitle: "Harry Potter and the Goblet of Fire",
    searchTitles: ["гарри поттер и кубок огня", "harry potter and the goblet of fire"],
    type: "Фильм",
    year: "2005",
    rating: 7.7,
    genres: ["Фэнтези", "Приключения", "Семейный"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 674, imdbId: "tt0330373", title: "Гарри Поттер и Кубок огня", originalTitle: "Harry Potter and the Goblet of Fire", year: "2005", type: "Фильм" }),
    description: "Четвёртый год Гарри в Хогвартсе превращается в опасное испытание после неожиданного участия в Турнире трёх волшебников.",
    trailerUrl: "",
    longDescription: "«Гарри Поттер и Кубок огня» — фильм 2005 года. Четвёртый год Гарри в Хогвартсе превращается в опасное испытание после неожиданного участия в Турнире трёх волшебников. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2005" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр/создатель", value: "Mike Newell" },
      { label: "Жанры", value: "Фэнтези, Приключения, Семейный" },
    ],
    cast: [
      { name: "Daniel Radcliffe", role: "" },
      { name: "Emma Watson", role: "" },
      { name: "Rupert Grint", role: "" },
      { name: "Ralph Fiennes", role: "" }
    ],
  },
  {
    id: 160,
    kinopoiskId: 48356,
    tmdbId: 675,
    imdbId: "tt0373889",
    slug: "harry-potter-and-the-order-of-the-phoenix",
    title: "Гарри Поттер и Орден Феникса",
    originalTitle: "Harry Potter and the Order of the Phoenix",
    searchTitles: ["гарри поттер и орден феникса", "harry potter and the order of the phoenix"],
    type: "Фильм",
    year: "2007",
    rating: 7.5,
    genres: ["Фэнтези", "Приключения", "Семейный"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 675, imdbId: "tt0373889", title: "Гарри Поттер и Орден Феникса", originalTitle: "Harry Potter and the Order of the Phoenix", year: "2007", type: "Фильм" }),
    description: "Гарри сталкивается с недоверием магического мира и собирает друзей для сопротивления возвращающейся угрозе.",
    trailerUrl: "",
    longDescription: "«Гарри Поттер и Орден Феникса» — фильм 2007 года. Гарри сталкивается с недоверием магического мира и собирает друзей для сопротивления возвращающейся угрозе. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2007" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр/создатель", value: "David Yates" },
      { label: "Жанры", value: "Фэнтези, Приключения, Семейный" },
    ],
    cast: [
      { name: "Daniel Radcliffe", role: "" },
      { name: "Emma Watson", role: "" },
      { name: "Rupert Grint", role: "" },
      { name: "Gary Oldman", role: "" }
    ],
  },
  {
    id: 161,
    kinopoiskId: 89515,
    tmdbId: 767,
    imdbId: "tt0417741",
    slug: "harry-potter-and-the-half-blood-prince",
    title: "Гарри Поттер и Принц-полукровка",
    originalTitle: "Harry Potter and the Half-Blood Prince",
    searchTitles: ["гарри поттер и принц-полукровка", "harry potter and the half-blood prince"],
    type: "Фильм",
    year: "2009",
    rating: 7.6,
    genres: ["Фэнтези", "Приключения", "Драма"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 767, imdbId: "tt0417741", title: "Гарри Поттер и Принц-полукровка", originalTitle: "Harry Potter and the Half-Blood Prince", year: "2009", type: "Фильм" }),
    description: "Гарри изучает прошлое Волан-де-Морта и находит загадочную книгу, связанную с Принцем-полукровкой.",
    trailerUrl: "",
    longDescription: "«Гарри Поттер и Принц-полукровка» — фильм 2009 года. Гарри изучает прошлое Волан-де-Морта и находит загадочную книгу, связанную с Принцем-полукровкой. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2009" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр/создатель", value: "David Yates" },
      { label: "Жанры", value: "Фэнтези, Приключения, Драма" },
    ],
    cast: [
      { name: "Daniel Radcliffe", role: "" },
      { name: "Emma Watson", role: "" },
      { name: "Rupert Grint", role: "" },
      { name: "Michael Gambon", role: "" }
    ],
  },
  {
    id: 162,
    kinopoiskId: 276762,
    tmdbId: 12444,
    imdbId: "tt0926084",
    slug: "harry-potter-and-the-deathly-hallows-part-1",
    title: "Гарри Поттер и Дары Смерти: Часть 1",
    originalTitle: "Harry Potter and the Deathly Hallows: Part 1",
    searchTitles: ["гарри поттер и дары смерти: часть 1", "harry potter and the deathly hallows: part 1", "harry potter and the deathly hallows part 1"],
    type: "Фильм",
    year: "2010",
    rating: 7.7,
    genres: ["Фэнтези", "Приключения", "Драма"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 12444, imdbId: "tt0926084", title: "Гарри Поттер и Дары Смерти: Часть 1", originalTitle: "Harry Potter and the Deathly Hallows: Part 1", year: "2010", type: "Фильм" }),
    description: "Гарри, Рон и Гермиона покидают Хогвартс и отправляются на поиски крестражей.",
    trailerUrl: "",
    longDescription: "«Гарри Поттер и Дары Смерти: Часть 1» — фильм 2010 года. Гарри, Рон и Гермиона покидают Хогвартс и отправляются на поиски крестражей. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр/создатель", value: "David Yates" },
      { label: "Жанры", value: "Фэнтези, Приключения, Драма" },
    ],
    cast: [
      { name: "Daniel Radcliffe", role: "" },
      { name: "Emma Watson", role: "" },
      { name: "Rupert Grint", role: "" }
    ],
  },
  {
    id: 163,
    kinopoiskId: 407636,
    tmdbId: 12445,
    imdbId: "tt1201607",
    slug: "harry-potter-and-the-deathly-hallows-part-2",
    title: "Гарри Поттер и Дары Смерти: Часть 2",
    originalTitle: "Harry Potter and the Deathly Hallows: Part 2",
    searchTitles: ["гарри поттер и дары смерти: часть 2", "harry potter and the deathly hallows: part 2", "harry potter and the deathly hallows part 2"],
    type: "Фильм",
    year: "2011",
    rating: 8.1,
    genres: ["Фэнтези", "Приключения", "Драма"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 12445, imdbId: "tt1201607", title: "Гарри Поттер и Дары Смерти: Часть 2", originalTitle: "Harry Potter and the Deathly Hallows: Part 2", year: "2011", type: "Фильм" }),
    description: "Финальная битва за Хогвартс решает судьбу Гарри, его друзей и всего магического мира.",
    trailerUrl: "",
    longDescription: "«Гарри Поттер и Дары Смерти: Часть 2» — фильм 2011 года. Финальная битва за Хогвартс решает судьбу Гарри, его друзей и всего магического мира. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр/создатель", value: "David Yates" },
      { label: "Жанры", value: "Фэнтези, Приключения, Драма" },
    ],
    cast: [
      { name: "Daniel Radcliffe", role: "" },
      { name: "Emma Watson", role: "" },
      { name: "Rupert Grint", role: "" },
      { name: "Ralph Fiennes", role: "" }
    ],
  },
  {
    id: 164,
    tmdbId: 259316,
    imdbId: "tt3183660",
    slug: "fantastic-beasts-and-where-to-find-them",
    title: "Фантастические твари и где они обитают",
    originalTitle: "Fantastic Beasts and Where to Find Them",
    searchTitles: ["фантастические твари и где они обитают", "fantastic beasts and where to find them"],
    type: "Фильм",
    year: "2016",
    rating: 7.2,
    genres: ["Фэнтези", "Приключения", "Семейный"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 259316, imdbId: "tt3183660", title: "Фантастические твари и где они обитают", originalTitle: "Fantastic Beasts and Where to Find Them", year: "2016", type: "Фильм" }),
    description: "Магозоолог Ньют Саламандер приезжает в Нью-Йорк, где несколько волшебных существ случайно оказываются на свободе.",
    trailerUrl: "",
    longDescription: "«Фантастические твари и где они обитают» — фильм 2016 года. Магозоолог Ньют Саламандер приезжает в Нью-Йорк, где несколько волшебных существ случайно оказываются на свободе. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр/создатель", value: "David Yates" },
      { label: "Жанры", value: "Фэнтези, Приключения, Семейный" },
    ],
    cast: [
      { name: "Eddie Redmayne", role: "" },
      { name: "Katherine Waterston", role: "" },
      { name: "Dan Fogler", role: "" }
    ],
  },
  {
    id: 165,
    tmdbId: 338952,
    imdbId: "tt4123430",
    slug: "fantastic-beasts-the-crimes-of-grindelwald",
    title: "Фантастические твари: Преступления Грин-де-Вальда",
    originalTitle: "Fantastic Beasts: The Crimes of Grindelwald",
    searchTitles: ["фантастические твари: преступления грин-де-вальда", "fantastic beasts: the crimes of grindelwald", "fantastic beasts the crimes of grindelwald"],
    type: "Фильм",
    year: "2018",
    rating: 6.5,
    genres: ["Фэнтези", "Приключения"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 338952, imdbId: "tt4123430", title: "Фантастические твари: Преступления Грин-де-Вальда", originalTitle: "Fantastic Beasts: The Crimes of Grindelwald", year: "2018", type: "Фильм" }),
    description: "Ньют Саламандер оказывается втянут в противостояние с Грин-де-Вальдом, чьи планы угрожают миру магов и людей.",
    trailerUrl: "",
    longDescription: "«Фантастические твари: Преступления Грин-де-Вальда» — фильм 2018 года. Ньют Саламандер оказывается втянут в противостояние с Грин-де-Вальдом, чьи планы угрожают миру магов и людей. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр/создатель", value: "David Yates" },
      { label: "Жанры", value: "Фэнтези, Приключения" },
    ],
    cast: [
      { name: "Eddie Redmayne", role: "" },
      { name: "Katherine Waterston", role: "" },
      { name: "Jude Law", role: "" }
    ],
  },
  {
    id: 166,
    tmdbId: 338953,
    imdbId: "tt4123432",
    slug: "fantastic-beasts-the-secrets-of-dumbledore",
    title: "Фантастические твари: Тайны Дамблдора",
    originalTitle: "Fantastic Beasts: The Secrets of Dumbledore",
    searchTitles: ["фантастические твари: тайны дамблдора", "fantastic beasts: the secrets of dumbledore", "fantastic beasts the secrets of dumbledore"],
    type: "Фильм",
    year: "2022",
    rating: 6.2,
    genres: ["Фэнтези", "Приключения"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 338953, imdbId: "tt4123432", title: "Фантастические твари: Тайны Дамблдора", originalTitle: "Fantastic Beasts: The Secrets of Dumbledore", year: "2022", type: "Фильм" }),
    description: "Дамблдор собирает команду, чтобы остановить Грин-де-Вальда и его влияние на магическое сообщество.",
    trailerUrl: "",
    longDescription: "«Фантастические твари: Тайны Дамблдора» — фильм 2022 года. Дамблдор собирает команду, чтобы остановить Грин-де-Вальда и его влияние на магическое сообщество. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Режиссёр/создатель", value: "David Yates" },
      { label: "Жанры", value: "Фэнтези, Приключения" },
    ],
    cast: [
      { name: "Eddie Redmayne", role: "" },
      { name: "Jude Law", role: "" },
      { name: "Mads Mikkelsen", role: "" }
    ],
  },
  {
    id: 167,
    tmdbId: 49051,
    imdbId: "tt0903624",
    slug: "the-hobbit-an-unexpected-journey",
    title: "Хоббит: Нежданное путешествие",
    originalTitle: "The Hobbit: An Unexpected Journey",
    searchTitles: ["хоббит: нежданное путешествие", "the hobbit: an unexpected journey", "the hobbit an unexpected journey"],
    type: "Фильм",
    year: "2012",
    rating: 7.8,
    genres: ["Фэнтези", "Приключения"],
    countries: ["Новая Зеландия", "США"],
    poster: getTmdbPoster({ tmdbId: 49051, imdbId: "tt0903624", title: "Хоббит: Нежданное путешествие", originalTitle: "The Hobbit: An Unexpected Journey", year: "2012", type: "Фильм" }),
    description: "Бильбо Бэггинс присоединяется к отряду гномов и отправляется к Одинокой горе.",
    trailerUrl: "",
    longDescription: "«Хоббит: Нежданное путешествие» — фильм 2012 года. Бильбо Бэггинс присоединяется к отряду гномов и отправляется к Одинокой горе. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Новая Зеландия, США" },
      { label: "Режиссёр/создатель", value: "Peter Jackson" },
      { label: "Жанры", value: "Фэнтези, Приключения" },
    ],
    cast: [
      { name: "Martin Freeman", role: "" },
      { name: "Ian McKellen", role: "" },
      { name: "Richard Armitage", role: "" }
    ],
  },
  {
    id: 168,
    tmdbId: 57158,
    imdbId: "tt1170358",
    slug: "the-hobbit-the-desolation-of-smaug",
    title: "Хоббит: Пустошь Смауга",
    originalTitle: "The Hobbit: The Desolation of Smaug",
    searchTitles: ["хоббит: пустошь смауга", "the hobbit: the desolation of smaug", "the hobbit the desolation of smaug"],
    type: "Фильм",
    year: "2013",
    rating: 7.8,
    genres: ["Фэнтези", "Приключения"],
    countries: ["Новая Зеландия", "США"],
    poster: getTmdbPoster({ tmdbId: 57158, imdbId: "tt1170358", title: "Хоббит: Пустошь Смауга", originalTitle: "The Hobbit: The Desolation of Smaug", year: "2013", type: "Фильм" }),
    description: "Бильбо и гномы продолжают путь к Одинокой горе, где их ждёт дракон Смауг.",
    trailerUrl: "",
    longDescription: "«Хоббит: Пустошь Смауга» — фильм 2013 года. Бильбо и гномы продолжают путь к Одинокой горе, где их ждёт дракон Смауг. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Новая Зеландия, США" },
      { label: "Режиссёр/создатель", value: "Peter Jackson" },
      { label: "Жанры", value: "Фэнтези, Приключения" },
    ],
    cast: [
      { name: "Martin Freeman", role: "" },
      { name: "Ian McKellen", role: "" },
      { name: "Richard Armitage", role: "" }
    ],
  },
  {
    id: 169,
    tmdbId: 122917,
    imdbId: "tt2310332",
    slug: "the-hobbit-the-battle-of-the-five-armies",
    title: "Хоббит: Битва пяти воинств",
    originalTitle: "The Hobbit: The Battle of the Five Armies",
    searchTitles: ["хоббит: битва пяти воинств", "the hobbit: the battle of the five armies", "the hobbit the battle of the five armies"],
    type: "Фильм",
    year: "2014",
    rating: 7.4,
    genres: ["Фэнтези", "Приключения"],
    countries: ["Новая Зеландия", "США"],
    poster: getTmdbPoster({ tmdbId: 122917, imdbId: "tt2310332", title: "Хоббит: Битва пяти воинств", originalTitle: "The Hobbit: The Battle of the Five Armies", year: "2014", type: "Фильм" }),
    description: "Судьба Одинокой горы приводит к масштабному столкновению людей, эльфов, гномов и орков.",
    trailerUrl: "",
    longDescription: "«Хоббит: Битва пяти воинств» — фильм 2014 года. Судьба Одинокой горы приводит к масштабному столкновению людей, эльфов, гномов и орков. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Новая Зеландия, США" },
      { label: "Режиссёр/создатель", value: "Peter Jackson" },
      { label: "Жанры", value: "Фэнтези, Приключения" },
    ],
    cast: [
      { name: "Martin Freeman", role: "" },
      { name: "Ian McKellen", role: "" },
      { name: "Richard Armitage", role: "" }
    ],
  },
  {
    id: 170,
    tmdbId: 58,
    imdbId: "tt0383574",
    slug: "pirates-of-the-caribbean-dead-mans-chest",
    title: "Пираты Карибского моря: Сундук мертвеца",
    originalTitle: "Pirates of the Caribbean: Dead Man's Chest",
    searchTitles: ["пираты карибского моря: сундук мертвеца", "pirates of the caribbean: dead man's chest", "pirates of the caribbean dead man's chest"],
    type: "Фильм",
    year: "2006",
    rating: 7.4,
    genres: ["Фэнтези", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 58, imdbId: "tt0383574", title: "Пираты Карибского моря: Сундук мертвеца", originalTitle: "Pirates of the Caribbean: Dead Man's Chest", year: "2006", type: "Фильм" }),
    description: "Джек Воробей пытается избежать долга перед Дэйви Джонсом, а его друзья оказываются втянуты в новую морскую авантюру.",
    trailerUrl: "",
    longDescription: "«Пираты Карибского моря: Сундук мертвеца» — фильм 2006 года. Джек Воробей пытается избежать долга перед Дэйви Джонсом, а его друзья оказываются втянуты в новую морскую авантюру. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2006" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Gore Verbinski" },
      { label: "Жанры", value: "Фэнтези, Приключения, Боевик" },
    ],
    cast: [
      { name: "Johnny Depp", role: "" },
      { name: "Orlando Bloom", role: "" },
      { name: "Keira Knightley", role: "" }
    ],
  },
  {
    id: 171,
    tmdbId: 285,
    imdbId: "tt0449088",
    slug: "pirates-of-the-caribbean-at-worlds-end",
    title: "Пираты Карибского моря: На краю света",
    originalTitle: "Pirates of the Caribbean: At World's End",
    searchTitles: ["пираты карибского моря: на краю света", "pirates of the caribbean: at world's end", "pirates of the caribbean at world's end"],
    type: "Фильм",
    year: "2007",
    rating: 7.1,
    genres: ["Фэнтези", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 285, imdbId: "tt0449088", title: "Пираты Карибского моря: На краю света", originalTitle: "Pirates of the Caribbean: At World's End", year: "2007", type: "Фильм" }),
    description: "Пираты объединяются перед решающей битвой за свободу морей.",
    trailerUrl: "",
    longDescription: "«Пираты Карибского моря: На краю света» — фильм 2007 года. Пираты объединяются перед решающей битвой за свободу морей. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2007" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Gore Verbinski" },
      { label: "Жанры", value: "Фэнтези, Приключения, Боевик" },
    ],
    cast: [
      { name: "Johnny Depp", role: "" },
      { name: "Orlando Bloom", role: "" },
      { name: "Keira Knightley", role: "" }
    ],
  },
  {
    id: 172,
    tmdbId: 1865,
    imdbId: "tt1298650",
    slug: "pirates-of-the-caribbean-on-stranger-tides",
    title: "Пираты Карибского моря: На странных берегах",
    originalTitle: "Pirates of the Caribbean: On Stranger Tides",
    searchTitles: ["пираты карибского моря: на странных берегах", "pirates of the caribbean: on stranger tides", "pirates of the caribbean on stranger tides"],
    type: "Фильм",
    year: "2011",
    rating: 6.6,
    genres: ["Фэнтези", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1865, imdbId: "tt1298650", title: "Пираты Карибского моря: На странных берегах", originalTitle: "Pirates of the Caribbean: On Stranger Tides", year: "2011", type: "Фильм" }),
    description: "Джек Воробей отправляется на поиски Источника вечной молодости и сталкивается с Чёрной Бородой.",
    trailerUrl: "",
    longDescription: "«Пираты Карибского моря: На странных берегах» — фильм 2011 года. Джек Воробей отправляется на поиски Источника вечной молодости и сталкивается с Чёрной Бородой. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Rob Marshall" },
      { label: "Жанры", value: "Фэнтези, Приключения, Боевик" },
    ],
    cast: [
      { name: "Johnny Depp", role: "" },
      { name: "Penélope Cruz", role: "" },
      { name: "Ian McShane", role: "" }
    ],
  },
  {
    id: 173,
    tmdbId: 166426,
    imdbId: "tt1790809",
    slug: "pirates-of-the-caribbean-dead-men-tell-no-tales",
    title: "Пираты Карибского моря: Мертвецы не рассказывают сказки",
    originalTitle: "Pirates of the Caribbean: Dead Men Tell No Tales",
    searchTitles: ["пираты карибского моря: мертвецы не рассказывают сказки", "pirates of the caribbean: dead men tell no tales", "pirates of the caribbean dead men tell no tales"],
    type: "Фильм",
    year: "2017",
    rating: 6.5,
    genres: ["Фэнтези", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 166426, imdbId: "tt1790809", title: "Пираты Карибского моря: Мертвецы не рассказывают сказки", originalTitle: "Pirates of the Caribbean: Dead Men Tell No Tales", year: "2017", type: "Фильм" }),
    description: "Капитан Салазар охотится за Джеком Воробьём, а спасением может стать древний артефакт.",
    trailerUrl: "",
    longDescription: "«Пираты Карибского моря: Мертвецы не рассказывают сказки» — фильм 2017 года. Капитан Салазар охотится за Джеком Воробьём, а спасением может стать древний артефакт. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Joachim Rønning, Espen Sandberg" },
      { label: "Жанры", value: "Фэнтези, Приключения, Боевик" },
    ],
    cast: [
      { name: "Johnny Depp", role: "" },
      { name: "Javier Bardem", role: "" },
      { name: "Geoffrey Rush", role: "" }
    ],
  },
  {
    id: 174,
    tmdbId: 863,
    imdbId: "tt0120363",
    slug: "toy-story-2",
    title: "История игрушек 2",
    originalTitle: "Toy Story 2",
    searchTitles: ["история игрушек 2", "toy story 2"],
    type: "Мультфильм",
    year: "1999",
    rating: 7.9,
    genres: ["Мультфильм", "Комедия", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 863, imdbId: "tt0120363", title: "История игрушек 2", originalTitle: "Toy Story 2", year: "1999", type: "Мультфильм" }),
    description: "Вуди похищают как редкую коллекционную игрушку, и друзья отправляются его спасать.",
    trailerUrl: "",
    longDescription: "«История игрушек 2» — мультфильм 1999 года. Вуди похищают как редкую коллекционную игрушку, и друзья отправляются его спасать. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "1999" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "John Lasseter" },
      { label: "Жанры", value: "Мультфильм, Комедия, Семейный" },
    ],
    cast: [
      { name: "Tom Hanks", role: "" },
      { name: "Tim Allen", role: "" },
      { name: "Joan Cusack", role: "" }
    ],
  },
  {
    id: 175,
    tmdbId: 10193,
    imdbId: "tt0435761",
    slug: "toy-story-3",
    title: "История игрушек: Большой побег",
    originalTitle: "Toy Story 3",
    searchTitles: ["история игрушек: большой побег", "toy story 3"],
    type: "Мультфильм",
    year: "2010",
    rating: 8.3,
    genres: ["Мультфильм", "Комедия", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 10193, imdbId: "tt0435761", title: "История игрушек: Большой побег", originalTitle: "Toy Story 3", year: "2010", type: "Мультфильм" }),
    description: "Игрушки Энди попадают в детский сад и пытаются понять, что ждёт их после взросления хозяина.",
    trailerUrl: "",
    longDescription: "«История игрушек: Большой побег» — мультфильм 2010 года. Игрушки Энди попадают в детский сад и пытаются понять, что ждёт их после взросления хозяина. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Lee Unkrich" },
      { label: "Жанры", value: "Мультфильм, Комедия, Семейный" },
    ],
    cast: [
      { name: "Tom Hanks", role: "" },
      { name: "Tim Allen", role: "" },
      { name: "Joan Cusack", role: "" }
    ],
  },
  {
    id: 176,
    tmdbId: 301528,
    imdbId: "tt1979376",
    slug: "toy-story-4",
    title: "История игрушек 4",
    originalTitle: "Toy Story 4",
    searchTitles: ["история игрушек 4", "toy story 4"],
    type: "Мультфильм",
    year: "2019",
    rating: 7.7,
    genres: ["Мультфильм", "Комедия", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 301528, imdbId: "tt1979376", title: "История игрушек 4", originalTitle: "Toy Story 4", year: "2019", type: "Мультфильм" }),
    description: "Вуди встречает Бо Пип и переосмысливает своё место рядом с новой хозяйкой.",
    trailerUrl: "",
    longDescription: "«История игрушек 4» — мультфильм 2019 года. Вуди встречает Бо Пип и переосмысливает своё место рядом с новой хозяйкой. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Josh Cooley" },
      { label: "Жанры", value: "Мультфильм, Комедия, Семейный" },
    ],
    cast: [
      { name: "Tom Hanks", role: "" },
      { name: "Tim Allen", role: "" },
      { name: "Annie Potts", role: "" }
    ],
  },
  {
    id: 177,
    tmdbId: 809,
    imdbId: "tt0298148",
    slug: "shrek-2",
    title: "Шрэк 2",
    originalTitle: "Shrek 2",
    searchTitles: ["шрэк 2", "shrek 2"],
    type: "Мультфильм",
    year: "2004",
    rating: 7.4,
    genres: ["Мультфильм", "Фэнтези", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 809, imdbId: "tt0298148", title: "Шрэк 2", originalTitle: "Shrek 2", year: "2004", type: "Мультфильм" }),
    description: "Шрэк и Фиона едут знакомиться с королевскими родителями, а сказочная идиллия быстро превращается в хаос.",
    trailerUrl: "",
    longDescription: "«Шрэк 2» — мультфильм 2004 года. Шрэк и Фиона едут знакомиться с королевскими родителями, а сказочная идиллия быстро превращается в хаос. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2004" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Andrew Adamson, Kelly Asbury, Conrad Vernon" },
      { label: "Жанры", value: "Мультфильм, Фэнтези, Комедия" },
    ],
    cast: [
      { name: "Mike Myers", role: "" },
      { name: "Eddie Murphy", role: "" },
      { name: "Cameron Diaz", role: "" }
    ],
  },
  {
    id: 178,
    tmdbId: 810,
    imdbId: "tt0413267",
    slug: "shrek-the-third",
    title: "Шрэк Третий",
    originalTitle: "Shrek the Third",
    searchTitles: ["шрэк третий", "shrek the third"],
    type: "Мультфильм",
    year: "2007",
    rating: 6.1,
    genres: ["Мультфильм", "Фэнтези", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 810, imdbId: "tt0413267", title: "Шрэк Третий", originalTitle: "Shrek the Third", year: "2007", type: "Мультфильм" }),
    description: "Шрэк ищет наследника трона, чтобы самому не становиться королём Тридевятого королевства.",
    trailerUrl: "",
    longDescription: "«Шрэк Третий» — мультфильм 2007 года. Шрэк ищет наследника трона, чтобы самому не становиться королём Тридевятого королевства. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2007" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Chris Miller" },
      { label: "Жанры", value: "Мультфильм, Фэнтези, Комедия" },
    ],
    cast: [
      { name: "Mike Myers", role: "" },
      { name: "Eddie Murphy", role: "" },
      { name: "Cameron Diaz", role: "" }
    ],
  },
  {
    id: 179,
    tmdbId: 10192,
    imdbId: "tt0892791",
    slug: "shrek-forever-after",
    title: "Шрэк навсегда",
    originalTitle: "Shrek Forever After",
    searchTitles: ["шрэк навсегда", "shrek forever after"],
    type: "Мультфильм",
    year: "2010",
    rating: 6.3,
    genres: ["Мультфильм", "Фэнтези", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 10192, imdbId: "tt0892791", title: "Шрэк навсегда", originalTitle: "Shrek Forever After", year: "2010", type: "Мультфильм" }),
    description: "Шрэк заключает сделку с Румпельштильцхеном и попадает в мир, где его никто не знает.",
    trailerUrl: "",
    longDescription: "«Шрэк навсегда» — мультфильм 2010 года. Шрэк заключает сделку с Румпельштильцхеном и попадает в мир, где его никто не знает. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Mike Mitchell" },
      { label: "Жанры", value: "Мультфильм, Фэнтези, Комедия" },
    ],
    cast: [
      { name: "Mike Myers", role: "" },
      { name: "Eddie Murphy", role: "" },
      { name: "Cameron Diaz", role: "" }
    ],
  },
  {
    id: 180,
    tmdbId: 315162,
    imdbId: "tt3915174",
    slug: "puss-in-boots-the-last-wish",
    title: "Кот в сапогах 2: Последнее желание",
    originalTitle: "Puss in Boots: The Last Wish",
    searchTitles: ["кот в сапогах 2: последнее желание", "puss in boots: the last wish", "puss in boots the last wish"],
    type: "Мультфильм",
    year: "2022",
    rating: 7.8,
    genres: ["Мультфильм", "Фэнтези", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 315162, imdbId: "tt3915174", title: "Кот в сапогах 2: Последнее желание", originalTitle: "Puss in Boots: The Last Wish", year: "2022", type: "Мультфильм" }),
    description: "Кот в сапогах узнаёт, что у него осталась последняя жизнь, и отправляется на поиски волшебного желания.",
    trailerUrl: "",
    longDescription: "«Кот в сапогах 2: Последнее желание» — мультфильм 2022 года. Кот в сапогах узнаёт, что у него осталась последняя жизнь, и отправляется на поиски волшебного желания. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Joel Crawford" },
      { label: "Жанры", value: "Мультфильм, Фэнтези, Приключения" },
    ],
    cast: [
      { name: "Antonio Banderas", role: "" },
      { name: "Salma Hayek", role: "" },
      { name: "Harvey Guillén", role: "" }
    ],
  },
  {
    id: 181,
    tmdbId: 165,
    imdbId: "tt0096874",
    slug: "back-to-the-future-part-ii",
    title: "Назад в будущее 2",
    originalTitle: "Back to the Future Part II",
    searchTitles: ["назад в будущее 2", "back to the future part ii"],
    type: "Фильм",
    year: "1989",
    rating: 7.8,
    genres: ["Фантастика", "Комедия", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 165, imdbId: "tt0096874", title: "Назад в будущее 2", originalTitle: "Back to the Future Part II", year: "1989", type: "Фильм" }),
    description: "Марти и Док отправляются в будущее, но одно вмешательство меняет прошлое и настоящее.",
    trailerUrl: "",
    longDescription: "«Назад в будущее 2» — фильм 1989 года. Марти и Док отправляются в будущее, но одно вмешательство меняет прошлое и настоящее. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "1989" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Robert Zemeckis" },
      { label: "Жанры", value: "Фантастика, Комедия, Приключения" },
    ],
    cast: [
      { name: "Michael J. Fox", role: "" },
      { name: "Christopher Lloyd", role: "" },
      { name: "Lea Thompson", role: "" }
    ],
  },
  {
    id: 182,
    tmdbId: 196,
    imdbId: "tt0099088",
    slug: "back-to-the-future-part-iii",
    title: "Назад в будущее 3",
    originalTitle: "Back to the Future Part III",
    searchTitles: ["назад в будущее 3", "back to the future part iii"],
    type: "Фильм",
    year: "1990",
    rating: 7.4,
    genres: ["Фантастика", "Комедия", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 196, imdbId: "tt0099088", title: "Назад в будущее 3", originalTitle: "Back to the Future Part III", year: "1990", type: "Фильм" }),
    description: "Марти переносится на Дикий Запад, чтобы спасти Дока и вернуть машину времени домой.",
    trailerUrl: "",
    longDescription: "«Назад в будущее 3» — фильм 1990 года. Марти переносится на Дикий Запад, чтобы спасти Дока и вернуть машину времени домой. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "1990" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Robert Zemeckis" },
      { label: "Жанры", value: "Фантастика, Комедия, Приключения" },
    ],
    cast: [
      { name: "Michael J. Fox", role: "" },
      { name: "Christopher Lloyd", role: "" },
      { name: "Mary Steenburgen", role: "" }
    ],
  },
  {
    id: 183,
    tmdbId: 218,
    imdbId: "tt0088247",
    slug: "the-terminator",
    title: "Терминатор",
    originalTitle: "The Terminator",
    searchTitles: ["терминатор", "the terminator"],
    type: "Фильм",
    year: "1984",
    rating: 8.1,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ tmdbId: 218, imdbId: "tt0088247", title: "Терминатор", originalTitle: "The Terminator", year: "1984", type: "Фильм" }),
    description: "Киборг из будущего прибывает в прошлое, чтобы устранить Сару Коннор.",
    trailerUrl: "",
    longDescription: "«Терминатор» — фильм 1984 года. Киборг из будущего прибывает в прошлое, чтобы устранить Сару Коннор. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "1984" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Режиссёр/создатель", value: "James Cameron" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Arnold Schwarzenegger", role: "" },
      { name: "Linda Hamilton", role: "" },
      { name: "Michael Biehn", role: "" }
    ],
  },
  {
    id: 184,
    tmdbId: 296,
    imdbId: "tt0181852",
    slug: "terminator-3-rise-of-the-machines",
    title: "Терминатор 3: Восстание машин",
    originalTitle: "Terminator 3: Rise of the Machines",
    searchTitles: ["терминатор 3: восстание машин", "terminator 3: rise of the machines", "terminator 3 rise of the machines"],
    type: "Фильм",
    year: "2003",
    rating: 6.3,
    genres: ["Фантастика", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 296, imdbId: "tt0181852", title: "Терминатор 3: Восстание машин", originalTitle: "Terminator 3: Rise of the Machines", year: "2003", type: "Фильм" }),
    description: "Джон Коннор снова оказывается целью машины из будущего, а Судный день становится всё ближе.",
    trailerUrl: "",
    longDescription: "«Терминатор 3: Восстание машин» — фильм 2003 года. Джон Коннор снова оказывается целью машины из будущего, а Судный день становится всё ближе. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Jonathan Mostow" },
      { label: "Жанры", value: "Фантастика, Боевик" },
    ],
    cast: [
      { name: "Arnold Schwarzenegger", role: "" },
      { name: "Nick Stahl", role: "" },
      { name: "Claire Danes", role: "" }
    ],
  },
  {
    id: 185,
    tmdbId: 534,
    imdbId: "tt0438488",
    slug: "terminator-salvation",
    title: "Терминатор: Да придёт спаситель",
    originalTitle: "Terminator Salvation",
    searchTitles: ["терминатор: да придёт спаситель", "terminator salvation"],
    type: "Фильм",
    year: "2009",
    rating: 6.5,
    genres: ["Фантастика", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 534, imdbId: "tt0438488", title: "Терминатор: Да придёт спаситель", originalTitle: "Terminator Salvation", year: "2009", type: "Фильм" }),
    description: "В будущем Джон Коннор ведёт сопротивление против машин Skynet.",
    trailerUrl: "",
    longDescription: "«Терминатор: Да придёт спаситель» — фильм 2009 года. В будущем Джон Коннор ведёт сопротивление против машин Skynet. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2009" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "McG" },
      { label: "Жанры", value: "Фантастика, Боевик" },
    ],
    cast: [
      { name: "Christian Bale", role: "" },
      { name: "Sam Worthington", role: "" },
      { name: "Anton Yelchin", role: "" }
    ],
  },
  {
    id: 186,
    tmdbId: 87101,
    imdbId: "tt1340138",
    slug: "terminator-genisys",
    title: "Терминатор: Генезис",
    originalTitle: "Terminator Genisys",
    searchTitles: ["терминатор: генезис", "terminator genisys"],
    type: "Фильм",
    year: "2015",
    rating: 6.0,
    genres: ["Фантастика", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 87101, imdbId: "tt1340138", title: "Терминатор: Генезис", originalTitle: "Terminator Genisys", year: "2015", type: "Фильм" }),
    description: "Изменённая временная линия ставит Сару Коннор и Кайла Риза перед новой версией войны с машинами.",
    trailerUrl: "",
    longDescription: "«Терминатор: Генезис» — фильм 2015 года. Изменённая временная линия ставит Сару Коннор и Кайла Риза перед новой версией войны с машинами. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Alan Taylor" },
      { label: "Жанры", value: "Фантастика, Боевик" },
    ],
    cast: [
      { name: "Arnold Schwarzenegger", role: "" },
      { name: "Emilia Clarke", role: "" },
      { name: "Jai Courtney", role: "" }
    ],
  },
  {
    id: 187,
    tmdbId: 290859,
    imdbId: "tt6450804",
    slug: "terminator-dark-fate",
    title: "Терминатор: Тёмные судьбы",
    originalTitle: "Terminator: Dark Fate",
    searchTitles: ["терминатор: тёмные судьбы", "terminator: dark fate", "terminator dark fate"],
    type: "Фильм",
    year: "2019",
    rating: 6.2,
    genres: ["Фантастика", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 290859, imdbId: "tt6450804", title: "Терминатор: Тёмные судьбы", originalTitle: "Terminator: Dark Fate", year: "2019", type: "Фильм" }),
    description: "Сара Коннор возвращается, чтобы защитить новую цель от усовершенствованного терминатора.",
    trailerUrl: "",
    longDescription: "«Терминатор: Тёмные судьбы» — фильм 2019 года. Сара Коннор возвращается, чтобы защитить новую цель от усовершенствованного терминатора. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Tim Miller" },
      { label: "Жанры", value: "Фантастика, Боевик" },
    ],
    cast: [
      { name: "Linda Hamilton", role: "" },
      { name: "Arnold Schwarzenegger", role: "" },
      { name: "Mackenzie Davis", role: "" }
    ],
  },
  {
    id: 188,
    tmdbId: 954,
    imdbId: "tt0117060",
    slug: "mission-impossible",
    title: "Миссия невыполнима",
    originalTitle: "Mission: Impossible",
    searchTitles: ["миссия невыполнима", "mission: impossible", "mission impossible"],
    type: "Фильм",
    year: "1996",
    rating: 7.1,
    genres: ["Боевик", "Триллер", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 954, imdbId: "tt0117060", title: "Миссия невыполнима", originalTitle: "Mission: Impossible", year: "1996", type: "Фильм" }),
    description: "Агент Итан Хант пытается доказать невиновность после провала операции и гибели команды.",
    trailerUrl: "",
    longDescription: "«Миссия невыполнима» — фильм 1996 года. Агент Итан Хант пытается доказать невиновность после провала операции и гибели команды. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "1996" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Brian De Palma" },
      { label: "Жанры", value: "Боевик, Триллер, Приключения" },
    ],
    cast: [
      { name: "Tom Cruise", role: "" },
      { name: "Jon Voight", role: "" },
      { name: "Emmanuelle Béart", role: "" }
    ],
  },
  {
    id: 189,
    tmdbId: 955,
    imdbId: "tt0120755",
    slug: "mission-impossible-ii",
    title: "Миссия невыполнима 2",
    originalTitle: "Mission: Impossible II",
    searchTitles: ["миссия невыполнима 2", "mission: impossible ii", "mission impossible ii"],
    type: "Фильм",
    year: "2000",
    rating: 6.1,
    genres: ["Боевик", "Триллер", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 955, imdbId: "tt0120755", title: "Миссия невыполнима 2", originalTitle: "Mission: Impossible II", year: "2000", type: "Фильм" }),
    description: "Итан Хант должен остановить биологическую угрозу и бывшего агента IMF.",
    trailerUrl: "",
    longDescription: "«Миссия невыполнима 2» — фильм 2000 года. Итан Хант должен остановить биологическую угрозу и бывшего агента IMF. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2000" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "John Woo" },
      { label: "Жанры", value: "Боевик, Триллер, Приключения" },
    ],
    cast: [
      { name: "Tom Cruise", role: "" },
      { name: "Dougray Scott", role: "" },
      { name: "Thandiwe Newton", role: "" }
    ],
  },
  {
    id: 190,
    tmdbId: 956,
    imdbId: "tt0317919",
    slug: "mission-impossible-iii",
    title: "Миссия невыполнима 3",
    originalTitle: "Mission: Impossible III",
    searchTitles: ["миссия невыполнима 3", "mission: impossible iii", "mission impossible iii"],
    type: "Фильм",
    year: "2006",
    rating: 6.9,
    genres: ["Боевик", "Триллер", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 956, imdbId: "tt0317919", title: "Миссия невыполнима 3", originalTitle: "Mission: Impossible III", year: "2006", type: "Фильм" }),
    description: "Итан Хант возвращается к полевой работе, когда опасный торговец оружием угрожает его личной жизни.",
    trailerUrl: "",
    longDescription: "«Миссия невыполнима 3» — фильм 2006 года. Итан Хант возвращается к полевой работе, когда опасный торговец оружием угрожает его личной жизни. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2006" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "J.J. Abrams" },
      { label: "Жанры", value: "Боевик, Триллер, Приключения" },
    ],
    cast: [
      { name: "Tom Cruise", role: "" },
      { name: "Philip Seymour Hoffman", role: "" },
      { name: "Ving Rhames", role: "" }
    ],
  },
  {
    id: 191,
    tmdbId: 56292,
    imdbId: "tt1229238",
    slug: "mission-impossible-ghost-protocol",
    title: "Миссия невыполнима: Протокол Фантом",
    originalTitle: "Mission: Impossible - Ghost Protocol",
    searchTitles: ["миссия невыполнима: протокол фантом", "mission: impossible - ghost protocol", "mission impossible - ghost protocol"],
    type: "Фильм",
    year: "2011",
    rating: 7.4,
    genres: ["Боевик", "Триллер", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 56292, imdbId: "tt1229238", title: "Миссия невыполнима: Протокол Фантом", originalTitle: "Mission: Impossible - Ghost Protocol", year: "2011", type: "Фильм" }),
    description: "Команда Ханта действует без официальной поддержки после обвинения в атаке на Кремль.",
    trailerUrl: "",
    longDescription: "«Миссия невыполнима: Протокол Фантом» — фильм 2011 года. Команда Ханта действует без официальной поддержки после обвинения в атаке на Кремль. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Brad Bird" },
      { label: "Жанры", value: "Боевик, Триллер, Приключения" },
    ],
    cast: [
      { name: "Tom Cruise", role: "" },
      { name: "Jeremy Renner", role: "" },
      { name: "Simon Pegg", role: "" }
    ],
  },
  {
    id: 192,
    tmdbId: 177677,
    imdbId: "tt2381249",
    slug: "mission-impossible-rogue-nation",
    title: "Миссия невыполнима: Племя изгоев",
    originalTitle: "Mission: Impossible - Rogue Nation",
    searchTitles: ["миссия невыполнима: племя изгоев", "mission: impossible - rogue nation", "mission impossible - rogue nation"],
    type: "Фильм",
    year: "2015",
    rating: 7.4,
    genres: ["Боевик", "Триллер", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 177677, imdbId: "tt2381249", title: "Миссия невыполнима: Племя изгоев", originalTitle: "Mission: Impossible - Rogue Nation", year: "2015", type: "Фильм" }),
    description: "Итан Хант противостоит Синдикату — тайной сети агентов, действующей против IMF.",
    trailerUrl: "",
    longDescription: "«Миссия невыполнима: Племя изгоев» — фильм 2015 года. Итан Хант противостоит Синдикату — тайной сети агентов, действующей против IMF. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Christopher McQuarrie" },
      { label: "Жанры", value: "Боевик, Триллер, Приключения" },
    ],
    cast: [
      { name: "Tom Cruise", role: "" },
      { name: "Rebecca Ferguson", role: "" },
      { name: "Simon Pegg", role: "" }
    ],
  },
  {
    id: 193,
    tmdbId: 575264,
    imdbId: "tt9603212",
    slug: "mission-impossible-dead-reckoning-part-one",
    title: "Миссия невыполнима: Смертельная расплата. Часть первая",
    originalTitle: "Mission: Impossible - Dead Reckoning Part One",
    searchTitles: ["миссия невыполнима: смертельная расплата. часть первая", "mission: impossible - dead reckoning part one", "mission impossible - dead reckoning part one"],
    type: "Фильм",
    year: "2023",
    rating: 7.7,
    genres: ["Боевик", "Триллер", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 575264, imdbId: "tt9603212", title: "Миссия невыполнима: Смертельная расплата. Часть первая", originalTitle: "Mission: Impossible - Dead Reckoning Part One", year: "2023", type: "Фильм" }),
    description: "Итан Хант ищет ключ к опасной технологии, способной изменить баланс сил в мире.",
    trailerUrl: "",
    longDescription: "«Миссия невыполнима: Смертельная расплата. Часть первая» — фильм 2023 года. Итан Хант ищет ключ к опасной технологии, способной изменить баланс сил в мире. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Christopher McQuarrie" },
      { label: "Жанры", value: "Боевик, Триллер, Приключения" },
    ],
    cast: [
      { name: "Tom Cruise", role: "" },
      { name: "Hayley Atwell", role: "" },
      { name: "Rebecca Ferguson", role: "" }
    ],
  },
  {
    id: 194,
    tmdbId: 575265,
    imdbId: "tt9603208",
    slug: "mission-impossible-the-final-reckoning",
    title: "Миссия невыполнима: Финальная расплата",
    originalTitle: "Mission: Impossible - The Final Reckoning",
    searchTitles: ["миссия невыполнима: финальная расплата", "mission: impossible - the final reckoning", "mission impossible - the final reckoning"],
    type: "Фильм",
    year: "2025",
    rating: 7.2,
    genres: ["Боевик", "Триллер", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 575265, imdbId: "tt9603208", title: "Миссия невыполнима: Финальная расплата", originalTitle: "Mission: Impossible - The Final Reckoning", year: "2025", type: "Фильм" }),
    description: "Итан Хант продолжает борьбу с угрозой, связанной с Entity, и последствиями прошлых миссий.",
    trailerUrl: "",
    longDescription: "«Миссия невыполнима: Финальная расплата» — фильм 2025 года. Итан Хант продолжает борьбу с угрозой, связанной с Entity, и последствиями прошлых миссий. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2025" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Christopher McQuarrie" },
      { label: "Жанры", value: "Боевик, Триллер, Приключения" },
    ],
    cast: [
      { name: "Tom Cruise", role: "" },
      { name: "Hayley Atwell", role: "" },
      { name: "Ving Rhames", role: "" }
    ],
  },
  {
    id: 195,
    tmdbId: 343668,
    imdbId: "tt4649466",
    slug: "kingsman-the-golden-circle",
    title: "Kingsman: Золотое кольцо",
    originalTitle: "Kingsman: The Golden Circle",
    searchTitles: ["kingsman: золотое кольцо", "kingsman: the golden circle", "kingsman the golden circle", "кингсман 2", "золотое кольцо"],
    type: "Фильм",
    year: "2017",
    rating: 6.7,
    genres: ["Боевик", "Комедия", "Приключения", "Шпионаж"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 343668, imdbId: "tt4649466", title: "Kingsman: Золотое кольцо", originalTitle: "Kingsman: The Golden Circle", year: "2017", type: "Фильм" }),
    description: "После удара по Kingsman Эггси и Мерлин выходят на американскую организацию Statesman и новую угрозу мирового масштаба.",
    trailerUrl: "",
    longDescription: "«Kingsman: Золотое кольцо» расширяет франшизу: вместо одной британской службы появляется американская зеркальная команда Statesman, а история становится громче, ярче и безумнее. Сиквел сохраняет фирменную смесь костюмов, гаджетов и сарказма, но добавляет больше международного масштаба и новых союзников. На странице KinoLuma эта часть теперь выглядит не как короткая заглушка, а как нормальная карточка франшизы с понятным описанием, фактами, настроением и актёрами.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Длительность", value: "141 мин" },
      { label: "Студия", value: "Marv Films, Cloudy Productions, TSG Entertainment" },
      { label: "Франшиза", value: "Kingsman" },
      { label: "Режиссёр", value: "Мэттью Вон" },
      { label: "Настроение", value: "Громко, глянцево, авантюрно" },
      { label: "Темы", value: "союзники, организация, месть, доверие" },
    ],
    cast: [
      { name: "Тэрон Эджертон", role: "Эггси" },
      { name: "Колин Фёрт", role: "Гарри Харт" },
      { name: "Марк Стронг", role: "Мерлин" },
      { name: "Джулианна Мур", role: "Поппи" },
      { name: "Педро Паскаль", role: "Виски" },
      { name: "Холли Берри", role: "Джинджер Эйл" },
    ],
  },
  {
    id: 196,
    tmdbId: 476669,
    imdbId: "tt6856242",
    slug: "the-kings-man",
    title: "King’s Man: Начало",
    originalTitle: "The King's Man",
    searchTitles: ["king’s man: начало", "the king's man", "кингсман начало", "kingsman prequel"],
    type: "Фильм",
    year: "2021",
    rating: 6.3,
    genres: ["Боевик", "Приключения", "Триллер", "Шпионаж"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ tmdbId: 476669, imdbId: "tt6856242", title: "King’s Man: Начало", originalTitle: "The King's Man", year: "2021", type: "Фильм" }),
    description: "Приквел Kingsman показывает рождение тайной службы на фоне большого исторического конфликта и закулисных заговоров.",
    trailerUrl: "",
    longDescription: "«King’s Man: Начало» работает как исторический приквел франшизы: меньше подростковой дерзости Эггси, больше старой школы, политических интриг и идеи, что секретная организация появляется не ради красивых костюмов, а как ответ на хаос эпохи. Фильм объясняет, откуда выросли правила Kingsman, почему для этой службы так важны честь и дисциплина, и чем её стиль отличается от обычного шпионского боевика.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Великобритания, США" },
      { label: "Длительность", value: "131 мин" },
      { label: "Студия", value: "Marv Studios, Cloudy Productions, 20th Century Studios" },
      { label: "Франшиза", value: "Kingsman" },
      { label: "Режиссёр", value: "Мэттью Вон" },
      { label: "Настроение", value: "Исторично, заговорщицки, приключенчески" },
      { label: "Темы", value: "происхождение службы, долг, заговор, наследие" },
    ],
    cast: [
      { name: "Рэйф Файнс", role: "Орландо Оксфорд" },
      { name: "Джемма Артертон", role: "Полли" },
      { name: "Рис Иванс", role: "Распутин" },
      { name: "Харрис Дикинсон", role: "Конрад" },
      { name: "Джимон Хонсу", role: "Шола" },
    ],
  },
  {
    id: 197,
    tmdbId: 447332,
    imdbId: "tt6644200",
    slug: "a-quiet-place",
    title: "Тихое место",
    originalTitle: "A Quiet Place",
    searchTitles: ["тихое место", "a quiet place"],
    type: "Фильм",
    year: "2018",
    rating: 7.5,
    genres: ["Ужасы", "Фантастика", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 447332, imdbId: "tt6644200", title: "Тихое место", originalTitle: "A Quiet Place", year: "2018", type: "Фильм" }),
    description: "Семья выживает в мире, где любое громкое действие может привлечь смертельную угрозу.",
    trailerUrl: "",
    longDescription: "«Тихое место» — фильм 2018 года. Семья выживает в мире, где любое громкое действие может привлечь смертельную угрозу. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "John Krasinski" },
      { label: "Жанры", value: "Ужасы, Фантастика, Драма" },
    ],
    cast: [
      { name: "Emily Blunt", role: "" },
      { name: "John Krasinski", role: "" },
      { name: "Millicent Simmonds", role: "" }
    ],
  },
  {
    id: 198,
    tmdbId: 520763,
    imdbId: "tt8332922",
    slug: "a-quiet-place-part-ii",
    title: "Тихое место 2",
    originalTitle: "A Quiet Place Part II",
    searchTitles: ["тихое место 2", "a quiet place part ii"],
    type: "Фильм",
    year: "2020",
    rating: 7.2,
    genres: ["Ужасы", "Фантастика", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 520763, imdbId: "tt8332922", title: "Тихое место 2", originalTitle: "A Quiet Place Part II", year: "2020", type: "Фильм" }),
    description: "Семья Эбботт покидает дом и сталкивается с новыми опасностями внешнего мира.",
    trailerUrl: "",
    longDescription: "«Тихое место 2» — фильм 2020 года. Семья Эбботт покидает дом и сталкивается с новыми опасностями внешнего мира. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2020" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "John Krasinski" },
      { label: "Жанры", value: "Ужасы, Фантастика, Драма" },
    ],
    cast: [
      { name: "Emily Blunt", role: "" },
      { name: "Cillian Murphy", role: "" },
      { name: "Millicent Simmonds", role: "" }
    ],
  },
  {
    id: 199,
    tmdbId: 8077,
    imdbId: "tt0103644",
    slug: "alien-3",
    title: "Чужой 3",
    originalTitle: "Alien³",
    searchTitles: ["чужой 3", "alien³"],
    type: "Фильм",
    year: "1992",
    rating: 6.4,
    genres: ["Фантастика", "Ужасы", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 8077, imdbId: "tt0103644", title: "Чужой 3", originalTitle: "Alien³", year: "1992", type: "Фильм" }),
    description: "Рипли оказывается на тюремной планете, где появляется новая форма ксеноморфа.",
    trailerUrl: "",
    longDescription: "«Чужой 3» — фильм 1992 года. Рипли оказывается на тюремной планете, где появляется новая форма ксеноморфа. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "1992" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "David Fincher" },
      { label: "Жанры", value: "Фантастика, Ужасы, Триллер" },
    ],
    cast: [
      { name: "Sigourney Weaver", role: "" },
      { name: "Charles S. Dutton", role: "" },
      { name: "Charles Dance", role: "" }
    ],
  },
  {
    id: 200,
    tmdbId: 8078,
    imdbId: "tt0118583",
    slug: "alien-resurrection",
    title: "Чужой: Воскрешение",
    originalTitle: "Alien Resurrection",
    searchTitles: ["чужой: воскрешение", "alien resurrection"],
    type: "Фильм",
    year: "1997",
    rating: 6.2,
    genres: ["Фантастика", "Ужасы", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 8078, imdbId: "tt0118583", title: "Чужой: Воскрешение", originalTitle: "Alien Resurrection", year: "1997", type: "Фильм" }),
    description: "Через много лет учёные возвращают Рипли к жизни и снова сталкиваются с ксеноморфами.",
    trailerUrl: "",
    longDescription: "«Чужой: Воскрешение» — фильм 1997 года. Через много лет учёные возвращают Рипли к жизни и снова сталкиваются с ксеноморфами. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "1997" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Jean-Pierre Jeunet" },
      { label: "Жанры", value: "Фантастика, Ужасы, Боевик" },
    ],
    cast: [
      { name: "Sigourney Weaver", role: "" },
      { name: "Winona Ryder", role: "" },
      { name: "Ron Perlman", role: "" }
    ],
  },
  {
    id: 201,
    tmdbId: 70981,
    imdbId: "tt1446714",
    slug: "prometheus",
    title: "Прометей",
    originalTitle: "Prometheus",
    searchTitles: ["прометей", "prometheus"],
    type: "Фильм",
    year: "2012",
    rating: 7.0,
    genres: ["Фантастика", "Ужасы", "Приключения"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ tmdbId: 70981, imdbId: "tt1446714", title: "Прометей", originalTitle: "Prometheus", year: "2012", type: "Фильм" }),
    description: "Экспедиция отправляется к далёкой планете в поисках истоков человечества.",
    trailerUrl: "",
    longDescription: "«Прометей» — фильм 2012 года. Экспедиция отправляется к далёкой планете в поисках истоков человечества. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Режиссёр/создатель", value: "Ridley Scott" },
      { label: "Жанры", value: "Фантастика, Ужасы, Приключения" },
    ],
    cast: [
      { name: "Noomi Rapace", role: "" },
      { name: "Michael Fassbender", role: "" },
      { name: "Charlize Theron", role: "" }
    ],
  },
  {
    id: 202,
    tmdbId: 126889,
    imdbId: "tt2316204",
    slug: "alien-covenant",
    title: "Чужой: Завет",
    originalTitle: "Alien: Covenant",
    searchTitles: ["чужой: завет", "alien: covenant", "alien covenant"],
    type: "Фильм",
    year: "2017",
    rating: 6.4,
    genres: ["Фантастика", "Ужасы", "Триллер"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ tmdbId: 126889, imdbId: "tt2316204", title: "Чужой: Завет", originalTitle: "Alien: Covenant", year: "2017", type: "Фильм" }),
    description: "Колониальный корабль прибывает на планету, где экипаж сталкивается с наследием Прометея.",
    trailerUrl: "",
    longDescription: "«Чужой: Завет» — фильм 2017 года. Колониальный корабль прибывает на планету, где экипаж сталкивается с наследием Прометея. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Режиссёр/создатель", value: "Ridley Scott" },
      { label: "Жанры", value: "Фантастика, Ужасы, Триллер" },
    ],
    cast: [
      { name: "Michael Fassbender", role: "" },
      { name: "Katherine Waterston", role: "" },
      { name: "Billy Crudup", role: "" }
    ],
  },
  {
    id: 203,
    tmdbId: 169,
    imdbId: "tt0100403",
    slug: "predator-2",
    title: "Хищник 2",
    originalTitle: "Predator 2",
    searchTitles: ["хищник 2", "predator 2"],
    type: "Фильм",
    year: "1990",
    rating: 6.3,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 169, imdbId: "tt0100403", title: "Хищник 2", originalTitle: "Predator 2", year: "1990", type: "Фильм" }),
    description: "Новый Хищник появляется в Лос-Анджелесе и охотится среди городского хаоса.",
    trailerUrl: "",
    longDescription: "«Хищник 2» — фильм 1990 года. Новый Хищник появляется в Лос-Анджелесе и охотится среди городского хаоса. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "1990" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Stephen Hopkins" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Danny Glover", role: "" },
      { name: "Gary Busey", role: "" },
      { name: "Kevin Peter Hall", role: "" }
    ],
  },
  {
    id: 204,
    tmdbId: 34851,
    imdbId: "tt1424381",
    slug: "predators",
    title: "Хищники",
    originalTitle: "Predators",
    searchTitles: ["хищники", "predators"],
    type: "Фильм",
    year: "2010",
    rating: 6.4,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 34851, imdbId: "tt1424381", title: "Хищники", originalTitle: "Predators", year: "2010", type: "Фильм" }),
    description: "Группа опасных людей оказывается на чужой планете, превращённой в охотничий заповедник.",
    trailerUrl: "",
    longDescription: "«Хищники» — фильм 2010 года. Группа опасных людей оказывается на чужой планете, превращённой в охотничий заповедник. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Nimród Antal" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Adrien Brody", role: "" },
      { name: "Alice Braga", role: "" },
      { name: "Topher Grace", role: "" }
    ],
  },
  {
    id: 205,
    tmdbId: 346910,
    imdbId: "tt3829266",
    slug: "the-predator",
    title: "Хищник",
    originalTitle: "The Predator",
    searchTitles: ["хищник", "the predator"],
    type: "Фильм",
    year: "2018",
    rating: 5.3,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 346910, imdbId: "tt3829266", title: "Хищник", originalTitle: "The Predator", year: "2018", type: "Фильм" }),
    description: "Возвращение Хищников на Землю приводит к столкновению людей с более опасной версией охотника.",
    trailerUrl: "",
    longDescription: "«Хищник» — фильм 2018 года. Возвращение Хищников на Землю приводит к столкновению людей с более опасной версией охотника. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Shane Black" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Boyd Holbrook", role: "" },
      { name: "Trevante Rhodes", role: "" },
      { name: "Olivia Munn", role: "" }
    ],
  },
  {
    id: 206,
    tmdbId: 766507,
    imdbId: "tt11866324",
    slug: "prey-2022",
    title: "Добыча",
    originalTitle: "Prey",
    searchTitles: ["добыча", "prey"],
    type: "Фильм",
    year: "2022",
    rating: 7.1,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 766507, imdbId: "tt11866324", title: "Добыча", originalTitle: "Prey", year: "2022", type: "Фильм" }),
    description: "Молодая охотница народа команчей сталкивается с внеземным охотником задолго до событий оригинального фильма.",
    trailerUrl: "",
    longDescription: "«Добыча» — фильм 2022 года. Молодая охотница народа команчей сталкивается с внеземным охотником задолго до событий оригинального фильма. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Dan Trachtenberg" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Amber Midthunder", role: "" },
      { name: "Dakota Beavers", role: "" },
      { name: "Dane DiLiegro", role: "" }
    ],
  },
  {
    id: 207,
    tmdbId: 755898,
    imdbId: "tt31227572",
    slug: "predator-badlands",
    title: "Хищник: Планета смерти",
    originalTitle: "Predator: Badlands",
    searchTitles: ["хищник: планета смерти", "predator: badlands", "predator badlands"],
    type: "Фильм",
    year: "2025",
    rating: 0.0,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 755898, imdbId: "tt31227572", title: "Хищник: Планета смерти", originalTitle: "Predator: Badlands", year: "2025", type: "Фильм" }),
    description: "Новая история во вселенной «Хищника», действие которой переносит охоту на другую планету.",
    trailerUrl: "",
    longDescription: "«Хищник: Планета смерти» — фильм 2025 года. Новая история во вселенной «Хищника», действие которой переносит охоту на другую планету. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2025" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Dan Trachtenberg" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
    ],
    cast: [
      { name: "Elle Fanning", role: "" }
    ],
  },
  {
    id: 208,
    tmdbId: 45243,
    imdbId: "tt1411697",
    slug: "the-hangover-part-ii",
    title: "Мальчишник 2: Из Вегаса в Бангкок",
    originalTitle: "The Hangover Part II",
    searchTitles: ["мальчишник 2: из вегаса в бангкок", "the hangover part ii"],
    type: "Фильм",
    year: "2011",
    rating: 6.5,
    genres: ["Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 45243, imdbId: "tt1411697", title: "Мальчишник 2: Из Вегаса в Бангкок", originalTitle: "The Hangover Part II", year: "2011", type: "Фильм" }),
    description: "Друзья снова просыпаются после бурной ночи без ясного понимания, что произошло, теперь уже в Бангкоке.",
    trailerUrl: "",
    longDescription: "«Мальчишник 2: Из Вегаса в Бангкок» — фильм 2011 года. Друзья снова просыпаются после бурной ночи без ясного понимания, что произошло, теперь уже в Бангкоке. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Todd Phillips" },
      { label: "Жанры", value: "Комедия" },
    ],
    cast: [
      { name: "Bradley Cooper", role: "" },
      { name: "Ed Helms", role: "" },
      { name: "Zach Galifianakis", role: "" }
    ],
  },
  {
    id: 209,
    tmdbId: 109439,
    imdbId: "tt1951261",
    slug: "the-hangover-part-iii",
    title: "Мальчишник: Часть III",
    originalTitle: "The Hangover Part III",
    searchTitles: ["мальчишник: часть iii", "the hangover part iii"],
    type: "Фильм",
    year: "2013",
    rating: 5.8,
    genres: ["Комедия", "Криминал"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 109439, imdbId: "tt1951261", title: "Мальчишник: Часть III", originalTitle: "The Hangover Part III", year: "2013", type: "Фильм" }),
    description: "Финальная глава компании друзей превращается в криминальную погоню и возвращение к старым проблемам.",
    trailerUrl: "",
    longDescription: "«Мальчишник: Часть III» — фильм 2013 года. Финальная глава компании друзей превращается в криминальную погоню и возвращение к старым проблемам. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Todd Phillips" },
      { label: "Жанры", value: "Комедия, Криминал" },
    ],
    cast: [
      { name: "Bradley Cooper", role: "" },
      { name: "Ed Helms", role: "" },
      { name: "Zach Galifianakis", role: "" }
    ],
  },
  {
    id: 210,
    tmdbId: 83533,
    imdbId: "tt1757678",
    slug: "avatar-fire-and-ash",
    title: "Аватар: Огонь и пепел",
    originalTitle: "Avatar: Fire and Ash",
    searchTitles: ["аватар: огонь и пепел", "avatar: fire and ash", "avatar fire and ash"],
    type: "Фильм",
    year: "2025",
    rating: 0.0,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 83533, imdbId: "tt1757678", title: "Аватар: Огонь и пепел", originalTitle: "Avatar: Fire and Ash", year: "2025", type: "Фильм" }),
    description: "Новая глава истории Пандоры продолжает линию семьи Салли и знакомит с другими народами планеты.",
    trailerUrl: "",
    longDescription: "«Аватар: Огонь и пепел» — фильм 2025 года. Новая глава истории Пандоры продолжает линию семьи Салли и знакомит с другими народами планеты. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2025" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "James Cameron" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
    ],
    cast: [
      { name: "Sam Worthington", role: "" },
      { name: "Zoe Saldaña", role: "" },
      { name: "Sigourney Weaver", role: "" }
    ],
  },
  {
    id: 211,
    tmdbId: 661374,
    imdbId: "tt11564570",
    slug: "glass-onion-a-knives-out-mystery",
    title: "Достать ножи: Стеклянная луковица",
    originalTitle: "Glass Onion: A Knives Out Mystery",
    searchTitles: ["достать ножи: стеклянная луковица", "glass onion: a knives out mystery", "glass onion a knives out mystery"],
    type: "Фильм",
    year: "2022",
    rating: 7.1,
    genres: ["Детектив", "Комедия", "Криминал"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 661374, imdbId: "tt11564570", title: "Достать ножи: Стеклянная луковица", originalTitle: "Glass Onion: A Knives Out Mystery", year: "2022", type: "Фильм" }),
    description: "Бенуа Блан расследует загадку на частном острове технологического миллиардера.",
    trailerUrl: "",
    longDescription: "«Достать ножи: Стеклянная луковица» — фильм 2022 года. Бенуа Блан расследует загадку на частном острове технологического миллиардера. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Rian Johnson" },
      { label: "Жанры", value: "Детектив, Комедия, Криминал" },
    ],
    cast: [
      { name: "Daniel Craig", role: "" },
      { name: "Edward Norton", role: "" },
      { name: "Janelle Monáe", role: "" }
    ],
  },
  {
    id: 212,
    tmdbId: 71912,
    imdbId: "tt5180504",
    slug: "the-witcher",
    title: "Ведьмак",
    originalTitle: "The Witcher",
    searchTitles: ["ведьмак", "the witcher"],
    type: "Сериал",
    year: "2019",
    rating: 8.0,
    genres: ["Фэнтези", "Приключения", "Драма"],
    countries: ["США", "Польша"],
    poster: getTmdbPoster({ tmdbId: 71912, imdbId: "tt5180504", title: "Ведьмак", originalTitle: "The Witcher", year: "2019", type: "Сериал" }),
    description: "Геральт из Ривии охотится на чудовищ и постепенно оказывается связан с судьбой Цири.",
    trailerUrl: "",
    longDescription: "«Ведьмак» — сериал 2019 года. Геральт из Ривии охотится на чудовищ и постепенно оказывается связан с судьбой Цири. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США, Польша" },
      { label: "Режиссёр/создатель", value: "Lauren Schmidt Hissrich" },
      { label: "Жанры", value: "Фэнтези, Приключения, Драма" },
    ],
    cast: [
      { name: "Henry Cavill", role: "" },
      { name: "Anya Chalotra", role: "" },
      { name: "Freya Allan", role: "" }
    ],
  },
  {
    id: 213,
    tmdbId: 106379,
    imdbId: "tt12637874",
    slug: "fallout",
    title: "Фоллаут",
    originalTitle: "Fallout",
    searchTitles: ["фоллаут", "fallout"],
    type: "Сериал",
    year: "2024",
    rating: 8.3,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 106379, imdbId: "tt12637874", title: "Фоллаут", originalTitle: "Fallout", year: "2024", type: "Сериал" }),
    description: "После ядерной катастрофы обитательница убежища выходит на поверхность и сталкивается с жестоким новым миром.",
    trailerUrl: "",
    longDescription: "«Фоллаут» — сериал 2024 года. После ядерной катастрофы обитательница убежища выходит на поверхность и сталкивается с жестоким новым миром. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Graham Wagner, Geneva Robertson-Dworet" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
    ],
    cast: [
      { name: "Ella Purnell", role: "" },
      { name: "Walton Goggins", role: "" },
      { name: "Aaron Moten", role: "" }
    ],
  },
  {
    id: 214,
    tmdbId: 84958,
    imdbId: "tt9140554",
    slug: "loki",
    title: "Локи",
    originalTitle: "Loki",
    searchTitles: ["локи", "loki"],
    type: "Сериал",
    year: "2021",
    rating: 8.2,
    genres: ["Фантастика", "Фэнтези", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 84958, imdbId: "tt9140554", title: "Локи", originalTitle: "Loki", year: "2021", type: "Сериал" }),
    description: "Локи попадает в организацию, следящую за временными линиями, и сталкивается с последствиями собственных вариантов.",
    trailerUrl: "",
    longDescription: "«Локи» — сериал 2021 года. Локи попадает в организацию, следящую за временными линиями, и сталкивается с последствиями собственных вариантов. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Michael Waldron" },
      { label: "Жанры", value: "Фантастика, Фэнтези, Приключения" },
    ],
    cast: [
      { name: "Tom Hiddleston", role: "" },
      { name: "Owen Wilson", role: "" },
      { name: "Sophia Di Martino", role: "" }
    ],
  },
  {
    id: 215,
    tmdbId: 83867,
    imdbId: "tt9253284",
    slug: "andor",
    title: "Андор",
    originalTitle: "Andor",
    searchTitles: ["андор", "andor"],
    type: "Сериал",
    year: "2022",
    rating: 8.4,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 83867, imdbId: "tt9253284", title: "Андор", originalTitle: "Andor", year: "2022", type: "Сериал" }),
    description: "Кассиан Андор проходит путь от выживания к участию в зарождающемся сопротивлении Империи.",
    trailerUrl: "",
    longDescription: "«Андор» — сериал 2022 года. Кассиан Андор проходит путь от выживания к участию в зарождающемся сопротивлении Империи. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Tony Gilroy" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
    ],
    cast: [
      { name: "Diego Luna", role: "" },
      { name: "Stellan Skarsgård", role: "" },
      { name: "Genevieve O’Reilly", role: "" }
    ],
  },
  {
    id: 216,
    tmdbId: 136315,
    imdbId: "tt14452776",
    slug: "the-bear",
    title: "Медведь",
    originalTitle: "The Bear",
    searchTitles: ["медведь", "the bear"],
    type: "Сериал",
    year: "2022",
    rating: 8.6,
    genres: ["Драма", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 136315, imdbId: "tt14452776", title: "Медведь", originalTitle: "The Bear", year: "2022", type: "Сериал" }),
    description: "Молодой шеф возвращается в семейную закусочную Чикаго и пытается перестроить кухню и команду.",
    trailerUrl: "",
    longDescription: "«Медведь» — сериал 2022 года. Молодой шеф возвращается в семейную закусочную Чикаго и пытается перестроить кухню и команду. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "Christopher Storer" },
      { label: "Жанры", value: "Драма, Комедия" },
    ],
    cast: [
      { name: "Jeremy Allen White", role: "" },
      { name: "Ayo Edebiri", role: "" },
      { name: "Ebon Moss-Bachrach", role: "" }
    ],
  },
  {
    id: 217,
    tmdbId: 110492,
    imdbId: "tt13146488",
    slug: "peacemaker",
    title: "Миротворец",
    originalTitle: "Peacemaker",
    searchTitles: ["миротворец", "peacemaker"],
    type: "Сериал",
    year: "2022",
    rating: 8.3,
    genres: ["Боевик", "Комедия", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 110492, imdbId: "tt13146488", title: "Миротворец", originalTitle: "Peacemaker", year: "2022", type: "Сериал" }),
    description: "Миротворец продолжает опасные миссии и пытается доказать, что его методы действительно служат миру.",
    trailerUrl: "",
    longDescription: "«Миротворец» — сериал 2022 года. Миротворец продолжает опасные миссии и пытается доказать, что его методы действительно служат миру. Карточка добавлена в KinoLuma как часть расширения франшиз: постер и варианты просмотра подключаются через внутренний каталог без лишних технических деталей для зрителя.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Режиссёр/создатель", value: "James Gunn" },
      { label: "Жанры", value: "Боевик, Комедия, Фантастика" },
    ],
    cast: [
      { name: "John Cena", role: "" },
      { name: "Danielle Brooks", role: "" },
      { name: "Jennifer Holland", role: "" }
    ],
  },
  {
    id: 218,
    tmdbId: 1724,
    imdbId: "tt0800080",
    slug: "the-incredible-hulk",
    title: "Невероятный Халк",
    originalTitle: "The Incredible Hulk",
    searchTitles: ["Невероятный Халк", "The Incredible Hulk", "Marvel Cinematic Universe", "невероятный халк", "the incredible hulk"],
    type: "Фильм",
    year: "2008",
    rating: 6.6,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1724, imdbId: "tt0800080", title: "Невероятный Халк", originalTitle: "The Incredible Hulk", year: "2008", type: "Фильм" }),
    description: "Брюс Бэннер пытается контролировать силу Халка и скрываться от тех, кто хочет использовать её.",
    trailerUrl: "",
    longDescription: "«Невероятный Халк» — фильм 2008 года из подборки «Marvel Cinematic Universe». Брюс Бэннер пытается контролировать силу Халка и скрываться от тех, кто хочет использовать её. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2008" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0800080" },
    ],
  },
  {
    id: 219,
    tmdbId: 10138,
    imdbId: "tt1228705",
    slug: "iron-man-2",
    title: "Железный человек 2",
    originalTitle: "Iron Man 2",
    searchTitles: ["Железный человек 2", "Iron Man 2", "Marvel Cinematic Universe", "железный человек 2", "iron man 2"],
    type: "Фильм",
    year: "2010",
    rating: 6.9,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 10138, imdbId: "tt1228705", title: "Железный человек 2", originalTitle: "Iron Man 2", year: "2010", type: "Фильм" }),
    description: "Тони Старк сталкивается с последствиями раскрытой личности Железного человека и новыми угрозами.",
    trailerUrl: "",
    longDescription: "«Железный человек 2» — фильм 2010 года из подборки «Marvel Cinematic Universe». Тони Старк сталкивается с последствиями раскрытой личности Железного человека и новыми угрозами. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1228705" },
    ],
  },
  {
    id: 220,
    tmdbId: 10195,
    imdbId: "tt0800369",
    slug: "thor",
    title: "Тор",
    originalTitle: "Thor",
    searchTitles: ["Тор", "Thor", "Marvel Cinematic Universe", "тор", "thor"],
    type: "Фильм",
    year: "2011",
    rating: 7.0,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 10195, imdbId: "tt0800369", title: "Тор", originalTitle: "Thor", year: "2011", type: "Фильм" }),
    description: "Наследник Асгарда оказывается на Земле и учится ответственности без короны и молота как простого бонуса.",
    trailerUrl: "",
    longDescription: "«Тор» — фильм 2011 года из подборки «Marvel Cinematic Universe». Наследник Асгарда оказывается на Земле и учится ответственности без короны и молота как простого бонуса. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0800369" },
    ],
  },
  {
    id: 221,
    tmdbId: 1771,
    imdbId: "tt0458339",
    slug: "captain-america-the-first-avenger",
    title: "Первый мститель",
    originalTitle: "Captain America: The First Avenger",
    searchTitles: ["Первый мститель", "Captain America: The First Avenger", "Marvel Cinematic Universe", "первый мститель", "captain america: the first avenger"],
    type: "Фильм",
    year: "2011",
    rating: 6.9,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1771, imdbId: "tt0458339", title: "Первый мститель", originalTitle: "Captain America: The First Avenger", year: "2011", type: "Фильм" }),
    description: "Стив Роджерс становится Капитаном Америкой и вступает в борьбу с угрозой времён Второй мировой войны.",
    trailerUrl: "",
    longDescription: "«Первый мститель» — фильм 2011 года из подборки «Marvel Cinematic Universe». Стив Роджерс становится Капитаном Америкой и вступает в борьбу с угрозой времён Второй мировой войны. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0458339" },
    ],
  },
  {
    id: 222,
    tmdbId: 68721,
    imdbId: "tt1300854",
    slug: "iron-man-3",
    title: "Железный человек 3",
    originalTitle: "Iron Man 3",
    searchTitles: ["Железный человек 3", "Iron Man 3", "Marvel Cinematic Universe", "железный человек 3", "iron man 3"],
    type: "Фильм",
    year: "2013",
    rating: 7.1,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 68721, imdbId: "tt1300854", title: "Железный человек 3", originalTitle: "Iron Man 3", year: "2013", type: "Фильм" }),
    description: "Тони Старк проверяет, кем он остаётся без привычной брони и полного контроля над ситуацией.",
    trailerUrl: "",
    longDescription: "«Железный человек 3» — фильм 2013 года из подборки «Marvel Cinematic Universe». Тони Старк проверяет, кем он остаётся без привычной брони и полного контроля над ситуацией. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1300854" },
    ],
  },
  {
    id: 223,
    tmdbId: 76338,
    imdbId: "tt1981115",
    slug: "thor-the-dark-world",
    title: "Тор 2: Царство тьмы",
    originalTitle: "Thor: The Dark World",
    searchTitles: ["Тор 2: Царство тьмы", "Thor: The Dark World", "Marvel Cinematic Universe", "тор 2: царство тьмы", "thor: the dark world"],
    type: "Фильм",
    year: "2013",
    rating: 6.8,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 76338, imdbId: "tt1981115", title: "Тор 2: Царство тьмы", originalTitle: "Thor: The Dark World", year: "2013", type: "Фильм" }),
    description: "Тор сталкивается с древней силой, угрожающей нескольким мирам сразу.",
    trailerUrl: "",
    longDescription: "«Тор 2: Царство тьмы» — фильм 2013 года из подборки «Marvel Cinematic Universe». Тор сталкивается с древней силой, угрожающей нескольким мирам сразу. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1981115" },
    ],
  },
  {
    id: 224,
    tmdbId: 100402,
    imdbId: "tt1843866",
    slug: "captain-america-the-winter-soldier",
    title: "Первый мститель: Другая война",
    originalTitle: "Captain America: The Winter Soldier",
    searchTitles: ["Первый мститель: Другая война", "Captain America: The Winter Soldier", "Marvel Cinematic Universe", "первый мститель: другая война", "captain america: the winter soldier"],
    type: "Фильм",
    year: "2014",
    rating: 7.8,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 100402, imdbId: "tt1843866", title: "Первый мститель: Другая война", originalTitle: "Captain America: The Winter Soldier", year: "2014", type: "Фильм" }),
    description: "Стив Роджерс раскрывает заговор внутри системы, которой привык доверять.",
    trailerUrl: "",
    longDescription: "«Первый мститель: Другая война» — фильм 2014 года из подборки «Marvel Cinematic Universe». Стив Роджерс раскрывает заговор внутри системы, которой привык доверять. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1843866" },
    ],
  },
  {
    id: 225,
    tmdbId: 99861,
    imdbId: "tt2395427",
    slug: "avengers-age-of-ultron",
    title: "Мстители: Эра Альтрона",
    originalTitle: "Avengers: Age of Ultron",
    searchTitles: ["Мстители: Эра Альтрона", "Avengers: Age of Ultron", "Marvel Cinematic Universe", "мстители: эра альтрона", "avengers: age of ultron"],
    type: "Фильм",
    year: "2015",
    rating: 7.3,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 99861, imdbId: "tt2395427", title: "Мстители: Эра Альтрона", originalTitle: "Avengers: Age of Ultron", year: "2015", type: "Фильм" }),
    description: "Мстители сталкиваются с искусственным интеллектом, который считает человечество главной проблемой планеты.",
    trailerUrl: "",
    longDescription: "«Мстители: Эра Альтрона» — фильм 2015 года из подборки «Marvel Cinematic Universe». Мстители сталкиваются с искусственным интеллектом, который считает человечество главной проблемой планеты. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt2395427" },
    ],
  },
  {
    id: 226,
    tmdbId: 102899,
    imdbId: "tt0478970",
    slug: "ant-man",
    title: "Человек-муравей",
    originalTitle: "Ant-Man",
    searchTitles: ["Человек-муравей", "Ant-Man", "Marvel Cinematic Universe", "человек-муравей", "ant-man"],
    type: "Фильм",
    year: "2015",
    rating: 7.3,
    genres: ["Боевик", "Комедия", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 102899, imdbId: "tt0478970", title: "Человек-муравей", originalTitle: "Ant-Man", year: "2015", type: "Фильм" }),
    description: "Скотт Лэнг получает костюм, позволяющий уменьшаться, и попадает в историю с ограблением супергеройского уровня.",
    trailerUrl: "",
    longDescription: "«Человек-муравей» — фильм 2015 года из подборки «Marvel Cinematic Universe». Скотт Лэнг получает костюм, позволяющий уменьшаться, и попадает в историю с ограблением супергеройского уровня. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Комедия, Фантастика" },
      { label: "Внутренний номер", value: "tt0478970" },
    ],
  },
  {
    id: 227,
    tmdbId: 271110,
    imdbId: "tt3498820",
    slug: "captain-america-civil-war",
    title: "Первый мститель: Противостояние",
    originalTitle: "Captain America: Civil War",
    searchTitles: ["Первый мститель: Противостояние", "Captain America: Civil War", "Marvel Cinematic Universe", "первый мститель: противостояние", "captain america: civil war"],
    type: "Фильм",
    year: "2016",
    rating: 7.8,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 271110, imdbId: "tt3498820", title: "Первый мститель: Противостояние", originalTitle: "Captain America: Civil War", year: "2016", type: "Фильм" }),
    description: "Разногласия между героями превращают команду Мстителей в две стороны одного конфликта.",
    trailerUrl: "",
    longDescription: "«Первый мститель: Противостояние» — фильм 2016 года из подборки «Marvel Cinematic Universe». Разногласия между героями превращают команду Мстителей в две стороны одного конфликта. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt3498820" },
    ],
  },
  {
    id: 228,
    tmdbId: 283995,
    imdbId: "tt3896198",
    slug: "guardians-of-the-galaxy-vol-2",
    title: "Стражи Галактики. Часть 2",
    originalTitle: "Guardians of the Galaxy Vol. 2",
    searchTitles: ["Стражи Галактики. Часть 2", "Guardians of the Galaxy Vol. 2", "Marvel Cinematic Universe", "стражи галактики. часть 2", "guardians of the galaxy vol. 2"],
    type: "Фильм",
    year: "2017",
    rating: 7.6,
    genres: ["Фантастика", "Комедия", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 283995, imdbId: "tt3896198", title: "Стражи Галактики. Часть 2", originalTitle: "Guardians of the Galaxy Vol. 2", year: "2017", type: "Фильм" }),
    description: "Стражи разбираются с прошлым Питера Квилла и проверяют, выдержит ли их команда семейные тайны.",
    trailerUrl: "",
    longDescription: "«Стражи Галактики. Часть 2» — фильм 2017 года из подборки «Marvel Cinematic Universe». Стражи разбираются с прошлым Питера Квилла и проверяют, выдержит ли их команда семейные тайны. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Фантастика, Комедия, Приключения" },
      { label: "Внутренний номер", value: "tt3896198" },
    ],
  },
  {
    id: 229,
    tmdbId: 315635,
    imdbId: "tt2250912",
    slug: "spider-man-homecoming",
    title: "Человек-паук: Возвращение домой",
    originalTitle: "Spider-Man: Homecoming",
    searchTitles: ["Человек-паук: Возвращение домой", "Spider-Man: Homecoming", "Marvel Cinematic Universe", "человек-паук: возвращение домой", "spider-man: homecoming"],
    type: "Фильм",
    year: "2017",
    rating: 7.4,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 315635, imdbId: "tt2250912", title: "Человек-паук: Возвращение домой", originalTitle: "Spider-Man: Homecoming", year: "2017", type: "Фильм" }),
    description: "Питер Паркер пытается быть обычным школьником и настоящим героем одновременно.",
    trailerUrl: "",
    longDescription: "«Человек-паук: Возвращение домой» — фильм 2017 года из подборки «Marvel Cinematic Universe». Питер Паркер пытается быть обычным школьником и настоящим героем одновременно. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt2250912" },
    ],
  },
  {
    id: 230,
    tmdbId: 284053,
    imdbId: "tt3501632",
    slug: "thor-ragnarok",
    title: "Тор: Рагнарёк",
    originalTitle: "Thor: Ragnarok",
    searchTitles: ["Тор: Рагнарёк", "Thor: Ragnarok", "Marvel Cinematic Universe", "тор: рагнарёк", "thor: ragnarok"],
    type: "Фильм",
    year: "2017",
    rating: 7.9,
    genres: ["Боевик", "Комедия", "Фэнтези"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 284053, imdbId: "tt3501632", title: "Тор: Рагнарёк", originalTitle: "Thor: Ragnarok", year: "2017", type: "Фильм" }),
    description: "Тор теряет привычные опоры и пытается остановить катастрофу Асгарда с новой командой союзников.",
    trailerUrl: "",
    longDescription: "«Тор: Рагнарёк» — фильм 2017 года из подборки «Marvel Cinematic Universe». Тор теряет привычные опоры и пытается остановить катастрофу Асгарда с новой командой союзников. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Комедия, Фэнтези" },
      { label: "Внутренний номер", value: "tt3501632" },
    ],
  },
  {
    id: 231,
    tmdbId: 284054,
    imdbId: "tt1825683",
    slug: "black-panther",
    title: "Чёрная Пантера",
    originalTitle: "Black Panther",
    searchTitles: ["Чёрная Пантера", "Black Panther", "Marvel Cinematic Universe", "чёрная пантера", "black panther"],
    type: "Фильм",
    year: "2018",
    rating: 7.3,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 284054, imdbId: "tt1825683", title: "Чёрная Пантера", originalTitle: "Black Panther", year: "2018", type: "Фильм" }),
    description: "Т’Чалла возвращается в Ваканду и сталкивается с испытанием власти, наследия и ответственности.",
    trailerUrl: "",
    longDescription: "«Чёрная Пантера» — фильм 2018 года из подборки «Marvel Cinematic Universe». Т’Чалла возвращается в Ваканду и сталкивается с испытанием власти, наследия и ответственности. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1825683" },
    ],
  },
  {
    id: 232,
    tmdbId: 363088,
    imdbId: "tt5095030",
    slug: "ant-man-and-the-wasp",
    title: "Человек-муравей и Оса",
    originalTitle: "Ant-Man and the Wasp",
    searchTitles: ["Человек-муравей и Оса", "Ant-Man and the Wasp", "Marvel Cinematic Universe", "человек-муравей и оса", "ant-man and the wasp"],
    type: "Фильм",
    year: "2018",
    rating: 7.0,
    genres: ["Боевик", "Комедия", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 363088, imdbId: "tt5095030", title: "Человек-муравей и Оса", originalTitle: "Ant-Man and the Wasp", year: "2018", type: "Фильм" }),
    description: "Скотт Лэнг возвращается к квантовым технологиям и семейным тайнам Хэнков.",
    trailerUrl: "",
    longDescription: "«Человек-муравей и Оса» — фильм 2018 года из подборки «Marvel Cinematic Universe». Скотт Лэнг возвращается к квантовым технологиям и семейным тайнам Хэнков. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Комедия, Фантастика" },
      { label: "Внутренний номер", value: "tt5095030" },
    ],
  },
  {
    id: 233,
    tmdbId: 299537,
    imdbId: "tt4154664",
    slug: "captain-marvel",
    title: "Капитан Марвел",
    originalTitle: "Captain Marvel",
    searchTitles: ["Капитан Марвел", "Captain Marvel", "Marvel Cinematic Universe", "капитан марвел", "captain marvel"],
    type: "Фильм",
    year: "2019",
    rating: 6.8,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 299537, imdbId: "tt4154664", title: "Капитан Марвел", originalTitle: "Captain Marvel", year: "2019", type: "Фильм" }),
    description: "Кэрол Дэнверс узнаёт правду о прошлом и становится одной из сильнейших героинь Marvel.",
    trailerUrl: "",
    longDescription: "«Капитан Марвел» — фильм 2019 года из подборки «Marvel Cinematic Universe». Кэрол Дэнверс узнаёт правду о прошлом и становится одной из сильнейших героинь Marvel. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt4154664" },
    ],
  },
  {
    id: 234,
    tmdbId: 429617,
    imdbId: "tt6320628",
    slug: "spider-man-far-from-home",
    title: "Человек-паук: Вдали от дома",
    originalTitle: "Spider-Man: Far From Home",
    searchTitles: ["Человек-паук: Вдали от дома", "Spider-Man: Far From Home", "Marvel Cinematic Universe", "человек-паук: вдали от дома", "spider-man: far from home"],
    type: "Фильм",
    year: "2019",
    rating: 7.4,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 429617, imdbId: "tt6320628", title: "Человек-паук: Вдали от дома", originalTitle: "Spider-Man: Far From Home", year: "2019", type: "Фильм" }),
    description: "Питер Паркер отправляется в европейскую поездку, которая быстро перестаёт быть отпуском.",
    trailerUrl: "",
    longDescription: "«Человек-паук: Вдали от дома» — фильм 2019 года из подборки «Marvel Cinematic Universe». Питер Паркер отправляется в европейскую поездку, которая быстро перестаёт быть отпуском. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt6320628" },
    ],
  },
  {
    id: 235,
    tmdbId: 497698,
    imdbId: "tt3480822",
    slug: "black-widow",
    title: "Чёрная Вдова",
    originalTitle: "Black Widow",
    searchTitles: ["Чёрная Вдова", "Black Widow", "Marvel Cinematic Universe", "чёрная вдова", "black widow"],
    type: "Фильм",
    year: "2021",
    rating: 6.7,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 497698, imdbId: "tt3480822", title: "Чёрная Вдова", originalTitle: "Black Widow", year: "2021", type: "Фильм" }),
    description: "Наташа Романофф сталкивается с прошлым, семьёй и программой, из которой когда-то пыталась вырваться.",
    trailerUrl: "",
    longDescription: "«Чёрная Вдова» — фильм 2021 года из подборки «Marvel Cinematic Universe». Наташа Романофф сталкивается с прошлым, семьёй и программой, из которой когда-то пыталась вырваться. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt3480822" },
    ],
  },
  {
    id: 236,
    tmdbId: 566525,
    imdbId: "tt9376612",
    slug: "shang-chi-and-the-legend-of-the-ten-rings",
    title: "Шан-Чи и легенда десяти колец",
    originalTitle: "Shang-Chi and the Legend of the Ten Rings",
    searchTitles: ["Шан-Чи и легенда десяти колец", "Shang-Chi and the Legend of the Ten Rings", "Marvel Cinematic Universe", "шан-чи и легенда десяти колец", "shang-chi and the legend of the ten rings"],
    type: "Фильм",
    year: "2021",
    rating: 7.4,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 566525, imdbId: "tt9376612", title: "Шан-Чи и легенда десяти колец", originalTitle: "Shang-Chi and the Legend of the Ten Rings", year: "2021", type: "Фильм" }),
    description: "Шан-Чи возвращается к семейному наследию и вступает в конфликт с силой Десяти колец.",
    trailerUrl: "",
    longDescription: "«Шан-Чи и легенда десяти колец» — фильм 2021 года из подборки «Marvel Cinematic Universe». Шан-Чи возвращается к семейному наследию и вступает в конфликт с силой Десяти колец. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt9376612" },
    ],
  },
  {
    id: 237,
    tmdbId: 524434,
    imdbId: "tt9032400",
    slug: "eternals",
    title: "Вечные",
    originalTitle: "Eternals",
    searchTitles: ["Вечные", "Eternals", "Marvel Cinematic Universe", "вечные", "eternals"],
    type: "Фильм",
    year: "2021",
    rating: 6.3,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 524434, imdbId: "tt9032400", title: "Вечные", originalTitle: "Eternals", year: "2021", type: "Фильм" }),
    description: "Древняя команда защитников Земли выходит из тени после событий, меняющих судьбу планеты.",
    trailerUrl: "",
    longDescription: "«Вечные» — фильм 2021 года из подборки «Marvel Cinematic Universe». Древняя команда защитников Земли выходит из тени после событий, меняющих судьбу планеты. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt9032400" },
    ],
  },
  {
    id: 238,
    tmdbId: 453395,
    imdbId: "tt9419884",
    slug: "doctor-strange-in-the-multiverse-of-madness",
    title: "Доктор Стрэндж: В мультивселенной безумия",
    originalTitle: "Doctor Strange in the Multiverse of Madness",
    searchTitles: ["Доктор Стрэндж: В мультивселенной безумия", "Doctor Strange in the Multiverse of Madness", "Marvel Cinematic Universe", "доктор стрэндж: в мультивселенной безумия", "doctor strange in the multiverse of madness"],
    type: "Фильм",
    year: "2022",
    rating: 6.9,
    genres: ["Фэнтези", "Фантастика", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 453395, imdbId: "tt9419884", title: "Доктор Стрэндж: В мультивселенной безумия", originalTitle: "Doctor Strange in the Multiverse of Madness", year: "2022", type: "Фильм" }),
    description: "Доктор Стрэндж проходит через опасные варианты реальности, где цена решений становится всё выше.",
    trailerUrl: "",
    longDescription: "«Доктор Стрэндж: В мультивселенной безумия» — фильм 2022 года из подборки «Marvel Cinematic Universe». Доктор Стрэндж проходит через опасные варианты реальности, где цена решений становится всё выше. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Фэнтези, Фантастика, Боевик" },
      { label: "Внутренний номер", value: "tt9419884" },
    ],
  },
  {
    id: 239,
    tmdbId: 616037,
    imdbId: "tt10648342",
    slug: "thor-love-and-thunder",
    title: "Тор: Любовь и гром",
    originalTitle: "Thor: Love and Thunder",
    searchTitles: ["Тор: Любовь и гром", "Thor: Love and Thunder", "Marvel Cinematic Universe", "тор: любовь и гром", "thor: love and thunder"],
    type: "Фильм",
    year: "2022",
    rating: 6.2,
    genres: ["Боевик", "Комедия", "Фэнтези"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 616037, imdbId: "tt10648342", title: "Тор: Любовь и гром", originalTitle: "Thor: Love and Thunder", year: "2022", type: "Фильм" }),
    description: "Тор ищет новый смысл и сталкивается с противником, объявившим войну богам.",
    trailerUrl: "",
    longDescription: "«Тор: Любовь и гром» — фильм 2022 года из подборки «Marvel Cinematic Universe». Тор ищет новый смысл и сталкивается с противником, объявившим войну богам. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Комедия, Фэнтези" },
      { label: "Внутренний номер", value: "tt10648342" },
    ],
  },
  {
    id: 240,
    tmdbId: 505642,
    imdbId: "tt9114286",
    slug: "black-panther-wakanda-forever",
    title: "Чёрная Пантера: Ваканда навеки",
    originalTitle: "Black Panther: Wakanda Forever",
    searchTitles: ["Чёрная Пантера: Ваканда навеки", "Black Panther: Wakanda Forever", "Marvel Cinematic Universe", "чёрная пантера: ваканда навеки", "black panther: wakanda forever"],
    type: "Фильм",
    year: "2022",
    rating: 6.7,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 505642, imdbId: "tt9114286", title: "Чёрная Пантера: Ваканда навеки", originalTitle: "Black Panther: Wakanda Forever", year: "2022", type: "Фильм" }),
    description: "Ваканда переживает потерю короля и защищает своё будущее в новом мировом конфликте.",
    trailerUrl: "",
    longDescription: "«Чёрная Пантера: Ваканда навеки» — фильм 2022 года из подборки «Marvel Cinematic Universe». Ваканда переживает потерю короля и защищает своё будущее в новом мировом конфликте. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt9114286" },
    ],
  },
  {
    id: 241,
    tmdbId: 640146,
    imdbId: "tt10954600",
    slug: "ant-man-and-the-wasp-quantumania",
    title: "Человек-муравей и Оса: Квантомания",
    originalTitle: "Ant-Man and the Wasp: Quantumania",
    searchTitles: ["Человек-муравей и Оса: Квантомания", "Ant-Man and the Wasp: Quantumania", "Marvel Cinematic Universe", "человек-муравей и оса: квантомания", "ant-man and the wasp: quantumania"],
    type: "Фильм",
    year: "2023",
    rating: 6.1,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 640146, imdbId: "tt10954600", title: "Человек-муравей и Оса: Квантомания", originalTitle: "Ant-Man and the Wasp: Quantumania", year: "2023", type: "Фильм" }),
    description: "Семья Лэнга попадает в квантовый мир и сталкивается с угрозой, важной для будущего мультивселенной.",
    trailerUrl: "",
    longDescription: "«Человек-муравей и Оса: Квантомания» — фильм 2023 года из подборки «Marvel Cinematic Universe». Семья Лэнга попадает в квантовый мир и сталкивается с угрозой, важной для будущего мультивселенной. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt10954600" },
    ],
  },
  {
    id: 242,
    tmdbId: 447365,
    imdbId: "tt6791350",
    slug: "guardians-of-the-galaxy-vol-3",
    title: "Стражи Галактики. Часть 3",
    originalTitle: "Guardians of the Galaxy Vol. 3",
    searchTitles: ["Стражи Галактики. Часть 3", "Guardians of the Galaxy Vol. 3", "Marvel Cinematic Universe", "стражи галактики. часть 3", "guardians of the galaxy vol. 3"],
    type: "Фильм",
    year: "2023",
    rating: 8.0,
    genres: ["Фантастика", "Комедия", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 447365, imdbId: "tt6791350", title: "Стражи Галактики. Часть 3", originalTitle: "Guardians of the Galaxy Vol. 3", year: "2023", type: "Фильм" }),
    description: "Стражи проходят через личную историю Ракеты и проверяют команду на прочность.",
    trailerUrl: "",
    longDescription: "«Стражи Галактики. Часть 3» — фильм 2023 года из подборки «Marvel Cinematic Universe». Стражи проходят через личную историю Ракеты и проверяют команду на прочность. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Фантастика, Комедия, Приключения" },
      { label: "Внутренний номер", value: "tt6791350" },
    ],
  },
  {
    id: 243,
    tmdbId: 609681,
    imdbId: "tt10676048",
    slug: "the-marvels",
    title: "Капитан Марвел 2",
    originalTitle: "The Marvels",
    searchTitles: ["Капитан Марвел 2", "The Marvels", "Marvel Cinematic Universe", "капитан марвел 2", "the marvels"],
    type: "Фильм",
    year: "2023",
    rating: 5.7,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 609681, imdbId: "tt10676048", title: "Капитан Марвел 2", originalTitle: "The Marvels", year: "2023", type: "Фильм" }),
    description: "Кэрол Дэнверс, Камала Хан и Моника Рамбо оказываются связаны общей космической проблемой.",
    trailerUrl: "",
    longDescription: "«Капитан Марвел 2» — фильм 2023 года из подборки «Marvel Cinematic Universe». Кэрол Дэнверс, Камала Хан и Моника Рамбо оказываются связаны общей космической проблемой. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt10676048" },
    ],
  },
  {
    id: 244,
    tmdbId: 822119,
    imdbId: "tt14513804",
    slug: "captain-america-brave-new-world",
    title: "Капитан Америка: Новый мир",
    originalTitle: "Captain America: Brave New World",
    searchTitles: ["Капитан Америка: Новый мир", "Captain America: Brave New World", "Marvel Cinematic Universe", "капитан америка: новый мир", "captain america: brave new world"],
    type: "Фильм",
    year: "2025",
    rating: 5.8,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 822119, imdbId: "tt14513804", title: "Капитан Америка: Новый мир", originalTitle: "Captain America: Brave New World", year: "2025", type: "Фильм" }),
    description: "Сэм Уилсон принимает щит Капитана Америки и сталкивается с политическим кризисом нового уровня.",
    trailerUrl: "",
    longDescription: "«Капитан Америка: Новый мир» — фильм 2025 года из подборки «Marvel Cinematic Universe». Сэм Уилсон принимает щит Капитана Америки и сталкивается с политическим кризисом нового уровня. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2025" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt14513804" },
    ],
  },
  {
    id: 245,
    slug: "avengers-secret-wars",
    title: "Мстители: Секретные войны",
    originalTitle: "Avengers: Secret Wars",
    searchTitles: ["Мстители: Секретные войны", "Avengers: Secret Wars", "Marvel Cinematic Universe", "мстители: секретные войны", "avengers: secret wars"],
    type: "Фильм",
    year: "2027",
    rating: 0.0,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ title: "Мстители: Секретные войны", originalTitle: "Avengers: Secret Wars", year: "2027", type: "Фильм" }),
    description: "Запланированное масштабное завершение мультивселенской арки Marvel Studios.",
    trailerUrl: "",
    longDescription: "«Мстители: Секретные войны» — фильм 2027 года из подборки «Marvel Cinematic Universe». Запланированное масштабное завершение мультивселенской арки Marvel Studios. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2027" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Cinematic Universe" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
    ],
  },
  {
    id: 246,
    tmdbId: 557,
    imdbId: "tt0145487",
    slug: "spider-man",
    title: "Человек-паук",
    originalTitle: "Spider-Man",
    searchTitles: ["Человек-паук", "Spider-Man", "человек-паук", "spider-man"],
    type: "Фильм",
    year: "2002",
    rating: 7.4,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 557, imdbId: "tt0145487", title: "Человек-паук", originalTitle: "Spider-Man", year: "2002", type: "Фильм" }),
    description: "Питер Паркер получает способности паука и учится быть героем, не теряя человеческое лицо.",
    trailerUrl: "",
    longDescription: "«Человек-паук» — фильм 2002 года из подборки «Spider-Man». Питер Паркер получает способности паука и учится быть героем, не теряя человеческое лицо. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2002" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Spider-Man" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0145487" },
    ],
  },
  {
    id: 247,
    tmdbId: 558,
    imdbId: "tt0316654",
    slug: "spider-man-2",
    title: "Человек-паук 2",
    originalTitle: "Spider-Man 2",
    searchTitles: ["Человек-паук 2", "Spider-Man 2", "Spider-Man", "человек-паук 2", "spider-man 2"],
    type: "Фильм",
    year: "2004",
    rating: 7.5,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 558, imdbId: "tt0316654", title: "Человек-паук 2", originalTitle: "Spider-Man 2", year: "2004", type: "Фильм" }),
    description: "Питер сталкивается с Доктором Осьминогом и тяжестью двойной жизни.",
    trailerUrl: "",
    longDescription: "«Человек-паук 2» — фильм 2004 года из подборки «Spider-Man». Питер сталкивается с Доктором Осьминогом и тяжестью двойной жизни. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2004" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Spider-Man" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0316654" },
    ],
  },
  {
    id: 248,
    tmdbId: 559,
    imdbId: "tt0413300",
    slug: "spider-man-3",
    title: "Человек-паук 3: Враг в отражении",
    originalTitle: "Spider-Man 3",
    searchTitles: ["Человек-паук 3: Враг в отражении", "Spider-Man 3", "Spider-Man", "человек-паук 3: враг в отражении", "spider-man 3"],
    type: "Фильм",
    year: "2007",
    rating: 6.3,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 559, imdbId: "tt0413300", title: "Человек-паук 3: Враг в отражении", originalTitle: "Spider-Man 3", year: "2007", type: "Фильм" }),
    description: "Питер Паркер сталкивается с новыми врагами и собственной тёмной стороной.",
    trailerUrl: "",
    longDescription: "«Человек-паук 3: Враг в отражении» — фильм 2007 года из подборки «Spider-Man». Питер Паркер сталкивается с новыми врагами и собственной тёмной стороной. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2007" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Spider-Man" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0413300" },
    ],
  },
  {
    id: 249,
    tmdbId: 1930,
    imdbId: "tt0948470",
    slug: "the-amazing-spider-man",
    title: "Новый Человек-паук",
    originalTitle: "The Amazing Spider-Man",
    searchTitles: ["Новый Человек-паук", "The Amazing Spider-Man", "Spider-Man", "новый человек-паук", "the amazing spider-man"],
    type: "Фильм",
    year: "2012",
    rating: 6.9,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1930, imdbId: "tt0948470", title: "Новый Человек-паук", originalTitle: "The Amazing Spider-Man", year: "2012", type: "Фильм" }),
    description: "Новая версия истории Питера Паркера, его способностей и поиска правды о семье.",
    trailerUrl: "",
    longDescription: "«Новый Человек-паук» — фильм 2012 года из подборки «Spider-Man». Новая версия истории Питера Паркера, его способностей и поиска правды о семье. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Spider-Man" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0948470" },
    ],
  },
  {
    id: 250,
    tmdbId: 102382,
    imdbId: "tt1872181",
    slug: "the-amazing-spider-man-2",
    title: "Новый Человек-паук: Высокое напряжение",
    originalTitle: "The Amazing Spider-Man 2",
    searchTitles: ["Новый Человек-паук: Высокое напряжение", "The Amazing Spider-Man 2", "Spider-Man", "новый человек-паук: высокое напряжение", "the amazing spider-man 2"],
    type: "Фильм",
    year: "2014",
    rating: 6.6,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 102382, imdbId: "tt1872181", title: "Новый Человек-паук: Высокое напряжение", originalTitle: "The Amazing Spider-Man 2", year: "2014", type: "Фильм" }),
    description: "Питер защищает Нью-Йорк и сталкивается с врагами, связанными с Oscorp.",
    trailerUrl: "",
    longDescription: "«Новый Человек-паук: Высокое напряжение» — фильм 2014 года из подборки «Spider-Man». Питер защищает Нью-Йорк и сталкивается с врагами, связанными с Oscorp. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Spider-Man" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1872181" },
    ],
  },
  {
    id: 251,
    tmdbId: 324857,
    imdbId: "tt4633694",
    slug: "spider-man-into-the-spider-verse",
    title: "Человек-паук: Через вселенные",
    originalTitle: "Spider-Man: Into the Spider-Verse",
    searchTitles: ["Человек-паук: Через вселенные", "Spider-Man: Into the Spider-Verse", "Spider-Man", "человек-паук: через вселенные", "spider-man: into the spider-verse"],
    type: "Мультфильм",
    year: "2018",
    rating: 8.4,
    genres: ["Анимация", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 324857, imdbId: "tt4633694", title: "Человек-паук: Через вселенные", originalTitle: "Spider-Man: Into the Spider-Verse", year: "2018", type: "Мультфильм" }),
    description: "Майлз Моралес открывает мультивселенную и встречает других Людей-пауков.",
    trailerUrl: "",
    longDescription: "«Человек-паук: Через вселенные» — мультфильм 2018 года из подборки «Spider-Man». Майлз Моралес открывает мультивселенную и встречает других Людей-пауков. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Spider-Man" },
      { label: "Жанры", value: "Анимация, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt4633694" },
    ],
  },
  {
    id: 252,
    tmdbId: 911916,
    imdbId: "tt16360004",
    slug: "spider-man-beyond-the-spider-verse",
    title: "Человек-паук: За пределами вселенных",
    originalTitle: "Spider-Man: Beyond the Spider-Verse",
    searchTitles: ["Человек-паук: За пределами вселенных", "Spider-Man: Beyond the Spider-Verse", "Spider-Man", "человек-паук: за пределами вселенных", "spider-man: beyond the spider-verse"],
    type: "Мультфильм",
    year: "2027",
    rating: 0.0,
    genres: ["Анимация", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 911916, imdbId: "tt16360004", title: "Человек-паук: За пределами вселенных", originalTitle: "Spider-Man: Beyond the Spider-Verse", year: "2027", type: "Мультфильм" }),
    description: "Запланированное продолжение истории Майлза Моралеса и анимационной трилогии Spider-Verse.",
    trailerUrl: "",
    longDescription: "«Человек-паук: За пределами вселенных» — мультфильм 2027 года из подборки «Spider-Man». Запланированное продолжение истории Майлза Моралеса и анимационной трилогии Spider-Verse. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2027" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Spider-Man" },
      { label: "Жанры", value: "Анимация, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt16360004" },
    ],
  },
  {
    id: 253,
    tmdbId: 335983,
    imdbId: "tt1270797",
    slug: "venom",
    title: "Веном",
    originalTitle: "Venom",
    searchTitles: ["Веном", "Venom", "Sony Spider-Man Universe", "веном", "venom"],
    type: "Фильм",
    year: "2018",
    rating: 6.6,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 335983, imdbId: "tt1270797", title: "Веном", originalTitle: "Venom", year: "2018", type: "Фильм" }),
    description: "Журналист Эдди Брок становится носителем инопланетного симбиота.",
    trailerUrl: "",
    longDescription: "«Веном» — фильм 2018 года из подборки «Sony Spider-Man Universe». Журналист Эдди Брок становится носителем инопланетного симбиота. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Sony Spider-Man Universe" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
      { label: "Внутренний номер", value: "tt1270797" },
    ],
  },
  {
    id: 254,
    tmdbId: 580489,
    imdbId: "tt7097896",
    slug: "venom-let-there-be-carnage",
    title: "Веном 2",
    originalTitle: "Venom: Let There Be Carnage",
    searchTitles: ["Веном 2", "Venom: Let There Be Carnage", "Sony Spider-Man Universe", "веном 2", "venom: let there be carnage"],
    type: "Фильм",
    year: "2021",
    rating: 5.9,
    genres: ["Фантастика", "Боевик", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 580489, imdbId: "tt7097896", title: "Веном 2", originalTitle: "Venom: Let There Be Carnage", year: "2021", type: "Фильм" }),
    description: "Эдди и Веном сталкиваются с новым симбиотом и ещё более хаотичным противником.",
    trailerUrl: "",
    longDescription: "«Веном 2» — фильм 2021 года из подборки «Sony Spider-Man Universe». Эдди и Веном сталкиваются с новым симбиотом и ещё более хаотичным противником. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Sony Spider-Man Universe" },
      { label: "Жанры", value: "Фантастика, Боевик, Комедия" },
      { label: "Внутренний номер", value: "tt7097896" },
    ],
  },
  {
    id: 255,
    tmdbId: 526896,
    imdbId: "tt5108870",
    slug: "morbius",
    title: "Морбиус",
    originalTitle: "Morbius",
    searchTitles: ["Морбиус", "Morbius", "Sony Spider-Man Universe", "морбиус", "morbius"],
    type: "Фильм",
    year: "2022",
    rating: 5.2,
    genres: ["Фантастика", "Боевик", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 526896, imdbId: "tt5108870", title: "Морбиус", originalTitle: "Morbius", year: "2022", type: "Фильм" }),
    description: "Учёный Майкл Морбиус пытается вылечить болезнь и получает опасные способности.",
    trailerUrl: "",
    longDescription: "«Морбиус» — фильм 2022 года из подборки «Sony Spider-Man Universe». Учёный Майкл Морбиус пытается вылечить болезнь и получает опасные способности. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Sony Spider-Man Universe" },
      { label: "Жанры", value: "Фантастика, Боевик, Триллер" },
      { label: "Внутренний номер", value: "tt5108870" },
    ],
  },
  {
    id: 256,
    tmdbId: 634492,
    imdbId: "tt11057302",
    slug: "madame-web",
    title: "Мадам Паутина",
    originalTitle: "Madame Web",
    searchTitles: ["Мадам Паутина", "Madame Web", "Sony Spider-Man Universe", "мадам паутина", "madame web"],
    type: "Фильм",
    year: "2024",
    rating: 3.9,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 634492, imdbId: "tt11057302", title: "Мадам Паутина", originalTitle: "Madame Web", year: "2024", type: "Фильм" }),
    description: "Кассандра Уэб начинает видеть варианты будущего и оказывается связана с новым паучьим мифом.",
    trailerUrl: "",
    longDescription: "«Мадам Паутина» — фильм 2024 года из подборки «Sony Spider-Man Universe». Кассандра Уэб начинает видеть варианты будущего и оказывается связана с новым паучьим мифом. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Sony Spider-Man Universe" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt11057302" },
    ],
  },
  {
    id: 257,
    tmdbId: 539972,
    imdbId: "tt8790086",
    slug: "kraven-the-hunter",
    title: "Крейвен-охотник",
    originalTitle: "Kraven the Hunter",
    searchTitles: ["Крейвен-охотник", "Kraven the Hunter", "Sony Spider-Man Universe", "крейвен-охотник", "kraven the hunter"],
    type: "Фильм",
    year: "2024",
    rating: 5.4,
    genres: ["Боевик", "Приключения", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 539972, imdbId: "tt8790086", title: "Крейвен-охотник", originalTitle: "Kraven the Hunter", year: "2024", type: "Фильм" }),
    description: "История Сергея Кравинова, охотника с собственным кодексом и конфликтом с прошлым.",
    trailerUrl: "",
    longDescription: "«Крейвен-охотник» — фильм 2024 года из подборки «Sony Spider-Man Universe». История Сергея Кравинова, охотника с собственным кодексом и конфликтом с прошлым. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Sony Spider-Man Universe" },
      { label: "Жанры", value: "Боевик, Приключения, Триллер" },
      { label: "Внутренний номер", value: "tt8790086" },
    ],
  },
  {
    id: 258,
    tmdbId: 36657,
    imdbId: "tt0120903",
    slug: "x-men",
    title: "Люди Икс",
    originalTitle: "X-Men",
    searchTitles: ["Люди Икс", "X-Men", "люди икс", "x-men"],
    type: "Фильм",
    year: "2000",
    rating: 7.3,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 36657, imdbId: "tt0120903", title: "Люди Икс", originalTitle: "X-Men", year: "2000", type: "Фильм" }),
    description: "Мутанты пытаются защитить людей и себя в мире, который их боится.",
    trailerUrl: "",
    longDescription: "«Люди Икс» — фильм 2000 года из подборки «X-Men». Мутанты пытаются защитить людей и себя в мире, который их боится. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2000" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0120903" },
    ],
  },
  {
    id: 259,
    tmdbId: 36658,
    imdbId: "tt0290334",
    slug: "x2",
    title: "Люди Икс 2",
    originalTitle: "X2",
    searchTitles: ["Люди Икс 2", "X2", "X-Men", "люди икс 2", "x2"],
    type: "Фильм",
    year: "2003",
    rating: 7.4,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 36658, imdbId: "tt0290334", title: "Люди Икс 2", originalTitle: "X2", year: "2003", type: "Фильм" }),
    description: "Люди Икс сталкиваются с угрозой, которая вынуждает старых врагов искать временный союз.",
    trailerUrl: "",
    longDescription: "«Люди Икс 2» — фильм 2003 года из подборки «X-Men». Люди Икс сталкиваются с угрозой, которая вынуждает старых врагов искать временный союз. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0290334" },
    ],
  },
  {
    id: 260,
    tmdbId: 36668,
    imdbId: "tt0376994",
    slug: "x-men-the-last-stand",
    title: "Люди Икс: Последняя битва",
    originalTitle: "X-Men: The Last Stand",
    searchTitles: ["Люди Икс: Последняя битва", "X-Men: The Last Stand", "X-Men", "люди икс: последняя битва", "x-men: the last stand"],
    type: "Фильм",
    year: "2006",
    rating: 6.6,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 36668, imdbId: "tt0376994", title: "Люди Икс: Последняя битва", originalTitle: "X-Men: The Last Stand", year: "2006", type: "Фильм" }),
    description: "Команда сталкивается с лекарством от мутаций и кризисом внутри собственного мира.",
    trailerUrl: "",
    longDescription: "«Люди Икс: Последняя битва» — фильм 2006 года из подборки «X-Men». Команда сталкивается с лекарством от мутаций и кризисом внутри собственного мира. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2006" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0376994" },
    ],
  },
  {
    id: 261,
    tmdbId: 2080,
    imdbId: "tt0458525",
    slug: "x-men-origins-wolverine",
    title: "Люди Икс: Начало. Росомаха",
    originalTitle: "X-Men Origins: Wolverine",
    searchTitles: ["Люди Икс: Начало. Росомаха", "X-Men Origins: Wolverine", "X-Men", "люди икс: начало. росомаха", "x-men origins: wolverine"],
    type: "Фильм",
    year: "2009",
    rating: 6.5,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 2080, imdbId: "tt0458525", title: "Люди Икс: Начало. Росомаха", originalTitle: "X-Men Origins: Wolverine", year: "2009", type: "Фильм" }),
    description: "Фильм раскрывает прошлое Логана и путь к образу Росомахи.",
    trailerUrl: "",
    longDescription: "«Люди Икс: Начало. Росомаха» — фильм 2009 года из подборки «X-Men». Фильм раскрывает прошлое Логана и путь к образу Росомахи. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2009" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0458525" },
    ],
  },
  {
    id: 262,
    tmdbId: 49538,
    imdbId: "tt1270798",
    slug: "x-men-first-class",
    title: "Люди Икс: Первый класс",
    originalTitle: "X-Men: First Class",
    searchTitles: ["Люди Икс: Первый класс", "X-Men: First Class", "X-Men", "люди икс: первый класс", "x-men: first class"],
    type: "Фильм",
    year: "2011",
    rating: 7.7,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 49538, imdbId: "tt1270798", title: "Люди Икс: Первый класс", originalTitle: "X-Men: First Class", year: "2011", type: "Фильм" }),
    description: "История молодого Профессора Икс, Магнето и формирования новой команды мутантов.",
    trailerUrl: "",
    longDescription: "«Люди Икс: Первый класс» — фильм 2011 года из подборки «X-Men». История молодого Профессора Икс, Магнето и формирования новой команды мутантов. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1270798" },
    ],
  },
  {
    id: 263,
    tmdbId: 76170,
    imdbId: "tt1430132",
    slug: "the-wolverine",
    title: "Росомаха: Бессмертный",
    originalTitle: "The Wolverine",
    searchTitles: ["Росомаха: Бессмертный", "The Wolverine", "X-Men", "росомаха: бессмертный", "the wolverine"],
    type: "Фильм",
    year: "2013",
    rating: 6.7,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 76170, imdbId: "tt1430132", title: "Росомаха: Бессмертный", originalTitle: "The Wolverine", year: "2013", type: "Фильм" }),
    description: "Логан отправляется в Японию и сталкивается с прошлым, честью и собственной уязвимостью.",
    trailerUrl: "",
    longDescription: "«Росомаха: Бессмертный» — фильм 2013 года из подборки «X-Men». Логан отправляется в Японию и сталкивается с прошлым, честью и собственной уязвимостью. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1430132" },
    ],
  },
  {
    id: 264,
    tmdbId: 127585,
    imdbId: "tt1877832",
    slug: "x-men-days-of-future-past",
    title: "Люди Икс: Дни минувшего будущего",
    originalTitle: "X-Men: Days of Future Past",
    searchTitles: ["Люди Икс: Дни минувшего будущего", "X-Men: Days of Future Past", "X-Men", "люди икс: дни минувшего будущего", "x-men: days of future past"],
    type: "Фильм",
    year: "2014",
    rating: 7.9,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 127585, imdbId: "tt1877832", title: "Люди Икс: Дни минувшего будущего", originalTitle: "X-Men: Days of Future Past", year: "2014", type: "Фильм" }),
    description: "Мутанты пытаются изменить прошлое, чтобы предотвратить катастрофическое будущее.",
    trailerUrl: "",
    longDescription: "«Люди Икс: Дни минувшего будущего» — фильм 2014 года из подборки «X-Men». Мутанты пытаются изменить прошлое, чтобы предотвратить катастрофическое будущее. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1877832" },
    ],
  },
  {
    id: 265,
    tmdbId: 293660,
    imdbId: "tt1431045",
    slug: "deadpool",
    title: "Дэдпул",
    originalTitle: "Deadpool",
    searchTitles: ["Дэдпул", "Deadpool", "X-Men", "дэдпул", "deadpool"],
    type: "Фильм",
    year: "2016",
    rating: 8.0,
    genres: ["Боевик", "Комедия", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 293660, imdbId: "tt1431045", title: "Дэдпул", originalTitle: "Deadpool", year: "2016", type: "Фильм" }),
    description: "Уэйд Уилсон становится Дэдпулом и превращает супергеройскую историю в дерзкий экшен.",
    trailerUrl: "",
    longDescription: "«Дэдпул» — фильм 2016 года из подборки «X-Men». Уэйд Уилсон становится Дэдпулом и превращает супергеройскую историю в дерзкий экшен. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Комедия, Фантастика" },
      { label: "Внутренний номер", value: "tt1431045" },
    ],
  },
  {
    id: 266,
    tmdbId: 246655,
    imdbId: "tt3385516",
    slug: "x-men-apocalypse",
    title: "Люди Икс: Апокалипсис",
    originalTitle: "X-Men: Apocalypse",
    searchTitles: ["Люди Икс: Апокалипсис", "X-Men: Apocalypse", "X-Men", "люди икс: апокалипсис", "x-men: apocalypse"],
    type: "Фильм",
    year: "2016",
    rating: 6.9,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 246655, imdbId: "tt3385516", title: "Люди Икс: Апокалипсис", originalTitle: "X-Men: Apocalypse", year: "2016", type: "Фильм" }),
    description: "Команда мутантов сталкивается с древней силой, угрожающей всему миру.",
    trailerUrl: "",
    longDescription: "«Люди Икс: Апокалипсис» — фильм 2016 года из подборки «X-Men». Команда мутантов сталкивается с древней силой, угрожающей всему миру. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt3385516" },
    ],
  },
  {
    id: 267,
    tmdbId: 263115,
    imdbId: "tt3315342",
    slug: "logan",
    title: "Логан",
    originalTitle: "Logan",
    searchTitles: ["Логан", "Logan", "X-Men", "логан", "logan"],
    type: "Фильм",
    year: "2017",
    rating: 8.1,
    genres: ["Боевик", "Драма", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 263115, imdbId: "tt3315342", title: "Логан", originalTitle: "Logan", year: "2017", type: "Фильм" }),
    description: "Постаревший Логан пытается защитить девочку-мутанта в мрачном будущем.",
    trailerUrl: "",
    longDescription: "«Логан» — фильм 2017 года из подборки «X-Men». Постаревший Логан пытается защитить девочку-мутанта в мрачном будущем. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Драма, Фантастика" },
      { label: "Внутренний номер", value: "tt3315342" },
    ],
  },
  {
    id: 268,
    tmdbId: 383498,
    imdbId: "tt5463162",
    slug: "deadpool-2",
    title: "Дэдпул 2",
    originalTitle: "Deadpool 2",
    searchTitles: ["Дэдпул 2", "Deadpool 2", "X-Men", "дэдпул 2", "deadpool 2"],
    type: "Фильм",
    year: "2018",
    rating: 7.6,
    genres: ["Боевик", "Комедия", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 383498, imdbId: "tt5463162", title: "Дэдпул 2", originalTitle: "Deadpool 2", year: "2018", type: "Фильм" }),
    description: "Дэдпул собирает необычную команду и снова ломает привычные правила супергеройского кино.",
    trailerUrl: "",
    longDescription: "«Дэдпул 2» — фильм 2018 года из подборки «X-Men». Дэдпул собирает необычную команду и снова ломает привычные правила супергеройского кино. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Комедия, Фантастика" },
      { label: "Внутренний номер", value: "tt5463162" },
    ],
  },
  {
    id: 269,
    tmdbId: 320288,
    imdbId: "tt6565702",
    slug: "dark-phoenix",
    title: "Люди Икс: Тёмный Феникс",
    originalTitle: "Dark Phoenix",
    searchTitles: ["Люди Икс: Тёмный Феникс", "Dark Phoenix", "X-Men", "люди икс: тёмный феникс", "dark phoenix"],
    type: "Фильм",
    year: "2019",
    rating: 5.7,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 320288, imdbId: "tt6565702", title: "Люди Икс: Тёмный Феникс", originalTitle: "Dark Phoenix", year: "2019", type: "Фильм" }),
    description: "Джин Грей получает силу, которая становится испытанием для всей команды.",
    trailerUrl: "",
    longDescription: "«Люди Икс: Тёмный Феникс» — фильм 2019 года из подборки «X-Men». Джин Грей получает силу, которая становится испытанием для всей команды. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt6565702" },
    ],
  },
  {
    id: 270,
    tmdbId: 340102,
    imdbId: "tt4682266",
    slug: "the-new-mutants",
    title: "Новые мутанты",
    originalTitle: "The New Mutants",
    searchTitles: ["Новые мутанты", "The New Mutants", "X-Men", "новые мутанты", "the new mutants"],
    type: "Фильм",
    year: "2020",
    rating: 5.3,
    genres: ["Фантастика", "Триллер", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 340102, imdbId: "tt4682266", title: "Новые мутанты", originalTitle: "The New Mutants", year: "2020", type: "Фильм" }),
    description: "Молодые мутанты оказываются в закрытом учреждении и сталкиваются со своими страхами.",
    trailerUrl: "",
    longDescription: "«Новые мутанты» — фильм 2020 года из подборки «X-Men». Молодые мутанты оказываются в закрытом учреждении и сталкиваются со своими страхами. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2020" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "X-Men" },
      { label: "Жанры", value: "Фантастика, Триллер, Боевик" },
      { label: "Внутренний номер", value: "tt4682266" },
    ],
  },
  {
    id: 271,
    tmdbId: 9738,
    imdbId: "tt0120667",
    slug: "fantastic-four",
    title: "Фантастическая четвёрка",
    originalTitle: "Fantastic Four",
    searchTitles: ["Фантастическая четвёрка", "Fantastic Four", "фантастическая четвёрка", "fantastic four"],
    type: "Фильм",
    year: "2005",
    rating: 5.7,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 9738, imdbId: "tt0120667", title: "Фантастическая четвёрка", originalTitle: "Fantastic Four", year: "2005", type: "Фильм" }),
    description: "Четыре героя получают необычные способности после космического эксперимента.",
    trailerUrl: "",
    longDescription: "«Фантастическая четвёрка» — фильм 2005 года из подборки «Fantastic Four». Четыре героя получают необычные способности после космического эксперимента. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2005" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fantastic Four" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0120667" },
    ],
  },
  {
    id: 272,
    tmdbId: 1979,
    imdbId: "tt0486576",
    slug: "fantastic-four-rise-of-the-silver-surfer",
    title: "Фантастическая четвёрка: Вторжение Серебряного сёрфера",
    originalTitle: "Fantastic Four: Rise of the Silver Surfer",
    searchTitles: ["Фантастическая четвёрка: Вторжение Серебряного сёрфера", "Fantastic Four: Rise of the Silver Surfer", "Fantastic Four", "фантастическая четвёрка: вторжение серебряного сёрфера", "fantastic four: rise of the silver surfer"],
    type: "Фильм",
    year: "2007",
    rating: 5.6,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1979, imdbId: "tt0486576", title: "Фантастическая четвёрка: Вторжение Серебряного сёрфера", originalTitle: "Fantastic Four: Rise of the Silver Surfer", year: "2007", type: "Фильм" }),
    description: "Команда сталкивается с Серебряным сёрфером и угрозой космического масштаба.",
    trailerUrl: "",
    longDescription: "«Фантастическая четвёрка: Вторжение Серебряного сёрфера» — фильм 2007 года из подборки «Fantastic Four». Команда сталкивается с Серебряным сёрфером и угрозой космического масштаба. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2007" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fantastic Four" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0486576" },
    ],
  },
  {
    id: 273,
    tmdbId: 166424,
    imdbId: "tt1502712",
    slug: "fantastic-four-2015",
    title: "Фантастическая четвёрка",
    originalTitle: "Fantastic Four",
    searchTitles: ["Фантастическая четвёрка", "Fantastic Four", "фантастическая четвёрка", "fantastic four"],
    type: "Фильм",
    year: "2015",
    rating: 4.3,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 166424, imdbId: "tt1502712", title: "Фантастическая четвёрка", originalTitle: "Fantastic Four", year: "2015", type: "Фильм" }),
    description: "Новая версия происхождения команды, связанная с экспериментом и другим измерением.",
    trailerUrl: "",
    longDescription: "«Фантастическая четвёрка» — фильм 2015 года из подборки «Fantastic Four». Новая версия происхождения команды, связанная с экспериментом и другим измерением. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fantastic Four" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1502712" },
    ],
  },
  {
    id: 274,
    tmdbId: 36647,
    imdbId: "tt0120611",
    slug: "blade",
    title: "Блэйд",
    originalTitle: "Blade",
    searchTitles: ["Блэйд", "Blade", "Marvel Legacy", "блэйд", "blade"],
    type: "Фильм",
    year: "1998",
    rating: 7.1,
    genres: ["Боевик", "Фэнтези", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 36647, imdbId: "tt0120611", title: "Блэйд", originalTitle: "Blade", year: "1998", type: "Фильм" }),
    description: "Полувампир Блэйд охотится на тех, кто угрожает людям из тени.",
    trailerUrl: "",
    longDescription: "«Блэйд» — фильм 1998 года из подборки «Marvel Legacy». Полувампир Блэйд охотится на тех, кто угрожает людям из тени. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1998" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Фэнтези, Триллер" },
      { label: "Внутренний номер", value: "tt0120611" },
    ],
  },
  {
    id: 275,
    tmdbId: 36586,
    imdbId: "tt0187738",
    slug: "blade-ii",
    title: "Блэйд 2",
    originalTitle: "Blade II",
    searchTitles: ["Блэйд 2", "Blade II", "Marvel Legacy", "блэйд 2", "blade ii"],
    type: "Фильм",
    year: "2002",
    rating: 6.7,
    genres: ["Боевик", "Фэнтези", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 36586, imdbId: "tt0187738", title: "Блэйд 2", originalTitle: "Blade II", year: "2002", type: "Фильм" }),
    description: "Блэйд вступает во временный союз с врагами против новой опасной угрозы.",
    trailerUrl: "",
    longDescription: "«Блэйд 2» — фильм 2002 года из подборки «Marvel Legacy». Блэйд вступает во временный союз с врагами против новой опасной угрозы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2002" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Фэнтези, Триллер" },
      { label: "Внутренний номер", value: "tt0187738" },
    ],
  },
  {
    id: 276,
    tmdbId: 36648,
    imdbId: "tt0359017",
    slug: "blade-trinity",
    title: "Блэйд: Троица",
    originalTitle: "Blade: Trinity",
    searchTitles: ["Блэйд: Троица", "Blade: Trinity", "Marvel Legacy", "блэйд: троица", "blade: trinity"],
    type: "Фильм",
    year: "2004",
    rating: 5.8,
    genres: ["Боевик", "Фэнтези", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 36648, imdbId: "tt0359017", title: "Блэйд: Троица", originalTitle: "Blade: Trinity", year: "2004", type: "Фильм" }),
    description: "Блэйд сталкивается с новым противником и получает помощь от команды охотников.",
    trailerUrl: "",
    longDescription: "«Блэйд: Троица» — фильм 2004 года из подборки «Marvel Legacy». Блэйд сталкивается с новым противником и получает помощь от команды охотников. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2004" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Фэнтези, Триллер" },
      { label: "Внутренний номер", value: "tt0359017" },
    ],
  },
  {
    id: 277,
    tmdbId: 1927,
    imdbId: "tt0286716",
    slug: "hulk",
    title: "Халк",
    originalTitle: "Hulk",
    searchTitles: ["Халк", "Hulk", "Marvel Legacy", "халк", "hulk"],
    type: "Фильм",
    year: "2003",
    rating: 5.6,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1927, imdbId: "tt0286716", title: "Халк", originalTitle: "Hulk", year: "2003", type: "Фильм" }),
    description: "Брюс Бэннер превращается в Халка и пытается понять источник своей силы.",
    trailerUrl: "",
    longDescription: "«Халк» — фильм 2003 года из подборки «Marvel Legacy». Брюс Бэннер превращается в Халка и пытается понять источник своей силы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0286716" },
    ],
  },
  {
    id: 278,
    tmdbId: 9480,
    imdbId: "tt0287978",
    slug: "daredevil",
    title: "Сорвиголова",
    originalTitle: "Daredevil",
    searchTitles: ["Сорвиголова", "Daredevil", "Marvel Legacy", "сорвиголова", "daredevil"],
    type: "Фильм",
    year: "2003",
    rating: 5.3,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 9480, imdbId: "tt0287978", title: "Сорвиголова", originalTitle: "Daredevil", year: "2003", type: "Фильм" }),
    description: "Слепой адвокат Мэтт Мёрдок ночью защищает город как Сорвиголова.",
    trailerUrl: "",
    longDescription: "«Сорвиголова» — фильм 2003 года из подборки «Marvel Legacy». Слепой адвокат Мэтт Мёрдок ночью защищает город как Сорвиголова. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0287978" },
    ],
  },
  {
    id: 279,
    tmdbId: 9947,
    imdbId: "tt0357277",
    slug: "elektra",
    title: "Электра",
    originalTitle: "Elektra",
    searchTitles: ["Электра", "Elektra", "Marvel Legacy", "электра", "elektra"],
    type: "Фильм",
    year: "2005",
    rating: 4.7,
    genres: ["Боевик", "Фэнтези", "Криминал"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 9947, imdbId: "tt0357277", title: "Электра", originalTitle: "Elektra", year: "2005", type: "Фильм" }),
    description: "Электра получает шанс на новую жизнь и сталкивается с опасным заказом.",
    trailerUrl: "",
    longDescription: "«Электра» — фильм 2005 года из подборки «Marvel Legacy». Электра получает шанс на новую жизнь и сталкивается с опасным заказом. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2005" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Фэнтези, Криминал" },
      { label: "Внутренний номер", value: "tt0357277" },
    ],
  },
  {
    id: 280,
    tmdbId: 1250,
    imdbId: "tt0259324",
    slug: "ghost-rider",
    title: "Призрачный гонщик",
    originalTitle: "Ghost Rider",
    searchTitles: ["Призрачный гонщик", "Ghost Rider", "Marvel Legacy", "призрачный гонщик", "ghost rider"],
    type: "Фильм",
    year: "2007",
    rating: 5.3,
    genres: ["Боевик", "Фэнтези", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1250, imdbId: "tt0259324", title: "Призрачный гонщик", originalTitle: "Ghost Rider", year: "2007", type: "Фильм" }),
    description: "Джонни Блэйз получает проклятие и становится гонщиком с огненной силой.",
    trailerUrl: "",
    longDescription: "«Призрачный гонщик» — фильм 2007 года из подборки «Marvel Legacy». Джонни Блэйз получает проклятие и становится гонщиком с огненной силой. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2007" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Фэнтези, Триллер" },
      { label: "Внутренний номер", value: "tt0259324" },
    ],
  },
  {
    id: 281,
    tmdbId: 71676,
    imdbId: "tt1071875",
    slug: "ghost-rider-spirit-of-vengeance",
    title: "Призрачный гонщик 2",
    originalTitle: "Ghost Rider: Spirit of Vengeance",
    searchTitles: ["Призрачный гонщик 2", "Ghost Rider: Spirit of Vengeance", "Marvel Legacy", "призрачный гонщик 2", "ghost rider: spirit of vengeance"],
    type: "Фильм",
    year: "2011",
    rating: 4.3,
    genres: ["Боевик", "Фэнтези", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 71676, imdbId: "tt1071875", title: "Призрачный гонщик 2", originalTitle: "Ghost Rider: Spirit of Vengeance", year: "2011", type: "Фильм" }),
    description: "Джонни Блэйз снова вынужден использовать проклятую силу ради защиты ребёнка.",
    trailerUrl: "",
    longDescription: "«Призрачный гонщик 2» — фильм 2011 года из подборки «Marvel Legacy». Джонни Блэйз снова вынужден использовать проклятую силу ради защиты ребёнка. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Фэнтези, Триллер" },
      { label: "Внутренний номер", value: "tt1071875" },
    ],
  },
  {
    id: 282,
    tmdbId: 7220,
    imdbId: "tt0330793",
    slug: "the-punisher",
    title: "Каратель",
    originalTitle: "The Punisher",
    searchTitles: ["Каратель", "The Punisher", "Marvel Legacy", "каратель", "the punisher"],
    type: "Фильм",
    year: "2004",
    rating: 6.4,
    genres: ["Боевик", "Криминал", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 7220, imdbId: "tt0330793", title: "Каратель", originalTitle: "The Punisher", year: "2004", type: "Фильм" }),
    description: "Фрэнк Касл выходит против преступного мира после личной трагедии.",
    trailerUrl: "",
    longDescription: "«Каратель» — фильм 2004 года из подборки «Marvel Legacy». Фрэнк Касл выходит против преступного мира после личной трагедии. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2004" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Криминал, Драма" },
      { label: "Внутренний номер", value: "tt0330793" },
    ],
  },
  {
    id: 283,
    tmdbId: 13056,
    imdbId: "tt0450314",
    slug: "punisher-war-zone",
    title: "Каратель: Территория войны",
    originalTitle: "Punisher: War Zone",
    searchTitles: ["Каратель: Территория войны", "Punisher: War Zone", "Marvel Legacy", "каратель: территория войны", "punisher: war zone"],
    type: "Фильм",
    year: "2008",
    rating: 5.9,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 13056, imdbId: "tt0450314", title: "Каратель: Территория войны", originalTitle: "Punisher: War Zone", year: "2008", type: "Фильм" }),
    description: "Фрэнк Касл продолжает борьбу с преступностью и сталкивается с новым врагом.",
    trailerUrl: "",
    longDescription: "«Каратель: Территория войны» — фильм 2008 года из подборки «Marvel Legacy». Фрэнк Касл продолжает борьбу с преступностью и сталкивается с новым врагом. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2008" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Marvel Legacy" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt0450314" },
    ],
  },
  {
    id: 284,
    tmdbId: 2661,
    imdbId: "tt0060153",
    slug: "batman",
    title: "Бэтмен",
    originalTitle: "Batman",
    searchTitles: ["Бэтмен", "Batman", "Batman / DC", "бэтмен", "batman"],
    type: "Фильм",
    year: "1966",
    rating: 6.5,
    genres: ["Комедия", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 2661, imdbId: "tt0060153", title: "Бэтмен", originalTitle: "Batman", year: "1966", type: "Фильм" }),
    description: "Классическая яркая версия Бэтмена и Робина с духом комикс-сериала шестидесятых.",
    trailerUrl: "",
    longDescription: "«Бэтмен» — фильм 1966 года из подборки «Batman / DC». Классическая яркая версия Бэтмена и Робина с духом комикс-сериала шестидесятых. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1966" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Комедия, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0060153" },
    ],
  },
  {
    id: 285,
    tmdbId: 268,
    imdbId: "tt0096895",
    slug: "batman-1989",
    title: "Бэтмен",
    originalTitle: "Batman",
    searchTitles: ["Бэтмен", "Batman", "Batman / DC", "бэтмен", "batman"],
    type: "Фильм",
    year: "1989",
    rating: 7.5,
    genres: ["Боевик", "Криминал", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 268, imdbId: "tt0096895", title: "Бэтмен", originalTitle: "Batman", year: "1989", type: "Фильм" }),
    description: "Готэм знакомится с Бэтменом, а Джокер превращает город в театр хаоса.",
    trailerUrl: "",
    longDescription: "«Бэтмен» — фильм 1989 года из подборки «Batman / DC». Готэм знакомится с Бэтменом, а Джокер превращает город в театр хаоса. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1989" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Криминал, Фантастика" },
      { label: "Внутренний номер", value: "tt0096895" },
    ],
  },
  {
    id: 286,
    tmdbId: 364,
    imdbId: "tt0103776",
    slug: "batman-returns",
    title: "Бэтмен возвращается",
    originalTitle: "Batman Returns",
    searchTitles: ["Бэтмен возвращается", "Batman Returns", "Batman / DC", "бэтмен возвращается", "batman returns"],
    type: "Фильм",
    year: "1992",
    rating: 7.1,
    genres: ["Боевик", "Криминал", "Фэнтези"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 364, imdbId: "tt0103776", title: "Бэтмен возвращается", originalTitle: "Batman Returns", year: "1992", type: "Фильм" }),
    description: "Бэтмен сталкивается с Пингвином и Женщиной-кошкой в мрачном зимнем Готэме.",
    trailerUrl: "",
    longDescription: "«Бэтмен возвращается» — фильм 1992 года из подборки «Batman / DC». Бэтмен сталкивается с Пингвином и Женщиной-кошкой в мрачном зимнем Готэме. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1992" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Криминал, Фэнтези" },
      { label: "Внутренний номер", value: "tt0103776" },
    ],
  },
  {
    id: 287,
    tmdbId: 414,
    imdbId: "tt0112462",
    slug: "batman-forever",
    title: "Бэтмен навсегда",
    originalTitle: "Batman Forever",
    searchTitles: ["Бэтмен навсегда", "Batman Forever", "Batman / DC", "бэтмен навсегда", "batman forever"],
    type: "Фильм",
    year: "1995",
    rating: 5.4,
    genres: ["Боевик", "Криминал", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 414, imdbId: "tt0112462", title: "Бэтмен навсегда", originalTitle: "Batman Forever", year: "1995", type: "Фильм" }),
    description: "Бэтмен противостоит Загадочнику и Двуликому в более яркой версии Готэма.",
    trailerUrl: "",
    longDescription: "«Бэтмен навсегда» — фильм 1995 года из подборки «Batman / DC». Бэтмен противостоит Загадочнику и Двуликому в более яркой версии Готэма. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1995" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Криминал, Фантастика" },
      { label: "Внутренний номер", value: "tt0112462" },
    ],
  },
  {
    id: 288,
    tmdbId: 415,
    imdbId: "tt0118688",
    slug: "batman-and-robin",
    title: "Бэтмен и Робин",
    originalTitle: "Batman & Robin",
    searchTitles: ["Бэтмен и Робин", "Batman & Robin", "Batman / DC", "бэтмен и робин", "batman & robin"],
    type: "Фильм",
    year: "1997",
    rating: 3.8,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 415, imdbId: "tt0118688", title: "Бэтмен и Робин", originalTitle: "Batman & Robin", year: "1997", type: "Фильм" }),
    description: "Бэтмен, Робин и Бэтгёрл сталкиваются с Мистером Фризом и Ядовитым плющом.",
    trailerUrl: "",
    longDescription: "«Бэтмен и Робин» — фильм 1997 года из подборки «Batman / DC». Бэтмен, Робин и Бэтгёрл сталкиваются с Мистером Фризом и Ядовитым плющом. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1997" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0118688" },
    ],
  },
  {
    id: 289,
    tmdbId: 14919,
    imdbId: "tt0106364",
    slug: "batman-mask-of-the-phantasm",
    title: "Бэтмен: Маска Фантазма",
    originalTitle: "Batman: Mask of the Phantasm",
    searchTitles: ["Бэтмен: Маска Фантазма", "Batman: Mask of the Phantasm", "Batman / DC", "бэтмен: маска фантазма", "batman: mask of the phantasm"],
    type: "Мультфильм",
    year: "1993",
    rating: 7.8,
    genres: ["Анимация", "Криминал", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 14919, imdbId: "tt0106364", title: "Бэтмен: Маска Фантазма", originalTitle: "Batman: Mask of the Phantasm", year: "1993", type: "Мультфильм" }),
    description: "Анимационная история о прошлом Брюса Уэйна и новой фигуре, появившейся в Готэме.",
    trailerUrl: "",
    longDescription: "«Бэтмен: Маска Фантазма» — мультфильм 1993 года из подборки «Batman / DC». Анимационная история о прошлом Брюса Уэйна и новой фигуре, появившейся в Готэме. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1993" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Анимация, Криминал, Драма" },
      { label: "Внутренний номер", value: "tt0106364" },
    ],
  },
  {
    id: 290,
    tmdbId: 272,
    imdbId: "tt0372784",
    slug: "batman-begins",
    title: "Бэтмен: Начало",
    originalTitle: "Batman Begins",
    searchTitles: ["Бэтмен: Начало", "Batman Begins", "Batman / DC", "бэтмен: начало", "batman begins"],
    type: "Фильм",
    year: "2005",
    rating: 8.2,
    genres: ["Боевик", "Криминал", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 272, imdbId: "tt0372784", title: "Бэтмен: Начало", originalTitle: "Batman Begins", year: "2005", type: "Фильм" }),
    description: "Брюс Уэйн проходит путь от личной травмы к созданию символа Бэтмена.",
    trailerUrl: "",
    longDescription: "«Бэтмен: Начало» — фильм 2005 года из подборки «Batman / DC». Брюс Уэйн проходит путь от личной травмы к созданию символа Бэтмена. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2005" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Криминал, Драма" },
      { label: "Внутренний номер", value: "tt0372784" },
    ],
  },
  {
    id: 291,
    tmdbId: 49026,
    imdbId: "tt1345836",
    slug: "the-dark-knight-rises",
    title: "Тёмный рыцарь: Возрождение легенды",
    originalTitle: "The Dark Knight Rises",
    searchTitles: ["Тёмный рыцарь: Возрождение легенды", "The Dark Knight Rises", "Batman / DC", "тёмный рыцарь: возрождение легенды", "the dark knight rises"],
    type: "Фильм",
    year: "2012",
    rating: 8.4,
    genres: ["Боевик", "Криминал", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 49026, imdbId: "tt1345836", title: "Тёмный рыцарь: Возрождение легенды", originalTitle: "The Dark Knight Rises", year: "2012", type: "Фильм" }),
    description: "Брюс Уэйн возвращается, когда Готэму угрожает Бэйн и новая волна разрушения.",
    trailerUrl: "",
    longDescription: "«Тёмный рыцарь: Возрождение легенды» — фильм 2012 года из подборки «Batman / DC». Брюс Уэйн возвращается, когда Готэму угрожает Бэйн и новая волна разрушения. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Криминал, Драма" },
      { label: "Внутренний номер", value: "tt1345836" },
    ],
  },
  {
    id: 292,
    tmdbId: 209112,
    imdbId: "tt2975590",
    slug: "batman-v-superman-dawn-of-justice",
    title: "Бэтмен против Супермена: На заре справедливости",
    originalTitle: "Batman v Superman: Dawn of Justice",
    searchTitles: ["Бэтмен против Супермена: На заре справедливости", "Batman v Superman: Dawn of Justice", "Batman / DC", "бэтмен против супермена: на заре справедливости", "batman v superman: dawn of justice"],
    type: "Фильм",
    year: "2016",
    rating: 6.5,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 209112, imdbId: "tt2975590", title: "Бэтмен против Супермена: На заре справедливости", originalTitle: "Batman v Superman: Dawn of Justice", year: "2016", type: "Фильм" }),
    description: "Столкновение Бэтмена и Супермена становится началом более широкой истории DC.",
    trailerUrl: "",
    longDescription: "«Бэтмен против Супермена: На заре справедливости» — фильм 2016 года из подборки «Batman / DC». Столкновение Бэтмена и Супермена становится началом более широкой истории DC. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt2975590" },
    ],
  },
  {
    id: 293,
    tmdbId: 297761,
    imdbId: "tt1386697",
    slug: "suicide-squad",
    title: "Отряд самоубийц",
    originalTitle: "Suicide Squad",
    searchTitles: ["Отряд самоубийц", "Suicide Squad", "Batman / DC", "отряд самоубийц", "suicide squad"],
    type: "Фильм",
    year: "2016",
    rating: 5.9,
    genres: ["Боевик", "Фантастика", "Криминал"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 297761, imdbId: "tt1386697", title: "Отряд самоубийц", originalTitle: "Suicide Squad", year: "2016", type: "Фильм" }),
    description: "Команда опасных антигероев получает миссию, от которой нельзя отказаться.",
    trailerUrl: "",
    longDescription: "«Отряд самоубийц» — фильм 2016 года из подборки «Batman / DC». Команда опасных антигероев получает миссию, от которой нельзя отказаться. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Фантастика, Криминал" },
      { label: "Внутренний номер", value: "tt1386697" },
    ],
  },
  {
    id: 294,
    tmdbId: 141052,
    imdbId: "tt0974015",
    slug: "justice-league",
    title: "Лига справедливости",
    originalTitle: "Justice League",
    searchTitles: ["Лига справедливости", "Justice League", "Batman / DC", "лига справедливости", "justice league"],
    type: "Фильм",
    year: "2017",
    rating: 6.1,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 141052, imdbId: "tt0974015", title: "Лига справедливости", originalTitle: "Justice League", year: "2017", type: "Фильм" }),
    description: "Герои DC объединяются, чтобы остановить угрозу, с которой одному не справиться.",
    trailerUrl: "",
    longDescription: "«Лига справедливости» — фильм 2017 года из подборки «Batman / DC». Герои DC объединяются, чтобы остановить угрозу, с которой одному не справиться. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0974015" },
    ],
  },
  {
    id: 295,
    tmdbId: 791373,
    imdbId: "tt12361974",
    slug: "zack-snyder-s-justice-league",
    title: "Лига справедливости Зака Снайдера",
    originalTitle: "Zack Snyder's Justice League",
    searchTitles: ["Лига справедливости Зака Снайдера", "Zack Snyder's Justice League", "Batman / DC", "лига справедливости зака снайдера", "zack snyder's justice league"],
    type: "Фильм",
    year: "2021",
    rating: 7.9,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 791373, imdbId: "tt12361974", title: "Лига справедливости Зака Снайдера", originalTitle: "Zack Snyder's Justice League", year: "2021", type: "Фильм" }),
    description: "Расширенная версия истории о формировании Лиги справедливости и борьбе со Степным Волком.",
    trailerUrl: "",
    longDescription: "«Лига справедливости Зака Снайдера» — фильм 2021 года из подборки «Batman / DC». Расширенная версия истории о формировании Лиги справедливости и борьбе со Степным Волком. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt12361974" },
    ],
  },
  {
    id: 296,
    tmdbId: 414906,
    imdbId: "tt1877830",
    slug: "the-batman-2022",
    title: "Бэтмен",
    originalTitle: "The Batman",
    searchTitles: ["Бэтмен", "The Batman", "Batman / DC", "бэтмен", "the batman"],
    type: "Фильм",
    year: "2022",
    rating: 7.8,
    genres: ["Криминал", "Детектив", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 414906, imdbId: "tt1877830", title: "Бэтмен", originalTitle: "The Batman", year: "2022", type: "Фильм" }),
    description: "Молодой Бэтмен расследует серию загадок в дождливом и коррумпированном Готэме.",
    trailerUrl: "",
    longDescription: "«Бэтмен» — фильм 2022 года из подборки «Batman / DC». Молодой Бэтмен расследует серию загадок в дождливом и коррумпированном Готэме. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Криминал, Детектив, Боевик" },
      { label: "Внутренний номер", value: "tt1877830" },
    ],
  },
  {
    id: 297,
    tmdbId: 324849,
    imdbId: "tt4116284",
    slug: "the-lego-batman-movie",
    title: "Лего Фильм: Бэтмен",
    originalTitle: "The Lego Batman Movie",
    searchTitles: ["Лего Фильм: Бэтмен", "The Lego Batman Movie", "Batman / DC", "лего фильм: бэтмен", "the lego batman movie"],
    type: "Мультфильм",
    year: "2017",
    rating: 7.3,
    genres: ["Анимация", "Комедия", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 324849, imdbId: "tt4116284", title: "Лего Фильм: Бэтмен", originalTitle: "The Lego Batman Movie", year: "2017", type: "Мультфильм" }),
    description: "Лего-Бэтмен учится работать в команде и быть чуть менее драматичным, чем обычно.",
    trailerUrl: "",
    longDescription: "«Лего Фильм: Бэтмен» — мультфильм 2017 года из подборки «Batman / DC». Лего-Бэтмен учится работать в команде и быть чуть менее драматичным, чем обычно. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Анимация, Комедия, Приключения" },
      { label: "Внутренний номер", value: "tt4116284" },
    ],
  },
  {
    id: 298,
    tmdbId: 475557,
    imdbId: "tt7286456",
    slug: "joker",
    title: "Джокер",
    originalTitle: "Joker",
    searchTitles: ["Джокер", "Joker", "Batman / DC", "джокер", "joker"],
    type: "Фильм",
    year: "2019",
    rating: 8.4,
    genres: ["Драма", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 475557, imdbId: "tt7286456", title: "Джокер", originalTitle: "Joker", year: "2019", type: "Фильм" }),
    description: "Мрачная самостоятельная история о человеке, который постепенно превращается в Джокера.",
    trailerUrl: "",
    longDescription: "«Джокер» — фильм 2019 года из подборки «Batman / DC». Мрачная самостоятельная история о человеке, который постепенно превращается в Джокера. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Драма, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt7286456" },
    ],
  },
  {
    id: 299,
    tmdbId: 889737,
    imdbId: "tt11315808",
    slug: "joker-folie-deux",
    title: "Джокер: Безумие на двоих",
    originalTitle: "Joker: Folie à Deux",
    searchTitles: ["Джокер: Безумие на двоих", "Joker: Folie à Deux", "Batman / DC", "джокер: безумие на двоих", "joker: folie à deux"],
    type: "Фильм",
    year: "2024",
    rating: 5.2,
    genres: ["Драма", "Криминал", "Музыкальный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 889737, imdbId: "tt11315808", title: "Джокер: Безумие на двоих", originalTitle: "Joker: Folie à Deux", year: "2024", type: "Фильм" }),
    description: "Продолжение истории Джокера в необычном жанровом формате.",
    trailerUrl: "",
    longDescription: "«Джокер: Безумие на двоих» — фильм 2024 года из подборки «Batman / DC». Продолжение истории Джокера в необычном жанровом формате. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Драма, Криминал, Музыкальный" },
      { label: "Внутренний номер", value: "tt11315808" },
    ],
  },
  {
    id: 300,
    tmdbId: 298618,
    imdbId: "tt0439572",
    slug: "the-flash",
    title: "Флэш",
    originalTitle: "The Flash",
    searchTitles: ["Флэш", "The Flash", "Batman / DC", "флэш", "the flash"],
    type: "Фильм",
    year: "2023",
    rating: 6.6,
    genres: ["Боевик", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 298618, imdbId: "tt0439572", title: "Флэш", originalTitle: "The Flash", year: "2023", type: "Фильм" }),
    description: "Барри Аллен меняет прошлое и сталкивается с последствиями для всей мультивселенной DC.",
    trailerUrl: "",
    longDescription: "«Флэш» — фильм 2023 года из подборки «Batman / DC». Барри Аллен меняет прошлое и сталкивается с последствиями для всей мультивселенной DC. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Batman / DC" },
      { label: "Жанры", value: "Боевик, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0439572" },
    ],
  },
  {
    id: 301,
    tmdbId: 1893,
    imdbId: "tt0120915",
    slug: "star-wars-episode-i-the-phantom-menace",
    title: "Звёздные войны: Эпизод I — Скрытая угроза",
    originalTitle: "Star Wars: Episode I - The Phantom Menace",
    searchTitles: ["Звёздные войны: Эпизод I — Скрытая угроза", "Star Wars: Episode I - The Phantom Menace", "Star Wars", "звёздные войны: эпизод i — скрытая угроза", "star wars: episode i - the phantom menace"],
    type: "Фильм",
    year: "1999",
    rating: 6.5,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1893, imdbId: "tt0120915", title: "Звёздные войны: Эпизод I — Скрытая угроза", originalTitle: "Star Wars: Episode I - The Phantom Menace", year: "1999", type: "Фильм" }),
    description: "Начало приквельной трилогии о Республике, джедаях и мальчике с необычной судьбой.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Эпизод I — Скрытая угроза» — фильм 1999 года из подборки «Star Wars». Начало приквельной трилогии о Республике, джедаях и мальчике с необычной судьбой. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1999" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0120915" },
    ],
  },
  {
    id: 302,
    tmdbId: 1894,
    imdbId: "tt0121765",
    slug: "star-wars-episode-ii-attack-of-the-clones",
    title: "Звёздные войны: Эпизод II — Атака клонов",
    originalTitle: "Star Wars: Episode II - Attack of the Clones",
    searchTitles: ["Звёздные войны: Эпизод II — Атака клонов", "Star Wars: Episode II - Attack of the Clones", "Star Wars", "звёздные войны: эпизод ii — атака клонов", "star wars: episode ii - attack of the clones"],
    type: "Фильм",
    year: "2002",
    rating: 6.6,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1894, imdbId: "tt0121765", title: "Звёздные войны: Эпизод II — Атака клонов", originalTitle: "Star Wars: Episode II - Attack of the Clones", year: "2002", type: "Фильм" }),
    description: "Галактика движется к войне, а судьба Анакина Скайуокера становится всё сложнее.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Эпизод II — Атака клонов» — фильм 2002 года из подборки «Star Wars». Галактика движется к войне, а судьба Анакина Скайуокера становится всё сложнее. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2002" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0121765" },
    ],
  },
  {
    id: 303,
    tmdbId: 1895,
    imdbId: "tt0121766",
    slug: "star-wars-episode-iii-revenge-of-the-sith",
    title: "Звёздные войны: Эпизод III — Месть ситхов",
    originalTitle: "Star Wars: Episode III - Revenge of the Sith",
    searchTitles: ["Звёздные войны: Эпизод III — Месть ситхов", "Star Wars: Episode III - Revenge of the Sith", "Star Wars", "звёздные войны: эпизод iii — месть ситхов", "star wars: episode iii - revenge of the sith"],
    type: "Фильм",
    year: "2005",
    rating: 7.6,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1895, imdbId: "tt0121766", title: "Звёздные войны: Эпизод III — Месть ситхов", originalTitle: "Star Wars: Episode III - Revenge of the Sith", year: "2005", type: "Фильм" }),
    description: "Республика рушится, а история Анакина Скайуокера подходит к трагическому перелому.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Эпизод III — Месть ситхов» — фильм 2005 года из подборки «Star Wars». Республика рушится, а история Анакина Скайуокера подходит к трагическому перелому. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2005" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0121766" },
    ],
  },
  {
    id: 304,
    tmdbId: 11,
    imdbId: "tt0076759",
    slug: "star-wars-episode-iv-a-new-hope",
    title: "Звёздные войны: Эпизод IV — Новая надежда",
    originalTitle: "Star Wars: Episode IV - A New Hope",
    searchTitles: ["Звёздные войны: Эпизод IV — Новая надежда", "Star Wars: Episode IV - A New Hope", "Star Wars", "звёздные войны: эпизод iv — новая надежда", "star wars: episode iv - a new hope"],
    type: "Фильм",
    year: "1977",
    rating: 8.6,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 11, imdbId: "tt0076759", title: "Звёздные войны: Эпизод IV — Новая надежда", originalTitle: "Star Wars: Episode IV - A New Hope", year: "1977", type: "Фильм" }),
    description: "Люк Скайуокер вступает в борьбу Повстанцев против Империи и открывает путь джедая.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Эпизод IV — Новая надежда» — фильм 1977 года из подборки «Star Wars». Люк Скайуокер вступает в борьбу Повстанцев против Империи и открывает путь джедая. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1977" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0076759" },
    ],
  },
  {
    id: 305,
    tmdbId: 1891,
    imdbId: "tt0080684",
    slug: "star-wars-episode-v-the-empire-strikes-back",
    title: "Звёздные войны: Эпизод V — Империя наносит ответный удар",
    originalTitle: "Star Wars: Episode V - The Empire Strikes Back",
    searchTitles: ["Звёздные войны: Эпизод V — Империя наносит ответный удар", "Star Wars: Episode V - The Empire Strikes Back", "Star Wars", "звёздные войны: эпизод v — империя наносит ответный удар", "star wars: episode v - the empire strikes back"],
    type: "Фильм",
    year: "1980",
    rating: 8.7,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1891, imdbId: "tt0080684", title: "Звёздные войны: Эпизод V — Империя наносит ответный удар", originalTitle: "Star Wars: Episode V - The Empire Strikes Back", year: "1980", type: "Фильм" }),
    description: "Повстанцы терпят удар Империи, а Люк узнаёт больше о Силе и собственной судьбе.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Эпизод V — Империя наносит ответный удар» — фильм 1980 года из подборки «Star Wars». Повстанцы терпят удар Империи, а Люк узнаёт больше о Силе и собственной судьбе. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1980" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0080684" },
    ],
  },
  {
    id: 306,
    tmdbId: 1892,
    imdbId: "tt0086190",
    slug: "star-wars-episode-vi-return-of-the-jedi",
    title: "Звёздные войны: Эпизод VI — Возвращение джедая",
    originalTitle: "Star Wars: Episode VI - Return of the Jedi",
    searchTitles: ["Звёздные войны: Эпизод VI — Возвращение джедая", "Star Wars: Episode VI - Return of the Jedi", "Star Wars", "звёздные войны: эпизод vi — возвращение джедая", "star wars: episode vi - return of the jedi"],
    type: "Фильм",
    year: "1983",
    rating: 8.3,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1892, imdbId: "tt0086190", title: "Звёздные войны: Эпизод VI — Возвращение джедая", originalTitle: "Star Wars: Episode VI - Return of the Jedi", year: "1983", type: "Фильм" }),
    description: "Финал классической трилогии о борьбе Повстанцев с Империей и судьбе семьи Скайуокеров.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Эпизод VI — Возвращение джедая» — фильм 1983 года из подборки «Star Wars». Финал классической трилогии о борьбе Повстанцев с Империей и судьбе семьи Скайуокеров. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1983" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0086190" },
    ],
  },
  {
    id: 307,
    tmdbId: 140607,
    imdbId: "tt2488496",
    slug: "star-wars-the-force-awakens",
    title: "Звёздные войны: Пробуждение силы",
    originalTitle: "Star Wars: The Force Awakens",
    searchTitles: ["Звёздные войны: Пробуждение силы", "Star Wars: The Force Awakens", "Star Wars", "звёздные войны: пробуждение силы", "star wars: the force awakens"],
    type: "Фильм",
    year: "2015",
    rating: 7.8,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 140607, imdbId: "tt2488496", title: "Звёздные войны: Пробуждение силы", originalTitle: "Star Wars: The Force Awakens", year: "2015", type: "Фильм" }),
    description: "Новые герои сталкиваются с Первым орденом и наследием старых легенд.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Пробуждение силы» — фильм 2015 года из подборки «Star Wars». Новые герои сталкиваются с Первым орденом и наследием старых легенд. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt2488496" },
    ],
  },
  {
    id: 308,
    tmdbId: 181808,
    imdbId: "tt2527336",
    slug: "star-wars-the-last-jedi",
    title: "Звёздные войны: Последние джедаи",
    originalTitle: "Star Wars: The Last Jedi",
    searchTitles: ["Звёздные войны: Последние джедаи", "Star Wars: The Last Jedi", "Star Wars", "звёздные войны: последние джедаи", "star wars: the last jedi"],
    type: "Фильм",
    year: "2017",
    rating: 6.9,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 181808, imdbId: "tt2527336", title: "Звёздные войны: Последние джедаи", originalTitle: "Star Wars: The Last Jedi", year: "2017", type: "Фильм" }),
    description: "Рей ищет своё место в Силе, а Сопротивление пытается выжить под давлением Первого ордена.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Последние джедаи» — фильм 2017 года из подборки «Star Wars». Рей ищет своё место в Силе, а Сопротивление пытается выжить под давлением Первого ордена. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt2527336" },
    ],
  },
  {
    id: 309,
    tmdbId: 181812,
    imdbId: "tt2527338",
    slug: "star-wars-the-rise-of-skywalker",
    title: "Звёздные войны: Скайуокер. Восход",
    originalTitle: "Star Wars: The Rise of Skywalker",
    searchTitles: ["Звёздные войны: Скайуокер. Восход", "Star Wars: The Rise of Skywalker", "Star Wars", "звёздные войны: скайуокер. восход", "star wars: the rise of skywalker"],
    type: "Фильм",
    year: "2019",
    rating: 6.4,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 181812, imdbId: "tt2527338", title: "Звёздные войны: Скайуокер. Восход", originalTitle: "Star Wars: The Rise of Skywalker", year: "2019", type: "Фильм" }),
    description: "Заключительная часть сиквел-трилогии о финальном столкновении Сопротивления и тёмных сил.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Скайуокер. Восход» — фильм 2019 года из подборки «Star Wars». Заключительная часть сиквел-трилогии о финальном столкновении Сопротивления и тёмных сил. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt2527338" },
    ],
  },
  {
    id: 310,
    tmdbId: 330459,
    imdbId: "tt3748528",
    slug: "rogue-one-a-star-wars-story",
    title: "Изгой-один: Звёздные войны. Истории",
    originalTitle: "Rogue One: A Star Wars Story",
    searchTitles: ["Изгой-один: Звёздные войны. Истории", "Rogue One: A Star Wars Story", "Star Wars", "изгой-один: звёздные войны. истории", "rogue one: a star wars story"],
    type: "Фильм",
    year: "2016",
    rating: 7.8,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 330459, imdbId: "tt3748528", title: "Изгой-один: Звёздные войны. Истории", originalTitle: "Rogue One: A Star Wars Story", year: "2016", type: "Фильм" }),
    description: "Группа повстанцев пытается добыть планы Звезды смерти перед событиями классической трилогии.",
    trailerUrl: "",
    longDescription: "«Изгой-один: Звёздные войны. Истории» — фильм 2016 года из подборки «Star Wars». Группа повстанцев пытается добыть планы Звезды смерти перед событиями классической трилогии. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt3748528" },
    ],
  },
  {
    id: 311,
    tmdbId: 348350,
    imdbId: "tt3778644",
    slug: "solo-a-star-wars-story",
    title: "Хан Соло: Звёздные войны. Истории",
    originalTitle: "Solo: A Star Wars Story",
    searchTitles: ["Хан Соло: Звёздные войны. Истории", "Solo: A Star Wars Story", "Star Wars", "хан соло: звёздные войны. истории", "solo: a star wars story"],
    type: "Фильм",
    year: "2018",
    rating: 6.9,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 348350, imdbId: "tt3778644", title: "Хан Соло: Звёздные войны. Истории", originalTitle: "Solo: A Star Wars Story", year: "2018", type: "Фильм" }),
    description: "Молодой Хан Соло проходит через первые опасные приключения и знакомится с будущими союзниками.",
    trailerUrl: "",
    longDescription: "«Хан Соло: Звёздные войны. Истории» — фильм 2018 года из подборки «Star Wars». Молодой Хан Соло проходит через первые опасные приключения и знакомится с будущими союзниками. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt3778644" },
    ],
  },
  {
    id: 312,
    tmdbId: 12180,
    imdbId: "tt1185834",
    slug: "star-wars-the-clone-wars-movie",
    title: "Звёздные войны: Войны клонов",
    originalTitle: "Star Wars: The Clone Wars",
    searchTitles: ["Звёздные войны: Войны клонов", "Star Wars: The Clone Wars", "Star Wars", "звёздные войны: войны клонов", "star wars: the clone wars"],
    type: "Мультфильм",
    year: "2008",
    rating: 5.9,
    genres: ["Анимация", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 12180, imdbId: "tt1185834", title: "Звёздные войны: Войны клонов", originalTitle: "Star Wars: The Clone Wars", year: "2008", type: "Мультфильм" }),
    description: "Анимационный фильм, расширяющий историю Войн клонов между вторым и третьим эпизодами.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Войны клонов» — мультфильм 2008 года из подборки «Star Wars». Анимационный фильм, расширяющий историю Войн клонов между вторым и третьим эпизодами. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2008" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Анимация, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt1185834" },
    ],
  },
  {
    id: 313,
    imdbId: "tt8466564",
    slug: "obi-wan-kenobi",
    title: "Оби-Ван Кеноби",
    originalTitle: "Obi-Wan Kenobi",
    searchTitles: ["Оби-Ван Кеноби", "Obi-Wan Kenobi", "Star Wars", "оби-ван кеноби", "obi-wan kenobi"],
    type: "Сериал",
    year: "2022",
    rating: 7.1,
    genres: ["Фантастика", "Приключения", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt8466564", title: "Оби-Ван Кеноби", originalTitle: "Obi-Wan Kenobi", year: "2022", type: "Сериал" }),
    description: "Оби-Ван живёт в изгнании, но прошлое снова заставляет его выйти из тени.",
    trailerUrl: "",
    longDescription: "«Оби-Ван Кеноби» — сериал 2022 года из подборки «Star Wars». Оби-Ван живёт в изгнании, но прошлое снова заставляет его выйти из тени. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Драма" },
      { label: "Внутренний номер", value: "tt8466564" },
    ],
  },
  {
    id: 314,
    imdbId: "tt13622776",
    slug: "ahsoka",
    title: "Асока",
    originalTitle: "Ahsoka",
    searchTitles: ["Асока", "Ahsoka", "Star Wars", "асока", "ahsoka"],
    type: "Сериал",
    year: "2023",
    rating: 7.5,
    genres: ["Фантастика", "Приключения", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt13622776", title: "Асока", originalTitle: "Ahsoka", year: "2023", type: "Сериал" }),
    description: "Асока Тано расследует новую угрозу и продолжает линию героев эпохи после Империи.",
    trailerUrl: "",
    longDescription: "«Асока» — сериал 2023 года из подборки «Star Wars». Асока Тано расследует новую угрозу и продолжает линию героев эпохи после Империи. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Драма" },
      { label: "Внутренний номер", value: "tt13622776" },
    ],
  },
  {
    id: 315,
    imdbId: "tt13668894",
    slug: "the-book-of-boba-fett",
    title: "Книга Бобы Фетта",
    originalTitle: "The Book of Boba Fett",
    searchTitles: ["Книга Бобы Фетта", "The Book of Boba Fett", "Star Wars", "книга бобы фетта", "the book of boba fett"],
    type: "Сериал",
    year: "2021",
    rating: 7.2,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt13668894", title: "Книга Бобы Фетта", originalTitle: "The Book of Boba Fett", year: "2021", type: "Сериал" }),
    description: "Боба Фетт пытается занять место в криминальном мире Татуина по собственным правилам.",
    trailerUrl: "",
    longDescription: "«Книга Бобы Фетта» — сериал 2021 года из подборки «Star Wars». Боба Фетт пытается занять место в криминальном мире Татуина по собственным правилам. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt13668894" },
    ],
  },
  {
    id: 316,
    imdbId: "tt12262202",
    slug: "the-acolyte",
    title: "Аколит",
    originalTitle: "The Acolyte",
    searchTitles: ["Аколит", "The Acolyte", "Star Wars", "аколит", "the acolyte"],
    type: "Сериал",
    year: "2024",
    rating: 4.2,
    genres: ["Фантастика", "Детектив", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt12262202", title: "Аколит", originalTitle: "The Acolyte", year: "2024", type: "Сериал" }),
    description: "События эпохи Высокой Республики раскрывают тайны, связанные с тёмной стороной Силы.",
    trailerUrl: "",
    longDescription: "«Аколит» — сериал 2024 года из подборки «Star Wars». События эпохи Высокой Республики раскрывают тайны, связанные с тёмной стороной Силы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Детектив, Приключения" },
      { label: "Внутренний номер", value: "tt12262202" },
    ],
  },
  {
    id: 317,
    imdbId: "tt20600980",
    slug: "star-wars-skeleton-crew",
    title: "Опорная команда",
    originalTitle: "Star Wars: Skeleton Crew",
    searchTitles: ["Опорная команда", "Star Wars: Skeleton Crew", "Star Wars", "опорная команда", "star wars: skeleton crew"],
    type: "Сериал",
    year: "2024",
    rating: 7.2,
    genres: ["Фантастика", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt20600980", title: "Опорная команда", originalTitle: "Star Wars: Skeleton Crew", year: "2024", type: "Сериал" }),
    description: "Группа детей теряется в большой галактике и пытается найти дорогу домой.",
    trailerUrl: "",
    longDescription: "«Опорная команда» — сериал 2024 года из подборки «Star Wars». Группа детей теряется в большой галактике и пытается найти дорогу домой. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Фантастика, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt20600980" },
    ],
  },
  {
    id: 318,
    imdbId: "tt0458290",
    slug: "star-wars-the-clone-wars-series",
    title: "Звёздные войны: Войны клонов",
    originalTitle: "Star Wars: The Clone Wars",
    searchTitles: ["Звёздные войны: Войны клонов", "Star Wars: The Clone Wars", "Star Wars", "звёздные войны: войны клонов", "star wars: the clone wars"],
    type: "Сериал",
    year: "2008",
    rating: 8.4,
    genres: ["Анимация", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0458290", title: "Звёздные войны: Войны клонов", originalTitle: "Star Wars: The Clone Wars", year: "2008", type: "Сериал" }),
    description: "Анимационный сериал о событиях Войн клонов, джедаях, клонах и судьбе галактики.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Войны клонов» — сериал 2008 года из подборки «Star Wars». Анимационный сериал о событиях Войн клонов, джедаях, клонах и судьбе галактики. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2008" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Анимация, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt0458290" },
    ],
  },
  {
    id: 319,
    imdbId: "tt2930604",
    slug: "star-wars-rebels",
    title: "Звёздные войны: Повстанцы",
    originalTitle: "Star Wars Rebels",
    searchTitles: ["Звёздные войны: Повстанцы", "Star Wars Rebels", "Star Wars", "звёздные войны: повстанцы", "star wars rebels"],
    type: "Сериал",
    year: "2014",
    rating: 8.1,
    genres: ["Анимация", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt2930604", title: "Звёздные войны: Повстанцы", originalTitle: "Star Wars Rebels", year: "2014", type: "Сериал" }),
    description: "Команда повстанцев начинает борьбу против Империи до событий «Новой надежды».",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Повстанцы» — сериал 2014 года из подборки «Star Wars». Команда повстанцев начинает борьбу против Империи до событий «Новой надежды». Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Анимация, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt2930604" },
    ],
  },
  {
    id: 320,
    imdbId: "tt12708542",
    slug: "star-wars-the-bad-batch",
    title: "Звёздные войны: Бракованная партия",
    originalTitle: "Star Wars: The Bad Batch",
    searchTitles: ["Звёздные войны: Бракованная партия", "Star Wars: The Bad Batch", "Star Wars", "звёздные войны: бракованная партия", "star wars: the bad batch"],
    type: "Сериал",
    year: "2021",
    rating: 7.8,
    genres: ["Анимация", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt12708542", title: "Звёздные войны: Бракованная партия", originalTitle: "Star Wars: The Bad Batch", year: "2021", type: "Сериал" }),
    description: "Отряд необычных клонов выживает в период после падения Республики.",
    trailerUrl: "",
    longDescription: "«Звёздные войны: Бракованная партия» — сериал 2021 года из подборки «Star Wars». Отряд необычных клонов выживает в период после падения Республики. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Star Wars" },
      { label: "Жанры", value: "Анимация, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt12708542" },
    ],
  },
  {
    id: 321,
    tmdbId: 329,
    imdbId: "tt0107290",
    slug: "jurassic-park",
    title: "Парк Юрского периода",
    originalTitle: "Jurassic Park",
    searchTitles: ["Парк Юрского периода", "Jurassic Park", "Jurassic", "парк юрского периода", "jurassic park"],
    type: "Фильм",
    year: "1993",
    rating: 8.2,
    genres: ["Фантастика", "Приключения", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 329, imdbId: "tt0107290", title: "Парк Юрского периода", originalTitle: "Jurassic Park", year: "1993", type: "Фильм" }),
    description: "Посетители островного парка сталкиваются с динозаврами, когда технология выходит из-под контроля.",
    trailerUrl: "",
    longDescription: "«Парк Юрского периода» — фильм 1993 года из подборки «Jurassic». Посетители островного парка сталкиваются с динозаврами, когда технология выходит из-под контроля. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1993" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Jurassic" },
      { label: "Жанры", value: "Фантастика, Приключения, Триллер" },
      { label: "Внутренний номер", value: "tt0107290" },
    ],
  },
  {
    id: 322,
    tmdbId: 330,
    imdbId: "tt0119567",
    slug: "the-lost-world-jurassic-park",
    title: "Парк Юрского периода 2: Затерянный мир",
    originalTitle: "The Lost World: Jurassic Park",
    searchTitles: ["Парк Юрского периода 2: Затерянный мир", "The Lost World: Jurassic Park", "Jurassic", "парк юрского периода 2: затерянный мир", "the lost world: jurassic park"],
    type: "Фильм",
    year: "1997",
    rating: 6.6,
    genres: ["Фантастика", "Приключения", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 330, imdbId: "tt0119567", title: "Парк Юрского периода 2: Затерянный мир", originalTitle: "The Lost World: Jurassic Park", year: "1997", type: "Фильм" }),
    description: "Экспедиция возвращается к динозаврам на другом острове, где опасность оказалась ещё ближе.",
    trailerUrl: "",
    longDescription: "«Парк Юрского периода 2: Затерянный мир» — фильм 1997 года из подборки «Jurassic». Экспедиция возвращается к динозаврам на другом острове, где опасность оказалась ещё ближе. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1997" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Jurassic" },
      { label: "Жанры", value: "Фантастика, Приключения, Триллер" },
      { label: "Внутренний номер", value: "tt0119567" },
    ],
  },
  {
    id: 323,
    tmdbId: 331,
    imdbId: "tt0163025",
    slug: "jurassic-park-iii",
    title: "Парк Юрского периода 3",
    originalTitle: "Jurassic Park III",
    searchTitles: ["Парк Юрского периода 3", "Jurassic Park III", "Jurassic", "парк юрского периода 3", "jurassic park iii"],
    type: "Фильм",
    year: "2001",
    rating: 5.9,
    genres: ["Фантастика", "Приключения", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 331, imdbId: "tt0163025", title: "Парк Юрского периода 3", originalTitle: "Jurassic Park III", year: "2001", type: "Фильм" }),
    description: "Алан Грант снова оказывается среди динозавров после опасной спасательной миссии.",
    trailerUrl: "",
    longDescription: "«Парк Юрского периода 3» — фильм 2001 года из подборки «Jurassic». Алан Грант снова оказывается среди динозавров после опасной спасательной миссии. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2001" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Jurassic" },
      { label: "Жанры", value: "Фантастика, Приключения, Триллер" },
      { label: "Внутренний номер", value: "tt0163025" },
    ],
  },
  {
    id: 324,
    tmdbId: 135397,
    imdbId: "tt0369610",
    slug: "jurassic-world",
    title: "Мир Юрского периода",
    originalTitle: "Jurassic World",
    searchTitles: ["Мир Юрского периода", "Jurassic World", "Jurassic", "мир юрского периода", "jurassic world"],
    type: "Фильм",
    year: "2015",
    rating: 6.9,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 135397, imdbId: "tt0369610", title: "Мир Юрского периода", originalTitle: "Jurassic World", year: "2015", type: "Фильм" }),
    description: "Новый парк динозавров открыт для публики, но экспериментальный хищник меняет всё.",
    trailerUrl: "",
    longDescription: "«Мир Юрского периода» — фильм 2015 года из подборки «Jurassic». Новый парк динозавров открыт для публики, но экспериментальный хищник меняет всё. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Jurassic" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0369610" },
    ],
  },
  {
    id: 325,
    tmdbId: 351286,
    imdbId: "tt4881806",
    slug: "jurassic-world-fallen-kingdom",
    title: "Мир Юрского периода 2",
    originalTitle: "Jurassic World: Fallen Kingdom",
    searchTitles: ["Мир Юрского периода 2", "Jurassic World: Fallen Kingdom", "Jurassic", "мир юрского периода 2", "jurassic world: fallen kingdom"],
    type: "Фильм",
    year: "2018",
    rating: 6.1,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 351286, imdbId: "tt4881806", title: "Мир Юрского периода 2", originalTitle: "Jurassic World: Fallen Kingdom", year: "2018", type: "Фильм" }),
    description: "Герои возвращаются на остров, чтобы спасти динозавров от новой катастрофы.",
    trailerUrl: "",
    longDescription: "«Мир Юрского периода 2» — фильм 2018 года из подборки «Jurassic». Герои возвращаются на остров, чтобы спасти динозавров от новой катастрофы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Jurassic" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt4881806" },
    ],
  },
  {
    id: 326,
    tmdbId: 507086,
    imdbId: "tt8041270",
    slug: "jurassic-world-dominion",
    title: "Мир Юрского периода: Господство",
    originalTitle: "Jurassic World Dominion",
    searchTitles: ["Мир Юрского периода: Господство", "Jurassic World Dominion", "Jurassic", "мир юрского периода: господство", "jurassic world dominion"],
    type: "Фильм",
    year: "2022",
    rating: 5.6,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 507086, imdbId: "tt8041270", title: "Мир Юрского периода: Господство", originalTitle: "Jurassic World Dominion", year: "2022", type: "Фильм" }),
    description: "Люди и динозавры пытаются существовать в одном мире после событий предыдущих фильмов.",
    trailerUrl: "",
    longDescription: "«Мир Юрского периода: Господство» — фильм 2022 года из подборки «Jurassic». Люди и динозавры пытаются существовать в одном мире после событий предыдущих фильмов. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Jurassic" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt8041270" },
    ],
  },
  {
    id: 327,
    imdbId: "tt31036941",
    slug: "jurassic-world-rebirth",
    title: "Мир Юрского периода: Возрождение",
    originalTitle: "Jurassic World Rebirth",
    searchTitles: ["Мир Юрского периода: Возрождение", "Jurassic World Rebirth", "Jurassic", "мир юрского периода: возрождение", "jurassic world rebirth"],
    type: "Фильм",
    year: "2025",
    rating: 0.0,
    genres: ["Фантастика", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt31036941", title: "Мир Юрского периода: Возрождение", originalTitle: "Jurassic World Rebirth", year: "2025", type: "Фильм" }),
    description: "Новая глава франшизы о динозаврах и опасной экспедиции в мир, где природа сильнее контроля.",
    trailerUrl: "",
    longDescription: "«Мир Юрского периода: Возрождение» — фильм 2025 года из подборки «Jurassic». Новая глава франшизы о динозаврах и опасной экспедиции в мир, где природа сильнее контроля. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2025" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Jurassic" },
      { label: "Жанры", value: "Фантастика, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt31036941" },
    ],
  },
  {
    id: 328,
    tmdbId: 9799,
    imdbId: "tt0232500",
    slug: "the-fast-and-the-furious",
    title: "Форсаж",
    originalTitle: "The Fast and the Furious",
    searchTitles: ["Форсаж", "The Fast and the Furious", "Fast & Furious", "форсаж", "the fast and the furious"],
    type: "Фильм",
    year: "2001",
    rating: 6.8,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 9799, imdbId: "tt0232500", title: "Форсаж", originalTitle: "The Fast and the Furious", year: "2001", type: "Фильм" }),
    description: "Полицейский под прикрытием погружается в мир уличных гонок и быстрых решений.",
    trailerUrl: "",
    longDescription: "«Форсаж» — фильм 2001 года из подборки «Fast & Furious». Полицейский под прикрытием погружается в мир уличных гонок и быстрых решений. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2001" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt0232500" },
    ],
  },
  {
    id: 329,
    tmdbId: 584,
    imdbId: "tt0322259",
    slug: "2-fast-2-furious",
    title: "Двойной форсаж",
    originalTitle: "2 Fast 2 Furious",
    searchTitles: ["Двойной форсаж", "2 Fast 2 Furious", "Fast & Furious", "двойной форсаж", "2 fast 2 furious"],
    type: "Фильм",
    year: "2003",
    rating: 5.9,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 584, imdbId: "tt0322259", title: "Двойной форсаж", originalTitle: "2 Fast 2 Furious", year: "2003", type: "Фильм" }),
    description: "Брайан О’Коннер получает новое дело, где скорость и доверие снова идут рядом.",
    trailerUrl: "",
    longDescription: "«Двойной форсаж» — фильм 2003 года из подборки «Fast & Furious». Брайан О’Коннер получает новое дело, где скорость и доверие снова идут рядом. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt0322259" },
    ],
  },
  {
    id: 330,
    tmdbId: 9615,
    imdbId: "tt0463985",
    slug: "the-fast-and-the-furious-tokyo-drift",
    title: "Тройной форсаж: Токийский дрифт",
    originalTitle: "The Fast and the Furious: Tokyo Drift",
    searchTitles: ["Тройной форсаж: Токийский дрифт", "The Fast and the Furious: Tokyo Drift", "Fast & Furious", "тройной форсаж: токийский дрифт", "the fast and the furious: tokyo drift"],
    type: "Фильм",
    year: "2006",
    rating: 6.0,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 9615, imdbId: "tt0463985", title: "Тройной форсаж: Токийский дрифт", originalTitle: "The Fast and the Furious: Tokyo Drift", year: "2006", type: "Фильм" }),
    description: "История переносится в Токио и знакомит зрителей с культурой дрифта.",
    trailerUrl: "",
    longDescription: "«Тройной форсаж: Токийский дрифт» — фильм 2006 года из подборки «Fast & Furious». История переносится в Токио и знакомит зрителей с культурой дрифта. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2006" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt0463985" },
    ],
  },
  {
    id: 331,
    tmdbId: 13804,
    imdbId: "tt1013752",
    slug: "fast-and-furious",
    title: "Форсаж 4",
    originalTitle: "Fast & Furious",
    searchTitles: ["Форсаж 4", "Fast & Furious", "форсаж 4", "fast & furious"],
    type: "Фильм",
    year: "2009",
    rating: 6.5,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 13804, imdbId: "tt1013752", title: "Форсаж 4", originalTitle: "Fast & Furious", year: "2009", type: "Фильм" }),
    description: "Доминик Торетто и Брайан снова оказываются по разные стороны закона и одной дороги.",
    trailerUrl: "",
    longDescription: "«Форсаж 4» — фильм 2009 года из подборки «Fast & Furious». Доминик Торетто и Брайан снова оказываются по разные стороны закона и одной дороги. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2009" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt1013752" },
    ],
  },
  {
    id: 332,
    tmdbId: 51497,
    imdbId: "tt1596343",
    slug: "fast-five",
    title: "Форсаж 5",
    originalTitle: "Fast Five",
    searchTitles: ["Форсаж 5", "Fast Five", "Fast & Furious", "форсаж 5", "fast five"],
    type: "Фильм",
    year: "2011",
    rating: 7.3,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 51497, imdbId: "tt1596343", title: "Форсаж 5", originalTitle: "Fast Five", year: "2011", type: "Фильм" }),
    description: "Команда собирается для крупного ограбления в Рио и меняет масштаб серии.",
    trailerUrl: "",
    longDescription: "«Форсаж 5» — фильм 2011 года из подборки «Fast & Furious». Команда собирается для крупного ограбления в Рио и меняет масштаб серии. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt1596343" },
    ],
  },
  {
    id: 333,
    tmdbId: 82992,
    imdbId: "tt1905041",
    slug: "fast-and-furious-6",
    title: "Форсаж 6",
    originalTitle: "Fast & Furious 6",
    searchTitles: ["Форсаж 6", "Fast & Furious 6", "Fast & Furious", "форсаж 6", "fast & furious 6"],
    type: "Фильм",
    year: "2013",
    rating: 7.0,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 82992, imdbId: "tt1905041", title: "Форсаж 6", originalTitle: "Fast & Furious 6", year: "2013", type: "Фильм" }),
    description: "Доминик и команда получают шанс вернуть близкого человека и остановить опасных наёмников.",
    trailerUrl: "",
    longDescription: "«Форсаж 6» — фильм 2013 года из подборки «Fast & Furious». Доминик и команда получают шанс вернуть близкого человека и остановить опасных наёмников. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt1905041" },
    ],
  },
  {
    id: 334,
    tmdbId: 168259,
    imdbId: "tt2820852",
    slug: "furious-7",
    title: "Форсаж 7",
    originalTitle: "Furious 7",
    searchTitles: ["Форсаж 7", "Furious 7", "Fast & Furious", "форсаж 7", "furious 7"],
    type: "Фильм",
    year: "2015",
    rating: 7.1,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 168259, imdbId: "tt2820852", title: "Форсаж 7", originalTitle: "Furious 7", year: "2015", type: "Фильм" }),
    description: "Команда сталкивается с местью Декарда Шоу и прощается с важной частью семьи.",
    trailerUrl: "",
    longDescription: "«Форсаж 7» — фильм 2015 года из подборки «Fast & Furious». Команда сталкивается с местью Декарда Шоу и прощается с важной частью семьи. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt2820852" },
    ],
  },
  {
    id: 335,
    tmdbId: 337339,
    imdbId: "tt4630562",
    slug: "the-fate-of-the-furious",
    title: "Форсаж 8",
    originalTitle: "The Fate of the Furious",
    searchTitles: ["Форсаж 8", "The Fate of the Furious", "Fast & Furious", "форсаж 8", "the fate of the furious"],
    type: "Фильм",
    year: "2017",
    rating: 6.6,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 337339, imdbId: "tt4630562", title: "Форсаж 8", originalTitle: "The Fate of the Furious", year: "2017", type: "Фильм" }),
    description: "Доминик неожиданно оказывается против своей команды, и семье приходится искать правду.",
    trailerUrl: "",
    longDescription: "«Форсаж 8» — фильм 2017 года из подборки «Fast & Furious». Доминик неожиданно оказывается против своей команды, и семье приходится искать правду. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt4630562" },
    ],
  },
  {
    id: 336,
    tmdbId: 384018,
    imdbId: "tt6806448",
    slug: "fast-and-furious-presents-hobbs-and-shaw",
    title: "Форсаж: Хоббс и Шоу",
    originalTitle: "Fast & Furious Presents: Hobbs & Shaw",
    searchTitles: ["Форсаж: Хоббс и Шоу", "Fast & Furious Presents: Hobbs & Shaw", "Fast & Furious", "форсаж: хоббс и шоу", "fast & furious presents: hobbs & shaw"],
    type: "Фильм",
    year: "2019",
    rating: 6.5,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 384018, imdbId: "tt6806448", title: "Форсаж: Хоббс и Шоу", originalTitle: "Fast & Furious Presents: Hobbs & Shaw", year: "2019", type: "Фильм" }),
    description: "Хоббс и Шоу вынуждены работать вместе против технологически усиленного врага.",
    trailerUrl: "",
    longDescription: "«Форсаж: Хоббс и Шоу» — фильм 2019 года из подборки «Fast & Furious». Хоббс и Шоу вынуждены работать вместе против технологически усиленного врага. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt6806448" },
    ],
  },
  {
    id: 337,
    tmdbId: 385128,
    imdbId: "tt5433138",
    slug: "f9",
    title: "Форсаж 9",
    originalTitle: "F9",
    searchTitles: ["Форсаж 9", "F9", "Fast & Furious", "форсаж 9", "f9"],
    type: "Фильм",
    year: "2021",
    rating: 5.2,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 385128, imdbId: "tt5433138", title: "Форсаж 9", originalTitle: "F9", year: "2021", type: "Фильм" }),
    description: "Семейное прошлое Доминика возвращается на скорости, привычной для франшизы.",
    trailerUrl: "",
    longDescription: "«Форсаж 9» — фильм 2021 года из подборки «Fast & Furious». Семейное прошлое Доминика возвращается на скорости, привычной для франшизы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt5433138" },
    ],
  },
  {
    id: 338,
    tmdbId: 385687,
    imdbId: "tt5433140",
    slug: "fast-x",
    title: "Форсаж 10",
    originalTitle: "Fast X",
    searchTitles: ["Форсаж 10", "Fast X", "Fast & Furious", "форсаж 10", "fast x"],
    type: "Фильм",
    year: "2023",
    rating: 5.8,
    genres: ["Боевик", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 385687, imdbId: "tt5433140", title: "Форсаж 10", originalTitle: "Fast X", year: "2023", type: "Фильм" }),
    description: "Команда сталкивается с противником, который превращает прошлые победы в новую угрозу.",
    trailerUrl: "",
    longDescription: "«Форсаж 10» — фильм 2023 года из подборки «Fast & Furious». Команда сталкивается с противником, который превращает прошлые победы в новую угрозу. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Fast & Furious" },
      { label: "Жанры", value: "Боевик, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt5433140" },
    ],
  },
  {
    id: 339,
    tmdbId: 1858,
    imdbId: "tt0418279",
    slug: "transformers",
    title: "Трансформеры",
    originalTitle: "Transformers",
    searchTitles: ["Трансформеры", "Transformers", "трансформеры", "transformers"],
    type: "Фильм",
    year: "2007",
    rating: 7.0,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1858, imdbId: "tt0418279", title: "Трансформеры", originalTitle: "Transformers", year: "2007", type: "Фильм" }),
    description: "Сэм Уитвики оказывается в центре войны автоботов и десептиконов на Земле.",
    trailerUrl: "",
    longDescription: "«Трансформеры» — фильм 2007 года из подборки «Transformers». Сэм Уитвики оказывается в центре войны автоботов и десептиконов на Земле. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2007" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Transformers" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt0418279" },
    ],
  },
  {
    id: 340,
    tmdbId: 8373,
    imdbId: "tt1055369",
    slug: "transformers-revenge-of-the-fallen",
    title: "Трансформеры: Месть падших",
    originalTitle: "Transformers: Revenge of the Fallen",
    searchTitles: ["Трансформеры: Месть падших", "Transformers: Revenge of the Fallen", "Transformers", "трансформеры: месть падших", "transformers: revenge of the fallen"],
    type: "Фильм",
    year: "2009",
    rating: 6.0,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 8373, imdbId: "tt1055369", title: "Трансформеры: Месть падших", originalTitle: "Transformers: Revenge of the Fallen", year: "2009", type: "Фильм" }),
    description: "Автоботы снова защищают Землю от древней угрозы десептиконов.",
    trailerUrl: "",
    longDescription: "«Трансформеры: Месть падших» — фильм 2009 года из подборки «Transformers». Автоботы снова защищают Землю от древней угрозы десептиконов. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2009" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Transformers" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt1055369" },
    ],
  },
  {
    id: 341,
    tmdbId: 38356,
    imdbId: "tt1399103",
    slug: "transformers-dark-of-the-moon",
    title: "Трансформеры 3: Тёмная сторона Луны",
    originalTitle: "Transformers: Dark of the Moon",
    searchTitles: ["Трансформеры 3: Тёмная сторона Луны", "Transformers: Dark of the Moon", "Transformers", "трансформеры 3: тёмная сторона луны", "transformers: dark of the moon"],
    type: "Фильм",
    year: "2011",
    rating: 6.2,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 38356, imdbId: "tt1399103", title: "Трансформеры 3: Тёмная сторона Луны", originalTitle: "Transformers: Dark of the Moon", year: "2011", type: "Фильм" }),
    description: "История войны роботов связывается с тайнами лунной миссии.",
    trailerUrl: "",
    longDescription: "«Трансформеры 3: Тёмная сторона Луны» — фильм 2011 года из подборки «Transformers». История войны роботов связывается с тайнами лунной миссии. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Transformers" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt1399103" },
    ],
  },
  {
    id: 342,
    tmdbId: 91314,
    imdbId: "tt2109248",
    slug: "transformers-age-of-extinction",
    title: "Трансформеры: Эпоха истребления",
    originalTitle: "Transformers: Age of Extinction",
    searchTitles: ["Трансформеры: Эпоха истребления", "Transformers: Age of Extinction", "Transformers", "трансформеры: эпоха истребления", "transformers: age of extinction"],
    type: "Фильм",
    year: "2014",
    rating: 5.6,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 91314, imdbId: "tt2109248", title: "Трансформеры: Эпоха истребления", originalTitle: "Transformers: Age of Extinction", year: "2014", type: "Фильм" }),
    description: "Люди пытаются контролировать технологии трансформеров, но получают новые проблемы.",
    trailerUrl: "",
    longDescription: "«Трансформеры: Эпоха истребления» — фильм 2014 года из подборки «Transformers». Люди пытаются контролировать технологии трансформеров, но получают новые проблемы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Transformers" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt2109248" },
    ],
  },
  {
    id: 343,
    tmdbId: 335988,
    imdbId: "tt3371366",
    slug: "transformers-the-last-knight",
    title: "Трансформеры: Последний рыцарь",
    originalTitle: "Transformers: The Last Knight",
    searchTitles: ["Трансформеры: Последний рыцарь", "Transformers: The Last Knight", "Transformers", "трансформеры: последний рыцарь", "transformers: the last knight"],
    type: "Фильм",
    year: "2017",
    rating: 5.2,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 335988, imdbId: "tt3371366", title: "Трансформеры: Последний рыцарь", originalTitle: "Transformers: The Last Knight", year: "2017", type: "Фильм" }),
    description: "Прошлое трансформеров связывается с легендами Земли и новой угрозой.",
    trailerUrl: "",
    longDescription: "«Трансформеры: Последний рыцарь» — фильм 2017 года из подборки «Transformers». Прошлое трансформеров связывается с легендами Земли и новой угрозой. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Transformers" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt3371366" },
    ],
  },
  {
    id: 344,
    tmdbId: 424783,
    imdbId: "tt4701182",
    slug: "bumblebee",
    title: "Бамблби",
    originalTitle: "Bumblebee",
    searchTitles: ["Бамблби", "Bumblebee", "Transformers", "бамблби", "bumblebee"],
    type: "Фильм",
    year: "2018",
    rating: 6.7,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 424783, imdbId: "tt4701182", title: "Бамблби", originalTitle: "Bumblebee", year: "2018", type: "Фильм" }),
    description: "Бамблби находит убежище у девушки Чарли и раскрывается как самый тёплый герой франшизы.",
    trailerUrl: "",
    longDescription: "«Бамблби» — фильм 2018 года из подборки «Transformers». Бамблби находит убежище у девушки Чарли и раскрывается как самый тёплый герой франшизы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Transformers" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt4701182" },
    ],
  },
  {
    id: 345,
    tmdbId: 667538,
    imdbId: "tt5090568",
    slug: "transformers-rise-of-the-beasts",
    title: "Трансформеры: Восхождение Звероботов",
    originalTitle: "Transformers: Rise of the Beasts",
    searchTitles: ["Трансформеры: Восхождение Звероботов", "Transformers: Rise of the Beasts", "Transformers", "трансформеры: восхождение звероботов", "transformers: rise of the beasts"],
    type: "Фильм",
    year: "2023",
    rating: 6.0,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 667538, imdbId: "tt5090568", title: "Трансформеры: Восхождение Звероботов", originalTitle: "Transformers: Rise of the Beasts", year: "2023", type: "Фильм" }),
    description: "Автоботы встречают Максималов в приключении, связанном с новой космической опасностью.",
    trailerUrl: "",
    longDescription: "«Трансформеры: Восхождение Звероботов» — фильм 2023 года из подборки «Transformers». Автоботы встречают Максималов в приключении, связанном с новой космической опасностью. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Transformers" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt5090568" },
    ],
  },
  {
    id: 346,
    tmdbId: 698687,
    imdbId: "tt8864596",
    slug: "transformers-one",
    title: "Трансформеры: Начало",
    originalTitle: "Transformers One",
    searchTitles: ["Трансформеры: Начало", "Transformers One", "Transformers", "трансформеры: начало", "transformers one"],
    type: "Мультфильм",
    year: "2024",
    rating: 7.6,
    genres: ["Анимация", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 698687, imdbId: "tt8864596", title: "Трансформеры: Начало", originalTitle: "Transformers One", year: "2024", type: "Мультфильм" }),
    description: "Анимационная история о прошлом Оптимуса Прайма и Мегатрона до большой войны.",
    trailerUrl: "",
    longDescription: "«Трансформеры: Начало» — мультфильм 2024 года из подборки «Transformers». Анимационная история о прошлом Оптимуса Прайма и Мегатрона до большой войны. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Transformers" },
      { label: "Жанры", value: "Анимация, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt8864596" },
    ],
  },
  {
    id: 347,
    tmdbId: 604,
    imdbId: "tt0234215",
    slug: "the-matrix-reloaded",
    title: "Матрица: Перезагрузка",
    originalTitle: "The Matrix Reloaded",
    searchTitles: ["Матрица: Перезагрузка", "The Matrix Reloaded", "The Matrix", "матрица: перезагрузка", "the matrix reloaded"],
    type: "Фильм",
    year: "2003",
    rating: 7.2,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 604, imdbId: "tt0234215", title: "Матрица: Перезагрузка", originalTitle: "The Matrix Reloaded", year: "2003", type: "Фильм" }),
    description: "Нео и союзники продолжают борьбу с машинами и раскрывают новые правила Матрицы.",
    trailerUrl: "",
    longDescription: "«Матрица: Перезагрузка» — фильм 2003 года из подборки «The Matrix». Нео и союзники продолжают борьбу с машинами и раскрывают новые правила Матрицы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Matrix" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt0234215" },
    ],
  },
  {
    id: 348,
    tmdbId: 605,
    imdbId: "tt0242653",
    slug: "the-matrix-revolutions",
    title: "Матрица: Революция",
    originalTitle: "The Matrix Revolutions",
    searchTitles: ["Матрица: Революция", "The Matrix Revolutions", "The Matrix", "матрица: революция", "the matrix revolutions"],
    type: "Фильм",
    year: "2003",
    rating: 6.7,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 605, imdbId: "tt0242653", title: "Матрица: Революция", originalTitle: "The Matrix Revolutions", year: "2003", type: "Фильм" }),
    description: "Финал оригинальной трилогии о войне людей и машин.",
    trailerUrl: "",
    longDescription: "«Матрица: Революция» — фильм 2003 года из подборки «The Matrix». Финал оригинальной трилогии о войне людей и машин. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Matrix" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt0242653" },
    ],
  },
  {
    id: 349,
    tmdbId: 624860,
    imdbId: "tt10838180",
    slug: "the-matrix-resurrections",
    title: "Матрица: Воскрешение",
    originalTitle: "The Matrix Resurrections",
    searchTitles: ["Матрица: Воскрешение", "The Matrix Resurrections", "The Matrix", "матрица: воскрешение", "the matrix resurrections"],
    type: "Фильм",
    year: "2021",
    rating: 5.7,
    genres: ["Фантастика", "Боевик", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 624860, imdbId: "tt10838180", title: "Матрица: Воскрешение", originalTitle: "The Matrix Resurrections", year: "2021", type: "Фильм" }),
    description: "Нео возвращается в новую версию мира, где знакомые вопросы снова становятся личными.",
    trailerUrl: "",
    longDescription: "«Матрица: Воскрешение» — фильм 2021 года из подборки «The Matrix». Нео возвращается в новую версию мира, где знакомые вопросы снова становятся личными. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Matrix" },
      { label: "Жанры", value: "Фантастика, Боевик, Приключения" },
      { label: "Внутренний номер", value: "tt10838180" },
    ],
  },
  {
    id: 350,
    tmdbId: 245891,
    imdbId: "tt2911666",
    slug: "john-wick",
    title: "Джон Уик",
    originalTitle: "John Wick",
    searchTitles: ["Джон Уик", "John Wick", "джон уик", "john wick"],
    type: "Фильм",
    year: "2014",
    rating: 7.4,
    genres: ["Боевик", "Криминал", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 245891, imdbId: "tt2911666", title: "Джон Уик", originalTitle: "John Wick", year: "2014", type: "Фильм" }),
    description: "Бывший киллер возвращается к старому миру после личной потери.",
    trailerUrl: "",
    longDescription: "«Джон Уик» — фильм 2014 года из подборки «John Wick». Бывший киллер возвращается к старому миру после личной потери. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "John Wick" },
      { label: "Жанры", value: "Боевик, Криминал, Приключения" },
      { label: "Внутренний номер", value: "tt2911666" },
    ],
  },
  {
    id: 351,
    tmdbId: 324552,
    imdbId: "tt4425200",
    slug: "john-wick-chapter-2",
    title: "Джон Уик 2",
    originalTitle: "John Wick: Chapter 2",
    searchTitles: ["Джон Уик 2", "John Wick: Chapter 2", "John Wick", "джон уик 2", "john wick: chapter 2"],
    type: "Фильм",
    year: "2017",
    rating: 7.4,
    genres: ["Боевик", "Криминал", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 324552, imdbId: "tt4425200", title: "Джон Уик 2", originalTitle: "John Wick: Chapter 2", year: "2017", type: "Фильм" }),
    description: "Джон Уик вынужден выполнить старый долг и снова входит в мир ассасинов.",
    trailerUrl: "",
    longDescription: "«Джон Уик 2» — фильм 2017 года из подборки «John Wick». Джон Уик вынужден выполнить старый долг и снова входит в мир ассасинов. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "John Wick" },
      { label: "Жанры", value: "Боевик, Криминал, Приключения" },
      { label: "Внутренний номер", value: "tt4425200" },
    ],
  },
  {
    id: 352,
    tmdbId: 458156,
    imdbId: "tt6146586",
    slug: "john-wick-chapter-3-parabellum",
    title: "Джон Уик 3",
    originalTitle: "John Wick: Chapter 3 - Parabellum",
    searchTitles: ["Джон Уик 3", "John Wick: Chapter 3 - Parabellum", "John Wick", "джон уик 3", "john wick: chapter 3 - parabellum"],
    type: "Фильм",
    year: "2019",
    rating: 7.4,
    genres: ["Боевик", "Криминал", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 458156, imdbId: "tt6146586", title: "Джон Уик 3", originalTitle: "John Wick: Chapter 3 - Parabellum", year: "2019", type: "Фильм" }),
    description: "Джон оказывается целью для всего преступного мира после нарушения правил.",
    trailerUrl: "",
    longDescription: "«Джон Уик 3» — фильм 2019 года из подборки «John Wick». Джон оказывается целью для всего преступного мира после нарушения правил. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "John Wick" },
      { label: "Жанры", value: "Боевик, Криминал, Приключения" },
      { label: "Внутренний номер", value: "tt6146586" },
    ],
  },
  {
    id: 353,
    tmdbId: 541671,
    imdbId: "tt7181546",
    slug: "ballerina",
    title: "Балерина",
    originalTitle: "Ballerina",
    searchTitles: ["Балерина", "Ballerina", "John Wick", "балерина", "ballerina"],
    type: "Фильм",
    year: "2025",
    rating: 6.8,
    genres: ["Боевик", "Криминал", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 541671, imdbId: "tt7181546", title: "Балерина", originalTitle: "Ballerina", year: "2025", type: "Фильм" }),
    description: "Спин-офф мира Джона Уика о героине, ищущей ответы и справедливость.",
    trailerUrl: "",
    longDescription: "«Балерина» — фильм 2025 года из подборки «John Wick». Спин-офф мира Джона Уика о героине, ищущей ответы и справедливость. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2025" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "John Wick" },
      { label: "Жанры", value: "Боевик, Криминал, Приключения" },
      { label: "Внутренний номер", value: "tt7181546" },
    ],
  },
  {
    id: 354,
    tmdbId: 70160,
    imdbId: "tt1392170",
    slug: "the-hunger-games",
    title: "Голодные игры",
    originalTitle: "The Hunger Games",
    searchTitles: ["Голодные игры", "The Hunger Games", "голодные игры", "the hunger games"],
    type: "Фильм",
    year: "2012",
    rating: 7.2,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 70160, imdbId: "tt1392170", title: "Голодные игры", originalTitle: "The Hunger Games", year: "2012", type: "Фильм" }),
    description: "Китнисс Эвердин становится участницей жестокого соревнования и символом сопротивления.",
    trailerUrl: "",
    longDescription: "«Голодные игры» — фильм 2012 года из подборки «The Hunger Games». Китнисс Эвердин становится участницей жестокого соревнования и символом сопротивления. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Hunger Games" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
      { label: "Внутренний номер", value: "tt1392170" },
    ],
  },
  {
    id: 355,
    tmdbId: 101299,
    imdbId: "tt1951264",
    slug: "the-hunger-games-catching-fire",
    title: "Голодные игры: И вспыхнет пламя",
    originalTitle: "The Hunger Games: Catching Fire",
    searchTitles: ["Голодные игры: И вспыхнет пламя", "The Hunger Games: Catching Fire", "The Hunger Games", "голодные игры: и вспыхнет пламя", "the hunger games: catching fire"],
    type: "Фильм",
    year: "2013",
    rating: 7.5,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 101299, imdbId: "tt1951264", title: "Голодные игры: И вспыхнет пламя", originalTitle: "The Hunger Games: Catching Fire", year: "2013", type: "Фильм" }),
    description: "Победа Китнисс приводит к новым испытаниям и росту сопротивления.",
    trailerUrl: "",
    longDescription: "«Голодные игры: И вспыхнет пламя» — фильм 2013 года из подборки «The Hunger Games». Победа Китнисс приводит к новым испытаниям и росту сопротивления. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Hunger Games" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
      { label: "Внутренний номер", value: "tt1951264" },
    ],
  },
  {
    id: 356,
    tmdbId: 131631,
    imdbId: "tt1951265",
    slug: "the-hunger-games-mockingjay-part-1",
    title: "Голодные игры: Сойка-пересмешница. Часть I",
    originalTitle: "The Hunger Games: Mockingjay - Part 1",
    searchTitles: ["Голодные игры: Сойка-пересмешница. Часть I", "The Hunger Games: Mockingjay - Part 1", "The Hunger Games", "голодные игры: сойка-пересмешница. часть i", "the hunger games: mockingjay - part 1"],
    type: "Фильм",
    year: "2014",
    rating: 6.6,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 131631, imdbId: "tt1951265", title: "Голодные игры: Сойка-пересмешница. Часть I", originalTitle: "The Hunger Games: Mockingjay - Part 1", year: "2014", type: "Фильм" }),
    description: "Китнисс становится лицом восстания против Капитолия.",
    trailerUrl: "",
    longDescription: "«Голодные игры: Сойка-пересмешница. Часть I» — фильм 2014 года из подборки «The Hunger Games». Китнисс становится лицом восстания против Капитолия. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Hunger Games" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
      { label: "Внутренний номер", value: "tt1951265" },
    ],
  },
  {
    id: 357,
    tmdbId: 131634,
    imdbId: "tt1951266",
    slug: "the-hunger-games-mockingjay-part-2",
    title: "Голодные игры: Сойка-пересмешница. Часть II",
    originalTitle: "The Hunger Games: Mockingjay - Part 2",
    searchTitles: ["Голодные игры: Сойка-пересмешница. Часть II", "The Hunger Games: Mockingjay - Part 2", "The Hunger Games", "голодные игры: сойка-пересмешница. часть ii", "the hunger games: mockingjay - part 2"],
    type: "Фильм",
    year: "2015",
    rating: 6.5,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 131634, imdbId: "tt1951266", title: "Голодные игры: Сойка-пересмешница. Часть II", originalTitle: "The Hunger Games: Mockingjay - Part 2", year: "2015", type: "Фильм" }),
    description: "Финальная часть борьбы против Капитолия и личной цены революции.",
    trailerUrl: "",
    longDescription: "«Голодные игры: Сойка-пересмешница. Часть II» — фильм 2015 года из подборки «The Hunger Games». Финальная часть борьбы против Капитолия и личной цены революции. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Hunger Games" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
      { label: "Внутренний номер", value: "tt1951266" },
    ],
  },
  {
    id: 358,
    tmdbId: 695721,
    imdbId: "tt10545296",
    slug: "the-hunger-games-the-ballad-of-songbirds-and-snakes",
    title: "Голодные игры: Баллада о змеях и певчих птицах",
    originalTitle: "The Hunger Games: The Ballad of Songbirds & Snakes",
    searchTitles: ["Голодные игры: Баллада о змеях и певчих птицах", "The Hunger Games: The Ballad of Songbirds & Snakes", "The Hunger Games", "голодные игры: баллада о змеях и певчих птицах", "the hunger games: the ballad of songbirds & snakes"],
    type: "Фильм",
    year: "2023",
    rating: 6.7,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 695721, imdbId: "tt10545296", title: "Голодные игры: Баллада о змеях и певчих птицах", originalTitle: "The Hunger Games: The Ballad of Songbirds & Snakes", year: "2023", type: "Фильм" }),
    description: "Приквел о молодом Кориолане Сноу и ранней истории Голодных игр.",
    trailerUrl: "",
    longDescription: "«Голодные игры: Баллада о змеях и певчих птицах» — фильм 2023 года из подборки «The Hunger Games». Приквел о молодом Кориолане Сноу и ранней истории Голодных игр. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Hunger Games" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
      { label: "Внутренний номер", value: "tt10545296" },
    ],
  },
  {
    id: 359,
    tmdbId: 8966,
    imdbId: "tt1099212",
    slug: "twilight",
    title: "Сумерки",
    originalTitle: "Twilight",
    searchTitles: ["Сумерки", "Twilight", "сумерки", "twilight"],
    type: "Фильм",
    year: "2008",
    rating: 5.3,
    genres: ["Фэнтези", "Мелодрама", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 8966, imdbId: "tt1099212", title: "Сумерки", originalTitle: "Twilight", year: "2008", type: "Фильм" }),
    description: "Белла Свон переезжает в Форкс и знакомится с Эдвардом Калленом.",
    trailerUrl: "",
    longDescription: "«Сумерки» — фильм 2008 года из подборки «Twilight». Белла Свон переезжает в Форкс и знакомится с Эдвардом Калленом. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2008" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Twilight" },
      { label: "Жанры", value: "Фэнтези, Мелодрама, Драма" },
      { label: "Внутренний номер", value: "tt1099212" },
    ],
  },
  {
    id: 360,
    tmdbId: 18239,
    imdbId: "tt1259571",
    slug: "the-twilight-saga-new-moon",
    title: "Сумерки. Сага. Новолуние",
    originalTitle: "The Twilight Saga: New Moon",
    searchTitles: ["Сумерки. Сага. Новолуние", "The Twilight Saga: New Moon", "Twilight", "сумерки. сага. новолуние", "the twilight saga: new moon"],
    type: "Фильм",
    year: "2009",
    rating: 4.8,
    genres: ["Фэнтези", "Мелодрама", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 18239, imdbId: "tt1259571", title: "Сумерки. Сага. Новолуние", originalTitle: "The Twilight Saga: New Moon", year: "2009", type: "Фильм" }),
    description: "Белла переживает разрыв и оказывается ближе к тайнам оборотней.",
    trailerUrl: "",
    longDescription: "«Сумерки. Сага. Новолуние» — фильм 2009 года из подборки «Twilight». Белла переживает разрыв и оказывается ближе к тайнам оборотней. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2009" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Twilight" },
      { label: "Жанры", value: "Фэнтези, Мелодрама, Драма" },
      { label: "Внутренний номер", value: "tt1259571" },
    ],
  },
  {
    id: 361,
    tmdbId: 24021,
    imdbId: "tt1325004",
    slug: "the-twilight-saga-eclipse",
    title: "Сумерки. Сага. Затмение",
    originalTitle: "The Twilight Saga: Eclipse",
    searchTitles: ["Сумерки. Сага. Затмение", "The Twilight Saga: Eclipse", "Twilight", "сумерки. сага. затмение", "the twilight saga: eclipse"],
    type: "Фильм",
    year: "2010",
    rating: 5.1,
    genres: ["Фэнтези", "Мелодрама", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 24021, imdbId: "tt1325004", title: "Сумерки. Сага. Затмение", originalTitle: "The Twilight Saga: Eclipse", year: "2010", type: "Фильм" }),
    description: "Белла оказывается между выбором будущего и растущей угрозой.",
    trailerUrl: "",
    longDescription: "«Сумерки. Сага. Затмение» — фильм 2010 года из подборки «Twilight». Белла оказывается между выбором будущего и растущей угрозой. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Twilight" },
      { label: "Жанры", value: "Фэнтези, Мелодрама, Драма" },
      { label: "Внутренний номер", value: "tt1325004" },
    ],
  },
  {
    id: 362,
    tmdbId: 50619,
    imdbId: "tt1324999",
    slug: "the-twilight-saga-breaking-dawn-part-1",
    title: "Сумерки. Сага. Рассвет: Часть 1",
    originalTitle: "The Twilight Saga: Breaking Dawn - Part 1",
    searchTitles: ["Сумерки. Сага. Рассвет: Часть 1", "The Twilight Saga: Breaking Dawn - Part 1", "Twilight", "сумерки. сага. рассвет: часть 1", "the twilight saga: breaking dawn - part 1"],
    type: "Фильм",
    year: "2011",
    rating: 4.9,
    genres: ["Фэнтези", "Мелодрама", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 50619, imdbId: "tt1324999", title: "Сумерки. Сага. Рассвет: Часть 1", originalTitle: "The Twilight Saga: Breaking Dawn - Part 1", year: "2011", type: "Фильм" }),
    description: "Белла и Эдвард принимают решение, которое меняет их жизнь.",
    trailerUrl: "",
    longDescription: "«Сумерки. Сага. Рассвет: Часть 1» — фильм 2011 года из подборки «Twilight». Белла и Эдвард принимают решение, которое меняет их жизнь. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Twilight" },
      { label: "Жанры", value: "Фэнтези, Мелодрама, Драма" },
      { label: "Внутренний номер", value: "tt1324999" },
    ],
  },
  {
    id: 363,
    tmdbId: 50620,
    imdbId: "tt1673434",
    slug: "the-twilight-saga-breaking-dawn-part-2",
    title: "Сумерки. Сага. Рассвет: Часть 2",
    originalTitle: "The Twilight Saga: Breaking Dawn - Part 2",
    searchTitles: ["Сумерки. Сага. Рассвет: Часть 2", "The Twilight Saga: Breaking Dawn - Part 2", "Twilight", "сумерки. сага. рассвет: часть 2", "the twilight saga: breaking dawn - part 2"],
    type: "Фильм",
    year: "2012",
    rating: 5.5,
    genres: ["Фэнтези", "Мелодрама", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 50620, imdbId: "tt1673434", title: "Сумерки. Сага. Рассвет: Часть 2", originalTitle: "The Twilight Saga: Breaking Dawn - Part 2", year: "2012", type: "Фильм" }),
    description: "Финал саги о семье Калленов и новой угрозе со стороны Вольтури.",
    trailerUrl: "",
    longDescription: "«Сумерки. Сага. Рассвет: Часть 2» — фильм 2012 года из подборки «Twilight». Финал саги о семье Калленов и новой угрозе со стороны Вольтури. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "Twilight" },
      { label: "Жанры", value: "Фэнтези, Мелодрама, Драма" },
      { label: "Внутренний номер", value: "tt1673434" },
    ],
  },
  {
    id: 364,
    tmdbId: 411,
    imdbId: "tt0363771",
    slug: "the-chronicles-of-narnia-the-lion-the-witch-and-the-wardrobe",
    title: "Хроники Нарнии: Лев, колдунья и волшебный шкаф",
    originalTitle: "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe",
    searchTitles: ["Хроники Нарнии: Лев, колдунья и волшебный шкаф", "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe", "The Chronicles of Narnia", "хроники нарнии: лев, колдунья и волшебный шкаф", "the chronicles of narnia: the lion, the witch and the wardrobe"],
    type: "Фильм",
    year: "2005",
    rating: 6.9,
    genres: ["Фэнтези", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 411, imdbId: "tt0363771", title: "Хроники Нарнии: Лев, колдунья и волшебный шкаф", originalTitle: "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe", year: "2005", type: "Фильм" }),
    description: "Дети попадают в Нарнию и становятся частью борьбы с Белой Колдуньей.",
    trailerUrl: "",
    longDescription: "«Хроники Нарнии: Лев, колдунья и волшебный шкаф» — фильм 2005 года из подборки «The Chronicles of Narnia». Дети попадают в Нарнию и становятся частью борьбы с Белой Колдуньей. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2005" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Chronicles of Narnia" },
      { label: "Жанры", value: "Фэнтези, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0363771" },
    ],
  },
  {
    id: 365,
    tmdbId: 2454,
    imdbId: "tt0499448",
    slug: "the-chronicles-of-narnia-prince-caspian",
    title: "Хроники Нарнии: Принц Каспиан",
    originalTitle: "The Chronicles of Narnia: Prince Caspian",
    searchTitles: ["Хроники Нарнии: Принц Каспиан", "The Chronicles of Narnia: Prince Caspian", "The Chronicles of Narnia", "хроники нарнии: принц каспиан", "the chronicles of narnia: prince caspian"],
    type: "Фильм",
    year: "2008",
    rating: 6.5,
    genres: ["Фэнтези", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 2454, imdbId: "tt0499448", title: "Хроники Нарнии: Принц Каспиан", originalTitle: "The Chronicles of Narnia: Prince Caspian", year: "2008", type: "Фильм" }),
    description: "Герои возвращаются в Нарнию, где прошло много времени и нужна новая помощь.",
    trailerUrl: "",
    longDescription: "«Хроники Нарнии: Принц Каспиан» — фильм 2008 года из подборки «The Chronicles of Narnia». Герои возвращаются в Нарнию, где прошло много времени и нужна новая помощь. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2008" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Chronicles of Narnia" },
      { label: "Жанры", value: "Фэнтези, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0499448" },
    ],
  },
  {
    id: 366,
    tmdbId: 10140,
    imdbId: "tt0980970",
    slug: "the-chronicles-of-narnia-the-voyage-of-the-dawn-treader",
    title: "Хроники Нарнии: Покоритель зари",
    originalTitle: "The Chronicles of Narnia: The Voyage of the Dawn Treader",
    searchTitles: ["Хроники Нарнии: Покоритель зари", "The Chronicles of Narnia: The Voyage of the Dawn Treader", "The Chronicles of Narnia", "хроники нарнии: покоритель зари", "the chronicles of narnia: the voyage of the dawn treader"],
    type: "Фильм",
    year: "2010",
    rating: 6.3,
    genres: ["Фэнтези", "Приключения", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 10140, imdbId: "tt0980970", title: "Хроники Нарнии: Покоритель зари", originalTitle: "The Chronicles of Narnia: The Voyage of the Dawn Treader", year: "2010", type: "Фильм" }),
    description: "Путешествие на корабле приводит героев к новым островам, испытаниям и чудесам.",
    trailerUrl: "",
    longDescription: "«Хроники Нарнии: Покоритель зари» — фильм 2010 года из подборки «The Chronicles of Narnia». Путешествие на корабле приводит героев к новым островам, испытаниям и чудесам. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Фильм" },
      { label: "Франшиза", value: "The Chronicles of Narnia" },
      { label: "Жанры", value: "Фэнтези, Приключения, Боевик" },
      { label: "Внутренний номер", value: "tt0980970" },
    ],
  },
  {
    id: 367,
    tmdbId: 20352,
    imdbId: "tt1323594",
    slug: "despicable-me",
    title: "Гадкий я",
    originalTitle: "Despicable Me",
    searchTitles: ["Гадкий я", "Despicable Me", "гадкий я", "despicable me"],
    type: "Мультфильм",
    year: "2010",
    rating: 7.6,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 20352, imdbId: "tt1323594", title: "Гадкий я", originalTitle: "Despicable Me", year: "2010", type: "Мультфильм" }),
    description: "Грю планирует большое злодейство, но неожиданно меняется из-за трёх девочек.",
    trailerUrl: "",
    longDescription: "«Гадкий я» — мультфильм 2010 года из подборки «Despicable Me». Грю планирует большое злодейство, но неожиданно меняется из-за трёх девочек. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Despicable Me" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt1323594" },
    ],
  },
  {
    id: 368,
    tmdbId: 93456,
    imdbId: "tt1690953",
    slug: "despicable-me-2",
    title: "Гадкий я 2",
    originalTitle: "Despicable Me 2",
    searchTitles: ["Гадкий я 2", "Despicable Me 2", "Despicable Me", "гадкий я 2", "despicable me 2"],
    type: "Мультфильм",
    year: "2013",
    rating: 7.3,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 93456, imdbId: "tt1690953", title: "Гадкий я 2", originalTitle: "Despicable Me 2", year: "2013", type: "Мультфильм" }),
    description: "Грю пробует жизнь без злодейства, но новая миссия быстро находит его сама.",
    trailerUrl: "",
    longDescription: "«Гадкий я 2» — мультфильм 2013 года из подборки «Despicable Me». Грю пробует жизнь без злодейства, но новая миссия быстро находит его сама. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Despicable Me" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt1690953" },
    ],
  },
  {
    id: 369,
    tmdbId: 324852,
    imdbId: "tt3469046",
    slug: "despicable-me-3",
    title: "Гадкий я 3",
    originalTitle: "Despicable Me 3",
    searchTitles: ["Гадкий я 3", "Despicable Me 3", "Despicable Me", "гадкий я 3", "despicable me 3"],
    type: "Мультфильм",
    year: "2017",
    rating: 6.2,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 324852, imdbId: "tt3469046", title: "Гадкий я 3", originalTitle: "Despicable Me 3", year: "2017", type: "Мультфильм" }),
    description: "Грю знакомится с братом и сталкивается с ярким противником из прошлого поп-культуры.",
    trailerUrl: "",
    longDescription: "«Гадкий я 3» — мультфильм 2017 года из подборки «Despicable Me». Грю знакомится с братом и сталкивается с ярким противником из прошлого поп-культуры. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Despicable Me" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt3469046" },
    ],
  },
  {
    id: 370,
    tmdbId: 519182,
    imdbId: "tt7510222",
    slug: "despicable-me-4",
    title: "Гадкий я 4",
    originalTitle: "Despicable Me 4",
    searchTitles: ["Гадкий я 4", "Despicable Me 4", "Despicable Me", "гадкий я 4", "despicable me 4"],
    type: "Мультфильм",
    year: "2024",
    rating: 6.2,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 519182, imdbId: "tt7510222", title: "Гадкий я 4", originalTitle: "Despicable Me 4", year: "2024", type: "Мультфильм" }),
    description: "Семья Грю расширяется, а старые враги снова заставляют Миньонов суетиться.",
    trailerUrl: "",
    longDescription: "«Гадкий я 4» — мультфильм 2024 года из подборки «Despicable Me». Семья Грю расширяется, а старые враги снова заставляют Миньонов суетиться. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Despicable Me" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt7510222" },
    ],
  },
  {
    id: 371,
    tmdbId: 211672,
    imdbId: "tt2293640",
    slug: "minions",
    title: "Миньоны",
    originalTitle: "Minions",
    searchTitles: ["Миньоны", "Minions", "Despicable Me", "миньоны", "minions"],
    type: "Мультфильм",
    year: "2015",
    rating: 6.4,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 211672, imdbId: "tt2293640", title: "Миньоны", originalTitle: "Minions", year: "2015", type: "Мультфильм" }),
    description: "Миньоны ищут самого злодейского босса задолго до встречи с Грю.",
    trailerUrl: "",
    longDescription: "«Миньоны» — мультфильм 2015 года из подборки «Despicable Me». Миньоны ищут самого злодейского босса задолго до встречи с Грю. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2015" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Despicable Me" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt2293640" },
    ],
  },
  {
    id: 372,
    tmdbId: 438148,
    imdbId: "tt5113044",
    slug: "minions-the-rise-of-gru",
    title: "Миньоны: Грювитация",
    originalTitle: "Minions: The Rise of Gru",
    searchTitles: ["Миньоны: Грювитация", "Minions: The Rise of Gru", "Despicable Me", "миньоны: грювитация", "minions: the rise of gru"],
    type: "Мультфильм",
    year: "2022",
    rating: 6.5,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 438148, imdbId: "tt5113044", title: "Миньоны: Грювитация", originalTitle: "Minions: The Rise of Gru", year: "2022", type: "Мультфильм" }),
    description: "Юный Грю мечтает стать суперзлодеем и попадает в историю с Миньонами.",
    trailerUrl: "",
    longDescription: "«Миньоны: Грювитация» — мультфильм 2022 года из подборки «Despicable Me». Юный Грю мечтает стать суперзлодеем и попадает в историю с Миньонами. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Despicable Me" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt5113044" },
    ],
  },
  {
    id: 373,
    tmdbId: 82702,
    imdbId: "tt1646971",
    slug: "how-to-train-your-dragon-2",
    title: "Как приручить дракона 2",
    originalTitle: "How to Train Your Dragon 2",
    searchTitles: ["Как приручить дракона 2", "How to Train Your Dragon 2", "How to Train Your Dragon", "как приручить дракона 2", "how to train your dragon 2"],
    type: "Мультфильм",
    year: "2014",
    rating: 7.8,
    genres: ["Анимация", "Фэнтези", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 82702, imdbId: "tt1646971", title: "Как приручить дракона 2", originalTitle: "How to Train Your Dragon 2", year: "2014", type: "Мультфильм" }),
    description: "Иккинг взрослеет и сталкивается с новой угрозой для людей и драконов.",
    trailerUrl: "",
    longDescription: "«Как приручить дракона 2» — мультфильм 2014 года из подборки «How to Train Your Dragon». Иккинг взрослеет и сталкивается с новой угрозой для людей и драконов. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "How to Train Your Dragon" },
      { label: "Жанры", value: "Анимация, Фэнтези, Приключения" },
      { label: "Внутренний номер", value: "tt1646971" },
    ],
  },
  {
    id: 374,
    tmdbId: 166428,
    imdbId: "tt2386490",
    slug: "how-to-train-your-dragon-the-hidden-world",
    title: "Как приручить дракона 3",
    originalTitle: "How to Train Your Dragon: The Hidden World",
    searchTitles: ["Как приручить дракона 3", "How to Train Your Dragon: The Hidden World", "How to Train Your Dragon", "как приручить дракона 3", "how to train your dragon: the hidden world"],
    type: "Мультфильм",
    year: "2019",
    rating: 7.4,
    genres: ["Анимация", "Фэнтези", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 166428, imdbId: "tt2386490", title: "Как приручить дракона 3", originalTitle: "How to Train Your Dragon: The Hidden World", year: "2019", type: "Мультфильм" }),
    description: "Финал анимационной трилогии о дружбе Иккинга и Беззубика.",
    trailerUrl: "",
    longDescription: "«Как приручить дракона 3» — мультфильм 2019 года из подборки «How to Train Your Dragon». Финал анимационной трилогии о дружбе Иккинга и Беззубика. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "How to Train Your Dragon" },
      { label: "Жанры", value: "Анимация, Фэнтези, Приключения" },
      { label: "Внутренний номер", value: "tt2386490" },
    ],
  },
  {
    id: 375,
    tmdbId: 109445,
    imdbId: "tt2294629",
    slug: "frozen",
    title: "Холодное сердце",
    originalTitle: "Frozen",
    searchTitles: ["Холодное сердце", "Frozen", "холодное сердце", "frozen"],
    type: "Мультфильм",
    year: "2013",
    rating: 7.4,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 109445, imdbId: "tt2294629", title: "Холодное сердце", originalTitle: "Frozen", year: "2013", type: "Мультфильм" }),
    description: "Эльза и Анна проходят через семейную тайну, магию и испытание любви.",
    trailerUrl: "",
    longDescription: "«Холодное сердце» — мультфильм 2013 года из подборки «Frozen». Эльза и Анна проходят через семейную тайну, магию и испытание любви. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Frozen" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt2294629" },
    ],
  },
  {
    id: 376,
    tmdbId: 330457,
    imdbId: "tt4520988",
    slug: "frozen-ii",
    title: "Холодное сердце 2",
    originalTitle: "Frozen II",
    searchTitles: ["Холодное сердце 2", "Frozen II", "Frozen", "холодное сердце 2", "frozen ii"],
    type: "Мультфильм",
    year: "2019",
    rating: 6.8,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 330457, imdbId: "tt4520988", title: "Холодное сердце 2", originalTitle: "Frozen II", year: "2019", type: "Мультфильм" }),
    description: "Сёстры отправляются искать источник магии Эльзы и историю своего королевства.",
    trailerUrl: "",
    longDescription: "«Холодное сердце 2» — мультфильм 2019 года из подборки «Frozen». Сёстры отправляются искать источник магии Эльзы и историю своего королевства. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Frozen" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt4520988" },
    ],
  },
  {
    id: 377,
    tmdbId: 12,
    imdbId: "tt0266543",
    slug: "finding-nemo",
    title: "В поисках Немо",
    originalTitle: "Finding Nemo",
    searchTitles: ["В поисках Немо", "Finding Nemo", "в поисках немо", "finding nemo"],
    type: "Мультфильм",
    year: "2003",
    rating: 8.2,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 12, imdbId: "tt0266543", title: "В поисках Немо", originalTitle: "Finding Nemo", year: "2003", type: "Мультфильм" }),
    description: "Марлин пересекает океан, чтобы найти сына, а зрители получают Дори в подарок судьбы.",
    trailerUrl: "",
    longDescription: "«В поисках Немо» — мультфильм 2003 года из подборки «Finding Nemo». Марлин пересекает океан, чтобы найти сына, а зрители получают Дори в подарок судьбы. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2003" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Finding Nemo" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt0266543" },
    ],
  },
  {
    id: 378,
    tmdbId: 127380,
    imdbId: "tt2277860",
    slug: "finding-dory",
    title: "В поисках Дори",
    originalTitle: "Finding Dory",
    searchTitles: ["В поисках Дори", "Finding Dory", "Finding Nemo", "в поисках дори", "finding dory"],
    type: "Мультфильм",
    year: "2016",
    rating: 7.2,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 127380, imdbId: "tt2277860", title: "В поисках Дори", originalTitle: "Finding Dory", year: "2016", type: "Мультфильм" }),
    description: "Дори отправляется искать свою семью и вспоминать важные кусочки прошлого.",
    trailerUrl: "",
    longDescription: "«В поисках Дори» — мультфильм 2016 года из подборки «Finding Nemo». Дори отправляется искать свою семью и вспоминать важные кусочки прошлого. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2016" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Finding Nemo" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt2277860" },
    ],
  },
  {
    id: 379,
    tmdbId: 920,
    imdbId: "tt0317219",
    slug: "cars",
    title: "Тачки",
    originalTitle: "Cars",
    searchTitles: ["Тачки", "Cars", "тачки", "cars"],
    type: "Мультфильм",
    year: "2006",
    rating: 7.2,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 920, imdbId: "tt0317219", title: "Тачки", originalTitle: "Cars", year: "2006", type: "Мультфильм" }),
    description: "Молния Маккуин застревает в маленьком городке и учится видеть жизнь за пределами гонок.",
    trailerUrl: "",
    longDescription: "«Тачки» — мультфильм 2006 года из подборки «Cars». Молния Маккуин застревает в маленьком городке и учится видеть жизнь за пределами гонок. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2006" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Cars" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt0317219" },
    ],
  },
  {
    id: 380,
    tmdbId: 49013,
    imdbId: "tt1216475",
    slug: "cars-2",
    title: "Тачки 2",
    originalTitle: "Cars 2",
    searchTitles: ["Тачки 2", "Cars 2", "Cars", "тачки 2", "cars 2"],
    type: "Мультфильм",
    year: "2011",
    rating: 6.2,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 49013, imdbId: "tt1216475", title: "Тачки 2", originalTitle: "Cars 2", year: "2011", type: "Мультфильм" }),
    description: "Мэтр и Молния Маккуин оказываются в международной истории со шпионским размахом.",
    trailerUrl: "",
    longDescription: "«Тачки 2» — мультфильм 2011 года из подборки «Cars». Мэтр и Молния Маккуин оказываются в международной истории со шпионским размахом. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2011" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Cars" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt1216475" },
    ],
  },
  {
    id: 381,
    tmdbId: 260514,
    imdbId: "tt3606752",
    slug: "cars-3",
    title: "Тачки 3",
    originalTitle: "Cars 3",
    searchTitles: ["Тачки 3", "Cars 3", "Cars", "тачки 3", "cars 3"],
    type: "Мультфильм",
    year: "2017",
    rating: 6.7,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 260514, imdbId: "tt3606752", title: "Тачки 3", originalTitle: "Cars 3", year: "2017", type: "Мультфильм" }),
    description: "Молния Маккуин пытается вернуться в гонки и принять новую эпоху спорта.",
    trailerUrl: "",
    longDescription: "«Тачки 3» — мультфильм 2017 года из подборки «Cars». Молния Маккуин пытается вернуться в гонки и принять новую эпоху спорта. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Cars" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt3606752" },
    ],
  },
  {
    id: 382,
    tmdbId: 585,
    imdbId: "tt0198781",
    slug: "monsters-inc",
    title: "Корпорация монстров",
    originalTitle: "Monsters, Inc.",
    searchTitles: ["Корпорация монстров", "Monsters, Inc.", "корпорация монстров", "monsters, inc."],
    type: "Мультфильм",
    year: "2001",
    rating: 8.1,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 585, imdbId: "tt0198781", title: "Корпорация монстров", originalTitle: "Monsters, Inc.", year: "2001", type: "Мультфильм" }),
    description: "Монстры Салли и Майк узнают, что ребёнок может изменить весь их мир.",
    trailerUrl: "",
    longDescription: "«Корпорация монстров» — мультфильм 2001 года из подборки «Monsters, Inc.». Монстры Салли и Майк узнают, что ребёнок может изменить весь их мир. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2001" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Monsters, Inc." },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt0198781" },
    ],
  },
  {
    id: 383,
    tmdbId: 62211,
    imdbId: "tt1453405",
    slug: "monsters-university",
    title: "Университет монстров",
    originalTitle: "Monsters University",
    searchTitles: ["Университет монстров", "Monsters University", "Monsters, Inc.", "университет монстров", "monsters university"],
    type: "Мультфильм",
    year: "2013",
    rating: 7.2,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 62211, imdbId: "tt1453405", title: "Университет монстров", originalTitle: "Monsters University", year: "2013", type: "Мультфильм" }),
    description: "Приквел о студенческих годах Майка и Салли до работы в Корпорации монстров.",
    trailerUrl: "",
    longDescription: "«Университет монстров» — мультфильм 2013 года из подборки «Monsters, Inc.». Приквел о студенческих годах Майка и Салли до работы в Корпорации монстров. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2013" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Monsters, Inc." },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt1453405" },
    ],
  },
  {
    id: 384,
    tmdbId: 260513,
    imdbId: "tt3606756",
    slug: "incredibles-2",
    title: "Суперсемейка 2",
    originalTitle: "Incredibles 2",
    searchTitles: ["Суперсемейка 2", "Incredibles 2", "The Incredibles", "суперсемейка 2", "incredibles 2"],
    type: "Мультфильм",
    year: "2018",
    rating: 7.6,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 260513, imdbId: "tt3606756", title: "Суперсемейка 2", originalTitle: "Incredibles 2", year: "2018", type: "Мультфильм" }),
    description: "Семья супергероев возвращается к работе, пытаясь совмещать подвиги и обычную жизнь.",
    trailerUrl: "",
    longDescription: "«Суперсемейка 2» — мультфильм 2018 года из подборки «The Incredibles». Семья супергероев возвращается к работе, пытаясь совмещать подвиги и обычную жизнь. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "The Incredibles" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt3606756" },
    ],
  },
  {
    id: 385,
    tmdbId: 953,
    imdbId: "tt0351283",
    slug: "madagascar",
    title: "Мадагаскар",
    originalTitle: "Madagascar",
    searchTitles: ["Мадагаскар", "Madagascar", "мадагаскар", "madagascar"],
    type: "Мультфильм",
    year: "2005",
    rating: 6.9,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 953, imdbId: "tt0351283", title: "Мадагаскар", originalTitle: "Madagascar", year: "2005", type: "Мультфильм" }),
    description: "Животные из зоопарка случайно попадают на Мадагаскар и учатся выживать вне комфорта.",
    trailerUrl: "",
    longDescription: "«Мадагаскар» — мультфильм 2005 года из подборки «Madagascar». Животные из зоопарка случайно попадают на Мадагаскар и учатся выживать вне комфорта. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2005" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Madagascar" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt0351283" },
    ],
  },
  {
    id: 386,
    tmdbId: 10527,
    imdbId: "tt0479952",
    slug: "madagascar-escape-2-africa",
    title: "Мадагаскар 2",
    originalTitle: "Madagascar: Escape 2 Africa",
    searchTitles: ["Мадагаскар 2", "Madagascar: Escape 2 Africa", "Madagascar", "мадагаскар 2", "madagascar: escape 2 africa"],
    type: "Мультфильм",
    year: "2008",
    rating: 6.6,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 10527, imdbId: "tt0479952", title: "Мадагаскар 2", originalTitle: "Madagascar: Escape 2 Africa", year: "2008", type: "Мультфильм" }),
    description: "Компания оказывается в Африке и сталкивается с вопросами семьи и дома.",
    trailerUrl: "",
    longDescription: "«Мадагаскар 2» — мультфильм 2008 года из подборки «Madagascar». Компания оказывается в Африке и сталкивается с вопросами семьи и дома. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2008" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Madagascar" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt0479952" },
    ],
  },
  {
    id: 387,
    tmdbId: 80321,
    imdbId: "tt1277953",
    slug: "madagascar-3-europe-s-most-wanted",
    title: "Мадагаскар 3",
    originalTitle: "Madagascar 3: Europe's Most Wanted",
    searchTitles: ["Мадагаскар 3", "Madagascar 3: Europe's Most Wanted", "Madagascar", "мадагаскар 3", "madagascar 3: europe's most wanted"],
    type: "Мультфильм",
    year: "2012",
    rating: 6.8,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 80321, imdbId: "tt1277953", title: "Мадагаскар 3", originalTitle: "Madagascar 3: Europe's Most Wanted", year: "2012", type: "Мультфильм" }),
    description: "Герои прячутся в цирке и превращают побег в яркое европейское приключение.",
    trailerUrl: "",
    longDescription: "«Мадагаскар 3» — мультфильм 2012 года из подборки «Madagascar». Герои прячутся в цирке и превращают побег в яркое европейское приключение. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2012" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Madagascar" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt1277953" },
    ],
  },
  {
    id: 388,
    tmdbId: 270946,
    imdbId: "tt1911658",
    slug: "penguins-of-madagascar",
    title: "Пингвины Мадагаскара",
    originalTitle: "Penguins of Madagascar",
    searchTitles: ["Пингвины Мадагаскара", "Penguins of Madagascar", "Madagascar", "пингвины мадагаскара", "penguins of madagascar"],
    type: "Мультфильм",
    year: "2014",
    rating: 6.6,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 270946, imdbId: "tt1911658", title: "Пингвины Мадагаскара", originalTitle: "Penguins of Madagascar", year: "2014", type: "Мультфильм" }),
    description: "Пингвины получают собственную миссию с шпионским масштабом и фирменным абсурдом.",
    trailerUrl: "",
    longDescription: "«Пингвины Мадагаскара» — мультфильм 2014 года из подборки «Madagascar». Пингвины получают собственную миссию с шпионским масштабом и фирменным абсурдом. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Madagascar" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt1911658" },
    ],
  },
  {
    id: 389,
    tmdbId: 1241982,
    imdbId: "tt13622970",
    slug: "moana-2",
    title: "Моана 2",
    originalTitle: "Moana 2",
    searchTitles: ["Моана 2", "Moana 2", "Moana", "моана 2", "moana 2"],
    type: "Мультфильм",
    year: "2024",
    rating: 6.8,
    genres: ["Анимация", "Приключения", "Семейный"],
    countries: ["США"],
    poster: getTmdbPoster({ tmdbId: 1241982, imdbId: "tt13622970", title: "Моана 2", originalTitle: "Moana 2", year: "2024", type: "Мультфильм" }),
    description: "Моана снова отправляется в океанское путешествие и открывает новый путь для своего народа.",
    trailerUrl: "",
    longDescription: "«Моана 2» — мультфильм 2024 года из подборки «Moana». Моана снова отправляется в океанское путешествие и открывает новый путь для своего народа. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Мультфильм" },
      { label: "Франшиза", value: "Moana" },
      { label: "Жанры", value: "Анимация, Приключения, Семейный" },
      { label: "Внутренний номер", value: "tt13622970" },
    ],
  },
  {
    id: 390,
    imdbId: "tt9140560",
    slug: "wandavision",
    title: "Ванда/Вижн",
    originalTitle: "WandaVision",
    searchTitles: ["Ванда/Вижн", "WandaVision", "Marvel Series", "ванда/вижн", "wandavision"],
    type: "Сериал",
    year: "2021",
    rating: 7.9,
    genres: ["Фантастика", "Драма", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt9140560", title: "Ванда/Вижн", originalTitle: "WandaVision", year: "2021", type: "Сериал" }),
    description: "Ванда и Вижн живут в мире телевизионных эпох, за которым скрывается большая тайна.",
    trailerUrl: "",
    longDescription: "«Ванда/Вижн» — сериал 2021 года из подборки «Marvel Series». Ванда и Вижн живут в мире телевизионных эпох, за которым скрывается большая тайна. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Фантастика, Драма, Комедия" },
      { label: "Внутренний номер", value: "tt9140560" },
    ],
  },
  {
    id: 391,
    imdbId: "tt9208876",
    slug: "the-falcon-and-the-winter-soldier",
    title: "Сокол и Зимний солдат",
    originalTitle: "The Falcon and the Winter Soldier",
    searchTitles: ["Сокол и Зимний солдат", "The Falcon and the Winter Soldier", "Marvel Series", "сокол и зимний солдат", "the falcon and the winter soldier"],
    type: "Сериал",
    year: "2021",
    rating: 7.1,
    genres: ["Боевик", "Драма", "Фантастика"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt9208876", title: "Сокол и Зимний солдат", originalTitle: "The Falcon and the Winter Soldier", year: "2021", type: "Сериал" }),
    description: "Сэм Уилсон и Баки Барнс разбираются с наследием щита Капитана Америки.",
    trailerUrl: "",
    longDescription: "«Сокол и Зимний солдат» — сериал 2021 года из подборки «Marvel Series». Сэм Уилсон и Баки Барнс разбираются с наследием щита Капитана Америки. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Боевик, Драма, Фантастика" },
      { label: "Внутренний номер", value: "tt9208876" },
    ],
  },
  {
    id: 392,
    imdbId: "tt10160804",
    slug: "hawkeye",
    title: "Соколиный глаз",
    originalTitle: "Hawkeye",
    searchTitles: ["Соколиный глаз", "Hawkeye", "Marvel Series", "соколиный глаз", "hawkeye"],
    type: "Сериал",
    year: "2021",
    rating: 7.5,
    genres: ["Боевик", "Криминал", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt10160804", title: "Соколиный глаз", originalTitle: "Hawkeye", year: "2021", type: "Сериал" }),
    description: "Клинт Бартон сталкивается с последствиями прошлого и новой героиней Кейт Бишоп.",
    trailerUrl: "",
    longDescription: "«Соколиный глаз» — сериал 2021 года из подборки «Marvel Series». Клинт Бартон сталкивается с последствиями прошлого и новой героиней Кейт Бишоп. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Боевик, Криминал, Комедия" },
      { label: "Внутренний номер", value: "tt10160804" },
    ],
  },
  {
    id: 393,
    imdbId: "tt10234724",
    slug: "moon-knight",
    title: "Лунный рыцарь",
    originalTitle: "Moon Knight",
    searchTitles: ["Лунный рыцарь", "Moon Knight", "Marvel Series", "лунный рыцарь", "moon knight"],
    type: "Сериал",
    year: "2022",
    rating: 7.3,
    genres: ["Фэнтези", "Боевик", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt10234724", title: "Лунный рыцарь", originalTitle: "Moon Knight", year: "2022", type: "Сериал" }),
    description: "Герой с несколькими сторонами личности оказывается связан с древнеегипетской мифологией.",
    trailerUrl: "",
    longDescription: "«Лунный рыцарь» — сериал 2022 года из подборки «Marvel Series». Герой с несколькими сторонами личности оказывается связан с древнеегипетской мифологией. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Фэнтези, Боевик, Драма" },
      { label: "Внутренний номер", value: "tt10234724" },
    ],
  },
  {
    id: 394,
    imdbId: "tt10857164",
    slug: "ms-marvel",
    title: "Мисс Марвел",
    originalTitle: "Ms. Marvel",
    searchTitles: ["Мисс Марвел", "Ms. Marvel", "Marvel Series", "мисс марвел", "ms. marvel"],
    type: "Сериал",
    year: "2022",
    rating: 6.2,
    genres: ["Фантастика", "Комедия", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt10857164", title: "Мисс Марвел", originalTitle: "Ms. Marvel", year: "2022", type: "Сериал" }),
    description: "Камала Хан из Джерси-Сити открывает способности и собственное место в мире героев.",
    trailerUrl: "",
    longDescription: "«Мисс Марвел» — сериал 2022 года из подборки «Marvel Series». Камала Хан из Джерси-Сити открывает способности и собственное место в мире героев. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Фантастика, Комедия, Приключения" },
      { label: "Внутренний номер", value: "tt10857164" },
    ],
  },
  {
    id: 395,
    imdbId: "tt10857160",
    slug: "she-hulk-attorney-at-law",
    title: "Женщина-Халк: Адвокат",
    originalTitle: "She-Hulk: Attorney at Law",
    searchTitles: ["Женщина-Халк: Адвокат", "She-Hulk: Attorney at Law", "Marvel Series", "женщина-халк: адвокат", "she-hulk: attorney at law"],
    type: "Сериал",
    year: "2022",
    rating: 5.2,
    genres: ["Комедия", "Фантастика", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt10857160", title: "Женщина-Халк: Адвокат", originalTitle: "She-Hulk: Attorney at Law", year: "2022", type: "Сериал" }),
    description: "Дженнифер Уолтерс совмещает адвокатскую практику и жизнь с силой Халка.",
    trailerUrl: "",
    longDescription: "«Женщина-Халк: Адвокат» — сериал 2022 года из подборки «Marvel Series». Дженнифер Уолтерс совмещает адвокатскую практику и жизнь с силой Халка. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Комедия, Фантастика, Боевик" },
      { label: "Внутренний номер", value: "tt10857160" },
    ],
  },
  {
    id: 396,
    imdbId: "tt13157618",
    slug: "secret-invasion",
    title: "Секретное вторжение",
    originalTitle: "Secret Invasion",
    searchTitles: ["Секретное вторжение", "Secret Invasion", "Marvel Series", "секретное вторжение", "secret invasion"],
    type: "Сериал",
    year: "2023",
    rating: 5.9,
    genres: ["Фантастика", "Триллер", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt13157618", title: "Секретное вторжение", originalTitle: "Secret Invasion", year: "2023", type: "Сериал" }),
    description: "Ник Фьюри сталкивается с угрозой скрытого проникновения скруллов.",
    trailerUrl: "",
    longDescription: "«Секретное вторжение» — сериал 2023 года из подборки «Marvel Series». Ник Фьюри сталкивается с угрозой скрытого проникновения скруллов. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Фантастика, Триллер, Боевик" },
      { label: "Внутренний номер", value: "tt13157618" },
    ],
  },
  {
    id: 397,
    imdbId: "tt13966962",
    slug: "echo",
    title: "Эхо",
    originalTitle: "Echo",
    searchTitles: ["Эхо", "Echo", "Marvel Series", "эхо", "echo"],
    type: "Сериал",
    year: "2024",
    rating: 6.0,
    genres: ["Боевик", "Криминал", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt13966962", title: "Эхо", originalTitle: "Echo", year: "2024", type: "Сериал" }),
    description: "Майя Лопес возвращается к корням и сталкивается с прошлым после событий «Соколиного глаза».",
    trailerUrl: "",
    longDescription: "«Эхо» — сериал 2024 года из подборки «Marvel Series». Майя Лопес возвращается к корням и сталкивается с прошлым после событий «Соколиного глаза». Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Боевик, Криминал, Драма" },
      { label: "Внутренний номер", value: "tt13966962" },
    ],
  },
  {
    id: 398,
    imdbId: "tt15571732",
    slug: "agatha-all-along",
    title: "Это всё Агата",
    originalTitle: "Agatha All Along",
    searchTitles: ["Это всё Агата", "Agatha All Along", "Marvel Series", "это всё агата", "agatha all along"],
    type: "Сериал",
    year: "2024",
    rating: 7.2,
    genres: ["Фэнтези", "Комедия", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt15571732", title: "Это всё Агата", originalTitle: "Agatha All Along", year: "2024", type: "Сериал" }),
    description: "Агата Харкнесс возвращается к магии и собственным тайнам после Вествью.",
    trailerUrl: "",
    longDescription: "«Это всё Агата» — сериал 2024 года из подборки «Marvel Series». Агата Харкнесс возвращается к магии и собственным тайнам после Вествью. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Фэнтези, Комедия, Драма" },
      { label: "Внутренний номер", value: "tt15571732" },
    ],
  },
  {
    id: 399,
    imdbId: "tt18923754",
    slug: "daredevil-born-again",
    title: "Сорвиголова: Рождённый заново",
    originalTitle: "Daredevil: Born Again",
    searchTitles: ["Сорвиголова: Рождённый заново", "Daredevil: Born Again", "Marvel Series", "сорвиголова: рождённый заново", "daredevil: born again"],
    type: "Сериал",
    year: "2025",
    rating: 8.2,
    genres: ["Криминал", "Драма", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt18923754", title: "Сорвиголова: Рождённый заново", originalTitle: "Daredevil: Born Again", year: "2025", type: "Сериал" }),
    description: "Мэтт Мёрдок снова защищает Нью-Йорк как адвокат и как Сорвиголова.",
    trailerUrl: "",
    longDescription: "«Сорвиголова: Рождённый заново» — сериал 2025 года из подборки «Marvel Series». Мэтт Мёрдок снова защищает Нью-Йорк как адвокат и как Сорвиголова. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2025" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Криминал, Драма, Боевик" },
      { label: "Внутренний номер", value: "tt18923754" },
    ],
  },
  {
    id: 400,
    imdbId: "tt13623126",
    slug: "ironheart",
    title: "Железное сердце",
    originalTitle: "Ironheart",
    searchTitles: ["Железное сердце", "Ironheart", "Marvel Series", "железное сердце", "ironheart"],
    type: "Сериал",
    year: "2025",
    rating: 0.0,
    genres: ["Фантастика", "Боевик", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt13623126", title: "Железное сердце", originalTitle: "Ironheart", year: "2025", type: "Сериал" }),
    description: "Рири Уильямс создаёт собственную высокотехнологичную броню и входит в мир больших угроз.",
    trailerUrl: "",
    longDescription: "«Железное сердце» — сериал 2025 года из подборки «Marvel Series». Рири Уильямс создаёт собственную высокотехнологичную броню и входит в мир больших угроз. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2025" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Фантастика, Боевик, Драма" },
      { label: "Внутренний номер", value: "tt13623126" },
    ],
  },
  {
    id: 401,
    imdbId: "tt10168312",
    slug: "what-if",
    title: "Что, если...?",
    originalTitle: "What If...?",
    searchTitles: ["Что, если...?", "What If...?", "Marvel Series", "что, если...?", "what if...?"],
    type: "Сериал",
    year: "2021",
    rating: 7.4,
    genres: ["Анимация", "Фантастика", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt10168312", title: "Что, если...?", originalTitle: "What If...?", year: "2021", type: "Сериал" }),
    description: "Анимационная антология показывает альтернативные варианты событий Marvel.",
    trailerUrl: "",
    longDescription: "«Что, если...?» — сериал 2021 года из подборки «Marvel Series». Анимационная антология показывает альтернативные варианты событий Marvel. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2021" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Анимация, Фантастика, Приключения" },
      { label: "Внутренний номер", value: "tt10168312" },
    ],
  },
  {
    id: 402,
    imdbId: "tt16026746",
    slug: "x-men-97",
    title: "Люди Икс ’97",
    originalTitle: "X-Men '97",
    searchTitles: ["Люди Икс ’97", "X-Men '97", "Marvel Series", "люди икс ’97", "x-men '97"],
    type: "Сериал",
    year: "2024",
    rating: 8.8,
    genres: ["Анимация", "Фантастика", "Боевик"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt16026746", title: "Люди Икс ’97", originalTitle: "X-Men '97", year: "2024", type: "Сериал" }),
    description: "Продолжение классического мультсериала о команде мутантов Marvel.",
    trailerUrl: "",
    longDescription: "«Люди Икс ’97» — сериал 2024 года из подборки «Marvel Series». Продолжение классического мультсериала о команде мутантов Marvel. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Marvel Series" },
      { label: "Жанры", value: "Анимация, Фантастика, Боевик" },
      { label: "Внутренний номер", value: "tt16026746" },
    ],
  },
  {
    id: 403,
    imdbId: "tt15435876",
    slug: "the-penguin",
    title: "Пингвин",
    originalTitle: "The Penguin",
    searchTitles: ["Пингвин", "The Penguin", "Batman / DC Series", "пингвин", "the penguin"],
    type: "Сериал",
    year: "2024",
    rating: 8.6,
    genres: ["Криминал", "Драма", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt15435876", title: "Пингвин", originalTitle: "The Penguin", year: "2024", type: "Сериал" }),
    description: "Освальд Кобб пытается подняться в криминальной иерархии Готэма после событий «Бэтмена».",
    trailerUrl: "",
    longDescription: "«Пингвин» — сериал 2024 года из подборки «Batman / DC Series». Освальд Кобб пытается подняться в криминальной иерархии Готэма после событий «Бэтмена». Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Batman / DC Series" },
      { label: "Жанры", value: "Криминал, Драма, Триллер" },
      { label: "Внутренний номер", value: "tt15435876" },
    ],
  },
  {
    id: 404,
    imdbId: "tt3749900",
    slug: "gotham",
    title: "Готэм",
    originalTitle: "Gotham",
    searchTitles: ["Готэм", "Gotham", "Batman / DC Series", "готэм", "gotham"],
    type: "Сериал",
    year: "2014",
    rating: 7.8,
    genres: ["Криминал", "Драма", "Детектив"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt3749900", title: "Готэм", originalTitle: "Gotham", year: "2014", type: "Сериал" }),
    description: "История молодого Джима Гордона и города до появления привычного Бэтмена.",
    trailerUrl: "",
    longDescription: "«Готэм» — сериал 2014 года из подборки «Batman / DC Series». История молодого Джима Гордона и города до появления привычного Бэтмена. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2014" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Batman / DC Series" },
      { label: "Жанры", value: "Криминал, Драма, Детектив" },
      { label: "Внутренний номер", value: "tt3749900" },
    ],
  },
  {
    id: 405,
    imdbId: "tt0103359",
    slug: "batman-the-animated-series",
    title: "Бэтмен: Анимационный сериал",
    originalTitle: "Batman: The Animated Series",
    searchTitles: ["Бэтмен: Анимационный сериал", "Batman: The Animated Series", "Batman / DC Series", "бэтмен: анимационный сериал", "batman: the animated series"],
    type: "Сериал",
    year: "1992",
    rating: 9.0,
    genres: ["Анимация", "Криминал", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0103359", title: "Бэтмен: Анимационный сериал", originalTitle: "Batman: The Animated Series", year: "1992", type: "Сериал" }),
    description: "Классический анимационный сериал о Бэтмене, Готэме и его главных противниках.",
    trailerUrl: "",
    longDescription: "«Бэтмен: Анимационный сериал» — сериал 1992 года из подборки «Batman / DC Series». Классический анимационный сериал о Бэтмене, Готэме и его главных противниках. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "1992" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "Batman / DC Series" },
      { label: "Жанры", value: "Анимация, Криминал, Приключения" },
      { label: "Внутренний номер", value: "tt0103359" },
    ],
  },
  {
    id: 406,
    imdbId: "tt1043813",
    slug: "titans",
    title: "Титаны",
    originalTitle: "Titans",
    searchTitles: ["Титаны", "Titans", "DC Series", "титаны", "titans"],
    type: "Сериал",
    year: "2018",
    rating: 7.5,
    genres: ["Боевик", "Фантастика", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt1043813", title: "Титаны", originalTitle: "Titans", year: "2018", type: "Сериал" }),
    description: "Команда молодых героев DC собирается вокруг Дика Грейсона.",
    trailerUrl: "",
    longDescription: "«Титаны» — сериал 2018 года из подборки «DC Series». Команда молодых героев DC собирается вокруг Дика Грейсона. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "DC Series" },
      { label: "Жанры", value: "Боевик, Фантастика, Драма" },
      { label: "Внутренний номер", value: "tt1043813" },
    ],
  },
  {
    id: 407,
    imdbId: "tt8416494",
    slug: "doom-patrol",
    title: "Роковой патруль",
    originalTitle: "Doom Patrol",
    searchTitles: ["Роковой патруль", "Doom Patrol", "DC Series", "роковой патруль", "doom patrol"],
    type: "Сериал",
    year: "2019",
    rating: 7.8,
    genres: ["Фантастика", "Комедия", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt8416494", title: "Роковой патруль", originalTitle: "Doom Patrol", year: "2019", type: "Сериал" }),
    description: "Необычная команда травмированных героев сталкивается с абсурдными и опасными миссиями.",
    trailerUrl: "",
    longDescription: "«Роковой патруль» — сериал 2019 года из подборки «DC Series». Необычная команда травмированных героев сталкивается с абсурдными и опасными миссиями. Карточка добавлена в KinoLuma без ручных постеров: изображение подтягивается в хорошем качестве, а варианты просмотра будут добавлены, когда карточка полностью обновится.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Сериал" },
      { label: "Франшиза", value: "DC Series" },
      { label: "Жанры", value: "Фантастика, Комедия, Драма" },
      { label: "Внутренний номер", value: "tt8416494" },
    ],
  },


  {
    id: 408,
    kinopoiskId: 4499386,
    imdbId: "tt14849194",
    slug: "the-holdovers",
    title: "Оставленные",
    originalTitle: "The Holdovers",
    searchTitles: ["Оставленные", "The Holdovers", "оставленные", "холдоверы"],
    type: "Фильм",
    year: "2023",
    rating: 7.9,
    genres: ["Драма", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt14849194", title: "Оставленные", originalTitle: "The Holdovers", year: "2023", type: "Фильм" }),
    description: "Зимняя камерная история о строгом учителе, ученике и поварихе, которые остаются в закрытой школе на каникулы.",
    trailerUrl: "https://www.youtube.com/embed/AhKLpJmHhIg",
    longDescription: "«Оставленные» — драмеди 2023 года о людях, которые вынужденно проводят рождественские каникулы в пустеющей школе. Карточка добавлена в KinoLuma с нейтральным описанием без выдуманных фактов: здесь есть жанры, трейлер, описание, дополнительные сведения и варианты просмотра, если они доступны.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Жанры", value: "Драма, Комедия" },
      { label: "Внутренний номер", value: "tt14849194" },
    ],
    players: createKinopoiskPlayers(4499386),
  },
  {
    id: 409,
    kinopoiskId: 1346482,
    imdbId: "tt13238346",
    slug: "past-lives",
    title: "Прошлые жизни",
    originalTitle: "Past Lives",
    searchTitles: ["Прошлые жизни", "Past Lives", "прошлые жизни", "паст лайвс"],
    type: "Фильм",
    year: "2023",
    rating: 7.8,
    genres: ["Драма", "Мелодрама"],
    countries: ["США", "Корея Южная"],
    poster: getTmdbPoster({ imdbId: "tt13238346", title: "Прошлые жизни", originalTitle: "Past Lives", year: "2023", type: "Фильм" }),
    description: "Тихая драма о двух друзьях детства, которые встречаются спустя годы и заново осмысляют прошлое.",
    trailerUrl: "https://www.youtube.com/embed/kA244xewjcI",
    longDescription: "«Прошлые жизни» — фильм 2023 года о памяти, взрослении и связи, которая не исчезает после переезда и долгой разлуки. Карточка использует внутренний каталог для постера, бесплатный шаблон описания KinoLuma и варианты просмотра по внутреннему номеру без ручного зашивания секретов.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Корея Южная" },
      { label: "Жанры", value: "Драма, Мелодрама" },
      { label: "Внутренний номер", value: "tt13238346" },
    ],
    players: createKinopoiskPlayers(1346482),
  },
  {
    id: 410,
    kinopoiskId: 762646,
    imdbId: "tt2906216",
    slug: "dungeons-dragons-honor-among-thieves",
    title: "Подземелья и драконы: Честь среди воров",
    originalTitle: "Dungeons & Dragons: Honor Among Thieves",
    searchTitles: ["Подземелья и драконы", "Честь среди воров", "Dungeons & Dragons Honor Among Thieves", "dnd movie"],
    type: "Фильм",
    year: "2023",
    rating: 7.2,
    genres: ["Фэнтези", "Приключения", "Комедия"],
    countries: ["США", "Канада"],
    poster: getTmdbPoster({ imdbId: "tt2906216", title: "Подземелья и драконы: Честь среди воров", originalTitle: "Dungeons & Dragons: Honor Among Thieves", year: "2023", type: "Фильм" }),
    description: "Фэнтези-приключение о команде неидеальных героев, которые ввязываются в опасную авантюру.",
    trailerUrl: "https://www.youtube.com/embed/IiMinixSXII",
    longDescription: "«Подземелья и драконы: Честь среди воров» — приключенческое фэнтези 2023 года с лёгким юмором, командной динамикой и большим путешествием. В KinoLuma карточка добавлена так, чтобы не ломать текущую архитектуру: данные лежат в каталоге, описание и дополнительные сведения подтягиваются существующими функциями, а просмотр строится по внутреннему номеру.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США, Канада" },
      { label: "Жанры", value: "Фэнтези, Приключения, Комедия" },
      { label: "Внутренний номер", value: "tt2906216" },
    ],
    players: createKinopoiskPlayers(762646),
  },
  {
    id: 411,
    kinopoiskId: 4499408,
    imdbId: "tt11858890",
    slug: "the-creator",
    title: "Создатель",
    originalTitle: "The Creator",
    searchTitles: ["Создатель", "The Creator", "создатель 2023", "the creator 2023"],
    type: "Фильм",
    year: "2023",
    rating: 6.7,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt11858890", title: "Создатель", originalTitle: "The Creator", year: "2023", type: "Фильм" }),
    description: "Фантастическая драма о будущем, где конфликт людей и искусственного интеллекта становится личной историей.",
    trailerUrl: "https://www.youtube.com/embed/ex3C1-5Dhb8",
    longDescription: "«Создатель» — научно-фантастический фильм 2023 года о мире будущего, технологиях и выборе, который меняет отношение героя к происходящему вокруг. Описание сделано нейтрально и без выдуманных деталей; карточка получает постер через внутренний каталог, описание через шаблон KinoLuma и варианты просмотра по внутреннему номеру.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
      { label: "Внутренний номер", value: "tt11858890" },
    ],
    players: createKinopoiskPlayers(4499408),
  },
  {
    id: 412,
    kinopoiskId: 5354707,
    imdbId: "tt23289160",
    slug: "godzilla-minus-one",
    title: "Годзилла: Минус один",
    originalTitle: "Gojira -1.0",
    searchTitles: ["Годзилла Минус один", "Godzilla Minus One", "Gojira -1.0", "годзилла минус один"],
    type: "Фильм",
    year: "2023",
    rating: 7.8,
    genres: ["Фантастика", "Драма", "Приключения"],
    countries: ["Япония"],
    poster: getTmdbPoster({ imdbId: "tt23289160", title: "Годзилла: Минус один", originalTitle: "Gojira -1.0", year: "2023", type: "Фильм" }),
    description: "Японская история о послевоенном обществе, которое сталкивается с новой разрушительной угрозой.",
    trailerUrl: "https://www.youtube.com/embed/VvSrHIX5a-0",
    longDescription: "«Годзилла: Минус один» — фильм 2023 года, где жанровое зрелище соединяется с человеческой драмой и темой восстановления после катастрофы. Карточка добавлена в общий каталог KinoLuma: обновление каталога подхватят её после сборки, а варианты просмотра подключаются из карточки.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "Япония" },
      { label: "Жанры", value: "Фантастика, Драма, Приключения" },
      { label: "Внутренний номер", value: "tt23289160" },
    ],
    players: createKinopoiskPlayers(5354707),
  },
  {
    id: 413,
    kinopoiskId: 5000997,
    imdbId: "tt16419074",
    slug: "air-2023",
    title: "Air: Большой прыжок",
    originalTitle: "Air",
    searchTitles: ["Air", "Air Большой прыжок", "эйр", "большой прыжок", "nike jordan film"],
    type: "Фильм",
    year: "2023",
    rating: 7.4,
    genres: ["Биография", "Драма", "Спорт"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt16419074", title: "Air: Большой прыжок", originalTitle: "Air", year: "2023", type: "Фильм" }),
    description: "Спортивная бизнес-драма о рискованной сделке, из которой выросла легендарная баскетбольная линейка.",
    trailerUrl: "https://www.youtube.com/embed/Euy4Yu6B3nU",
    longDescription: "«Air: Большой прыжок» — фильм 2023 года о маркетинговом решении, которое изменило спортивную индустрию. Карточка добавлена без выдуманных деталей: описание и нижний блок сделаны по шаблону, описание остаётся в текущем стиле проекта, а варианты просмотра создаются по данным карточки.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Фильм" },
      { label: "Страна", value: "США" },
      { label: "Жанры", value: "Биография, Драма, Спорт" },
      { label: "Внутренний номер", value: "tt16419074" },
    ],
    players: createKinopoiskPlayers(5000997),
  },
  {
    id: 414,
    kinopoiskId: 253245,
    imdbId: "tt0386676",
    slug: "the-office-us",
    title: "Офис",
    originalTitle: "The Office",
    searchTitles: ["Офис", "The Office US", "офис сша", "dunder mifflin"],
    type: "Сериал",
    year: "2005",
    rating: 9.0,
    genres: ["Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt0386676", title: "Офис", originalTitle: "The Office", year: "2005", type: "Сериал" }),
    description: "Мокьюментари-комедия о буднях сотрудников регионального офиса бумажной компании.",
    trailerUrl: "https://www.youtube.com/embed/cRpbuYnHWQY",
    longDescription: "«Офис» — комедийный сериал о рабочей рутине, странных совещаниях и людях, которые превращают обычный офис в маленькую вселенную. В KinoLuma сериал добавлен с внутреннему номеру, поэтому основные варианты просмотра строятся автоматически, а описание и дополнительные сведения остаются на существующих шаблонах проекта.",
    facts: [
      { label: "Год", value: "2005" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Жанры", value: "Комедия" },
      { label: "Внутренний номер", value: "tt0386676" },
    ],
    players: createKinopoiskPlayers(253245),
  },
  {
    id: 415,
    kinopoiskId: 1343318,
    imdbId: "tt11280740",
    slug: "severance",
    title: "Разделение",
    originalTitle: "Severance",
    searchTitles: ["Разделение", "Severance", "severance apple", "люмон"],
    type: "Сериал",
    year: "2022",
    rating: 8.7,
    genres: ["Фантастика", "Триллер", "Драма"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt11280740", title: "Разделение", originalTitle: "Severance", year: "2022", type: "Сериал" }),
    description: "Корпоративный триллер о сотрудниках, чьи рабочие и личные воспоминания искусственно разделены.",
    trailerUrl: "https://www.youtube.com/embed/xEQP4VVuyrY",
    longDescription: "«Разделение» — сериал 2022 года о компании Lumon и процедуре, которая отделяет рабочую память от личной. Описание не раскрывает лишнего и не выдумывает факты; карточка использует текущий шаблон описания KinoLuma, дополнительные сведения и варианты просмотра по внутреннему номеру.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Жанры", value: "Фантастика, Триллер, Драма" },
      { label: "Внутренний номер", value: "tt11280740" },
    ],
    players: createKinopoiskPlayers(1343318),
  },
  {
    id: 416,
    kinopoiskId: 1309707,
    imdbId: "tt10986410",
    slug: "ted-lasso",
    title: "Тед Лассо",
    originalTitle: "Ted Lasso",
    searchTitles: ["Тед Лассо", "Ted Lasso", "тэд лассо", "ted lasso"],
    type: "Сериал",
    year: "2020",
    rating: 8.8,
    genres: ["Комедия", "Драма", "Спорт"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt10986410", title: "Тед Лассо", originalTitle: "Ted Lasso", year: "2020", type: "Сериал" }),
    description: "Оптимистичный тренер по американскому футболу получает работу в английском футбольном клубе.",
    trailerUrl: "https://www.youtube.com/embed/3u7EIiohs6U",
    longDescription: "«Тед Лассо» — сериал о тренере, который попадает в непривычную спортивную среду и отвечает на хаос добротой, упрямством и командной работой. Карточка добавлена в каталоге, так что после сборки она попадёт в каталог и sitemap без ручного редактирования служебных файлов.",
    facts: [
      { label: "Год", value: "2020" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Жанры", value: "Комедия, Драма, Спорт" },
      { label: "Внутренний номер", value: "tt10986410" },
    ],
    players: createKinopoiskPlayers(1309707),
  },
  {
    id: 417,
    kinopoiskId: 986788,
    imdbId: "tt7660850",
    slug: "succession",
    title: "Наследники",
    originalTitle: "Succession",
    searchTitles: ["Наследники", "Succession", "семья рой", "roy family"],
    type: "Сериал",
    year: "2018",
    rating: 8.8,
    genres: ["Драма", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt7660850", title: "Наследники", originalTitle: "Succession", year: "2018", type: "Сериал" }),
    description: "Сатирическая драма о семье медиамагната, где власть и наследство становятся семейным спортом.",
    trailerUrl: "https://www.youtube.com/embed/OzYxJV_rmE8",
    longDescription: "«Наследники» — сериал о большой медиаимперии и родственниках, которые постоянно проверяют друг друга на прочность. Карточка добавлена точечно: описание нейтральное, рейтинг не выдуман, варианты просмотра связаны с карточкой, а описание и дополнительные сведения формируются существующими функциями KinoLuma.",
    facts: [
      { label: "Год", value: "2018" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Жанры", value: "Драма, Комедия" },
      { label: "Внутренний номер", value: "tt7660850" },
    ],
    players: createKinopoiskPlayers(986788),
  },
  {
    id: 418,
    kinopoiskId: 749562,
    imdbId: "tt2788316",
    slug: "shogun-2024",
    title: "Сёгун",
    originalTitle: "Shōgun",
    searchTitles: ["Сёгун", "Сегун", "Shogun", "Shōgun", "сёгун 2024"],
    type: "Сериал",
    year: "2024",
    rating: 8.6,
    genres: ["Драма", "История", "Приключения"],
    countries: ["США", "Япония"],
    poster: getTmdbPoster({ imdbId: "tt2788316", title: "Сёгун", originalTitle: "Shōgun", year: "2024", type: "Сериал" }),
    description: "Историческая драма о европейском мореплавателе, который оказывается в Японии начала XVII века.",
    trailerUrl: "https://www.youtube.com/embed/yAN5uspO_hk",
    longDescription: "«Сёгун» — сериал 2024 года о столкновении культур, политических интригах и борьбе за влияние в Японии начала XVII века. Карточка использует существующую архитектуру KinoLuma: каталоге как источник, обновление каталога после сборки и варианты просмотра по данным карточки.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США, Япония" },
      { label: "Жанры", value: "Драма, История, Приключения" },
      { label: "Внутренний номер", value: "tt2788316" },
    ],
    players: createKinopoiskPlayers(749562),
  },
  {
    id: 419,
    kinopoiskId: 1311083,
    imdbId: "tt11016042",
    slug: "ripley-2024",
    title: "Рипли",
    originalTitle: "Ripley",
    searchTitles: ["Рипли", "Ripley", "рипли 2024", "tom ripley"],
    type: "Сериал",
    year: "2024",
    rating: 8.1,
    genres: ["Драма", "Криминал", "Триллер"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt11016042", title: "Рипли", originalTitle: "Ripley", year: "2024", type: "Сериал" }),
    description: "Чёрно-белая криминальная история о Томе Рипли, который получает предложение отправиться в Европу.",
    trailerUrl: "https://www.youtube.com/embed/0ri2biYLeaI",
    longDescription: "«Рипли» — мини-сериал 2024 года с атмосферой психологического триллера и неторопливой криминальной интригой. Карточка добавлена без изменения публичной архитектуры: данные остаются в каталоге, описание и дополнительные сведения формируются текущими функциями, варианты просмотра подключаются по данным карточки.",
    facts: [
      { label: "Год", value: "2024" },
      { label: "Тип", value: "Сериал" },
      { label: "Страна", value: "США" },
      { label: "Жанры", value: "Драма, Криминал, Триллер" },
      { label: "Внутренний номер", value: "tt11016042" },
    ],
    players: createKinopoiskPlayers(1311083),
  },
  {
    id: 420,
    kinopoiskId: 1073233,
    imdbId: "tt6769208",
    slug: "blue-planet-ii",
    title: "Голубая планета 2",
    originalTitle: "Blue Planet II",
    searchTitles: ["Голубая планета 2", "Blue Planet II", "голубая планета ii", "bbc blue planet"],
    type: "Документальный",
    year: "2017",
    rating: 9.3,
    genres: ["Документальный", "Природа"],
    countries: ["Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt6769208", title: "Голубая планета 2", originalTitle: "Blue Planet II", year: "2017", type: "Документальный" }),
    description: "Документальный цикл BBC о жизни океанов, редких природных явлениях и мире под водой.",
    trailerUrl: "https://www.youtube.com/embed/_38JDGnr0vA",
    longDescription: "«Голубая планета 2» — документальный проект о Мировом океане, его обитателях и хрупком балансе природных систем. Для KinoLuma добавлены описание, трейлер, факты и варианты просмотра по внутреннему номеру; описание и дополнительные сведения подтягиваются через уже рабочие шаблоны сайта.",
    facts: [
      { label: "Год", value: "2017" },
      { label: "Тип", value: "Документальный" },
      { label: "Страна", value: "Великобритания" },
      { label: "Жанры", value: "Документальный, Природа" },
      { label: "Внутренний номер", value: "tt6769208" },
    ],
    players: createKinopoiskPlayers(1073233),
  },
  {
    id: 421,
    kinopoiskId: 1235047,
    imdbId: "tt8760684",
    slug: "apollo-11-2019",
    title: "Аполлон-11",
    originalTitle: "Apollo 11",
    searchTitles: ["Аполлон-11", "Apollo 11", "аполлон 11", "apollo 11 documentary"],
    type: "Документальный",
    year: "2019",
    rating: 8.1,
    genres: ["Документальный", "История", "Космос"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt8760684", title: "Аполлон-11", originalTitle: "Apollo 11", year: "2019", type: "Документальный" }),
    description: "Документальный фильм о лунной миссии 1969 года, собранный вокруг архивных кадров и записей.",
    trailerUrl: "https://www.youtube.com/embed/3Co8Z8BQgWc",
    longDescription: "«Аполлон-11» — документальный фильм 2019 года о знаменитой космической миссии. Карточка подходит для раздела документалок KinoLuma: есть краткое описание, нижний блок «О фильме», трейлер, факты, обновление каталога после сборки и варианты просмотра по внутреннему номеру.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Документальный" },
      { label: "Страна", value: "США" },
      { label: "Жанры", value: "Документальный, История, Космос" },
      { label: "Внутренний номер", value: "tt8760684" },
    ],
    players: createKinopoiskPlayers(1235047),
  },
  {
    id: 422,
    kinopoiskId: 573209,
    imdbId: "tt1424432",
    slug: "senna-2010",
    title: "Сенна",
    originalTitle: "Senna",
    searchTitles: ["Сенна", "Senna", "Айртон Сенна", "Ayrton Senna"],
    type: "Документальный",
    year: "2010",
    rating: 8.5,
    genres: ["Документальный", "Биография", "Спорт"],
    countries: ["Великобритания", "Франция"],
    poster: getTmdbPoster({ imdbId: "tt1424432", title: "Сенна", originalTitle: "Senna", year: "2010", type: "Документальный" }),
    description: "Документальная история о карьере Айртона Сенны и его месте в истории Формулы-1.",
    trailerUrl: "https://www.youtube.com/embed/sfosF-ZAbR4",
    longDescription: "«Сенна» — документальный фильм о легендарном гонщике Формулы-1, его спортивном пути и архивной хронике эпохи. В карточке не добавлены непроверенные рейтинги или награды: только базовые факты, трейлер, описание и варианты просмотра, собранные по данным карточки.",
    facts: [
      { label: "Год", value: "2010" },
      { label: "Тип", value: "Документальный" },
      { label: "Страна", value: "Великобритания, Франция" },
      { label: "Жанры", value: "Документальный, Биография, Спорт" },
      { label: "Внутренний номер", value: "tt1424432" },
    ],
    players: createKinopoiskPlayers(573209),
  },
  {
    id: 423,
    kinopoiskId: 5404281,
    imdbId: "tt9805674",
    slug: "planet-earth-iii",
    title: "BBC: Планета Земля III",
    originalTitle: "Planet Earth III",
    searchTitles: ["Планета Земля III", "Planet Earth III", "планета земля 3", "bbc planet earth iii"],
    type: "Документальный",
    year: "2023",
    rating: 8.6,
    genres: ["Документальный", "Природа"],
    countries: ["Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt9805674", title: "BBC: Планета Земля III", originalTitle: "Planet Earth III", year: "2023", type: "Документальный" }),
    description: "Новый документальный цикл BBC о природных средах, животных и меняющейся планете.",
    trailerUrl: "https://www.youtube.com/embed/nNWXMAJF7ww",
    longDescription: "«BBC: Планета Земля III» — документальный сериал 2023 года о разных средах обитания и удивительных формах жизни. Карточка добавлена в KinoLuma как документальный проект: работает шаблон описания, дополнительные сведения, sitemap и варианты просмотра по внутреннему номеру.",
    facts: [
      { label: "Год", value: "2023" },
      { label: "Тип", value: "Документальный" },
      { label: "Страна", value: "Великобритания" },
      { label: "Жанры", value: "Документальный, Природа" },
      { label: "Внутренний номер", value: "tt9805674" },
    ],
    players: createKinopoiskPlayers(5404281),
  },
  {
    id: 424,
    kinopoiskId: 4917950,
    imdbId: "tt10324164",
    slug: "prehistoric-planet",
    title: "Доисторическая планета",
    originalTitle: "Prehistoric Planet",
    searchTitles: ["Доисторическая планета", "Prehistoric Planet", "динозавры документальный", "prehistoric planet"],
    type: "Документальный",
    year: "2022",
    rating: 8.4,
    genres: ["Документальный", "Природа", "История"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt10324164", title: "Доисторическая планета", originalTitle: "Prehistoric Planet", year: "2022", type: "Документальный" }),
    description: "Кинематографичный документальный проект о доисторической жизни и мире динозавров.",
    trailerUrl: "https://www.youtube.com/embed/vnoNeMlNeD0",
    longDescription: "«Доисторическая планета» — документальный проект о жизни древней Земли, реконструированной через современную графику и научно-популярную подачу. Карточка добавлена аккуратно: без переписывания каталога, с текущим описанием, FAQ и плеерами по внутреннему номеру.",
    facts: [
      { label: "Год", value: "2022" },
      { label: "Тип", value: "Документальный" },
      { label: "Страна", value: "США, Великобритания" },
      { label: "Жанры", value: "Документальный, Природа, История" },
      { label: "Внутренний номер", value: "tt10324164" },
    ],
    players: createKinopoiskPlayers(4917950),
  },
  {
    id: 425,
    kinopoiskId: 1240162,
    imdbId: "tt8289930",
    slug: "formula-1-drive-to-survive",
    title: "Формула 1. Драйв выживания",
    originalTitle: "Formula 1: Drive to Survive",
    searchTitles: ["Формула 1 Драйв выживания", "Formula 1 Drive to Survive", "drive to survive", "f1 netflix"],
    type: "Документальный",
    year: "2019",
    rating: 8.5,
    genres: ["Документальный", "Спорт"],
    countries: ["Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt8289930", title: "Формула 1. Драйв выживания", originalTitle: "Formula 1: Drive to Survive", year: "2019", type: "Документальный" }),
    description: "Документальный сериал о сезонах Формулы-1, командах, гонщиках и закулисье чемпионата.",
    trailerUrl: "https://www.youtube.com/embed/wtJPe1ksS6E",
    longDescription: "«Формула 1. Драйв выживания» — документальный сериал о мире Формулы-1, работе команд и напряжении гоночного сезона. В KinoLuma карточка добавлена как документальный проект: постер через внутренний каталог, трейлер, факты, описание и дополнительные сведения через шаблон и варианты просмотра по внутреннему номеру.",
    facts: [
      { label: "Год", value: "2019" },
      { label: "Тип", value: "Документальный" },
      { label: "Страна", value: "Великобритания" },
      { label: "Жанры", value: "Документальный, Спорт" },
      { label: "Внутренний номер", value: "tt8289930" },
    ],
    players: createKinopoiskPlayers(1240162),
  },

  {
    id: 426,
    kinopoiskId: 4910679,
    imdbId: "tt17009710",
    slug: "anatomy-of-a-fall",
    title: "Анатомия падения",
    originalTitle: "Anatomie d'une chute",
    searchTitles: ["Анатомия падения", "Anatomy of a Fall", "Anatomie d'une chute", "анатомия падения"],
    type: "Фильм",
    year: "2023",
    rating: 7.7,
    genres: ["Драма", "Криминал", "Триллер"],
    countries: ["Франция"],
    poster: getTmdbPoster({ imdbId: "tt17009710", title: "Анатомия падения", originalTitle: "Anatomie d'une chute", year: "2023", type: "Фильм" }),
    description: "Писательница оказывается в центре судебного процесса после гибели мужа, а семейная история постепенно превращается в спор о правде.",
    trailerUrl: "https://www.youtube.com/embed/cDtaI3KFums",
    facts: [
      { label: "Страна", value: "Франция" },
      { label: "Длительность", value: "151 мин" },
      { label: "Бюджет", value: "около €6 млн" },
      { label: "Режиссёр", value: "Жюстин Трие" },
      { label: "Главные герои", value: "Сандра Войтер, Даниэль, Венсан, Самюэль" },
      { label: "Награды", value: "Золотая пальмовая ветвь, Оскар за оригинальный сценарий" },
    ],
    cast: [
      { name: "Сандра Хюллер", role: "Сандра Войтер" },
      { name: "Сванн Арло", role: "Венсан" },
      { name: "Мило Мачадо-Гранер", role: "Даниэль" },
    ],
    players: createKinopoiskPlayers(4910679),
  },
  {
    id: 427,
    kinopoiskId: 1048873,
    imdbId: "tt7160372",
    slug: "the-zone-of-interest",
    title: "Зона интересов",
    originalTitle: "The Zone of Interest",
    searchTitles: ["Зона интересов", "The Zone of Interest", "zone of interest"],
    type: "Фильм",
    year: "2023",
    rating: 7.4,
    genres: ["Драма", "История"],
    countries: ["Великобритания", "Польша", "США"],
    poster: getTmdbPoster({ imdbId: "tt7160372", title: "Зона интересов", originalTitle: "The Zone of Interest", year: "2023", type: "Фильм" }),
    description: "Холодная историческая драма о семье коменданта, которая строит бытовую идиллию рядом с местом большой трагедии.",
    trailerUrl: "https://www.youtube.com/embed/r-vfg3KkV54",
    facts: [
      { label: "Страна", value: "Великобритания, Польша, США" },
      { label: "Длительность", value: "105 мин" },
      { label: "Режиссёр", value: "Джонатан Глейзер" },
      { label: "Главные герои", value: "Рудольф Хёсс, Хедвиг Хёсс" },
      { label: "Студия", value: "A24, Film4, Access Entertainment" },
    ],
    cast: [
      { name: "Кристиан Фридель", role: "Рудольф Хёсс" },
      { name: "Сандра Хюллер", role: "Хедвиг Хёсс" },
    ],
    players: createKinopoiskPlayers(1048873),
  },
  {
    id: 428,
    kinopoiskId: 1077781,
    imdbId: "tt5537002",
    slug: "killers-of-the-flower-moon",
    title: "Убийцы цветочной луны",
    originalTitle: "Killers of the Flower Moon",
    searchTitles: ["Убийцы цветочной луны", "Killers of the Flower Moon", "скорсезе цветочная луна"],
    type: "Фильм",
    year: "2023",
    rating: 7.1,
    genres: ["Драма", "Криминал", "История"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt5537002", title: "Убийцы цветочной луны", originalTitle: "Killers of the Flower Moon", year: "2023", type: "Фильм" }),
    description: "Историческая криминальная сага Мартина Скорсезе о власти, деньгах и разрушении доверия внутри нефтяной резервации Осейджей.",
    trailerUrl: "https://www.youtube.com/embed/EP34Yoxs3FQ",
    facts: [
      { label: "Страна", value: "США" },
      { label: "Длительность", value: "206 мин" },
      { label: "Бюджет", value: "около $200 млн" },
      { label: "Режиссёр", value: "Мартин Скорсезе" },
      { label: "Главные герои", value: "Эрнест Беркхарт, Молли Беркхарт, Уильям Хейл" },
      { label: "Студия", value: "Apple Original Films, Imperative Entertainment" },
    ],
    cast: [
      { name: "Леонардо ДиКаприо", role: "Эрнест Беркхарт" },
      { name: "Лили Гладстоун", role: "Молли Беркхарт" },
      { name: "Роберт Де Ниро", role: "Уильям Хейл" },
    ],
    players: createKinopoiskPlayers(1077781),
  },
  {
    id: 429,
    kinopoiskId: 4396438,
    imdbId: "tt14230458",
    slug: "poor-things",
    title: "Бедные-несчастные",
    originalTitle: "Poor Things",
    searchTitles: ["Бедные-несчастные", "Poor Things", "бедные несчастные"],
    type: "Фильм",
    year: "2023",
    rating: 7.8,
    genres: ["Фантастика", "Драма", "Комедия"],
    countries: ["Великобритания", "США", "Ирландия"],
    poster: getTmdbPoster({ imdbId: "tt14230458", title: "Бедные-несчастные", originalTitle: "Poor Things", year: "2023", type: "Фильм" }),
    description: "Эксцентричная история взросления Беллы Бакстер в гротескном мире науки, свободы и социальных правил.",
    trailerUrl: "https://www.youtube.com/embed/RlbR5N6veqw",
    facts: [
      { label: "Страна", value: "Великобритания, США, Ирландия" },
      { label: "Длительность", value: "141 мин" },
      { label: "Бюджет", value: "около $35 млн" },
      { label: "Режиссёр", value: "Йоргос Лантимос" },
      { label: "Главные герои", value: "Белла Бакстер, Дункан Уэддерберн, Годвин Бакстер" },
      { label: "Основа", value: "роман Аласдера Грея" },
    ],
    cast: [
      { name: "Эмма Стоун", role: "Белла Бакстер" },
      { name: "Марк Руффало", role: "Дункан Уэддерберн" },
      { name: "Уиллем Дефо", role: "Годвин Бакстер" },
    ],
    players: createKinopoiskPlayers(4396438),
  },
  {
    id: 430,
    kinopoiskId: 4968810,
    imdbId: "tt17279496",
    slug: "civil-war-2024",
    title: "Падение империи",
    originalTitle: "Civil War",
    searchTitles: ["Падение империи", "Civil War", "Гражданская война", "Алекс Гарленд"],
    type: "Фильм",
    year: "2024",
    rating: 7.0,
    genres: ["Драма", "Боевик", "Триллер"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt17279496", title: "Падение империи", originalTitle: "Civil War", year: "2024", type: "Фильм" }),
    description: "Дорожный триллер о группе журналистов, которые пересекают расколотую страну и пытаются сохранить профессиональную дистанцию.",
    trailerUrl: "https://www.youtube.com/embed/aDyQxtg0V2w",
    facts: [
      { label: "Страна", value: "США, Великобритания" },
      { label: "Длительность", value: "109 мин" },
      { label: "Бюджет", value: "около $50 млн" },
      { label: "Режиссёр", value: "Алекс Гарленд" },
      { label: "Главные герои", value: "Ли, Джоэл, Джесси" },
      { label: "Студия", value: "A24, DNA Films" },
    ],
    cast: [
      { name: "Кирстен Данст", role: "Ли" },
      { name: "Вагнер Моура", role: "Джоэл" },
      { name: "Кейли Спэни", role: "Джесси" },
    ],
    players: createKinopoiskPlayers(4968810),
  },
  {
    id: 431,
    kinopoiskId: 4922904,
    imdbId: "tt17351924",
    slug: "saltburn",
    title: "Солтберн",
    originalTitle: "Saltburn",
    searchTitles: ["Солтберн", "Saltburn", "солтберн фильм"],
    type: "Фильм",
    year: "2023",
    rating: 7.0,
    genres: ["Драма", "Триллер", "Комедия"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ imdbId: "tt17351924", title: "Солтберн", originalTitle: "Saltburn", year: "2023", type: "Фильм" }),
    description: "Стильная сатирическая драма о студенте Оксфорда, который попадает в мир старой аристократии и чужих семейных правил.",
    trailerUrl: "https://www.youtube.com/embed/lALMdJf6UUE",
    facts: [
      { label: "Страна", value: "Великобритания, США" },
      { label: "Длительность", value: "131 мин" },
      { label: "Бюджет", value: "около $20 млн" },
      { label: "Режиссёр", value: "Эмиральд Феннел" },
      { label: "Главные герои", value: "Оливер Куик, Феликс Кэттон, Эльспет" },
      { label: "Студия", value: "Amazon MGM Studios, LuckyChap Entertainment" },
    ],
    cast: [
      { name: "Барри Кеоган", role: "Оливер Куик" },
      { name: "Джейкоб Элорди", role: "Феликс Кэттон" },
      { name: "Розамунд Пайк", role: "Эльспет" },
    ],
    players: createKinopoiskPlayers(4922904),
  },
  {
    id: 432,
    kinopoiskId: 5212291,
    imdbId: "tt23561236",
    slug: "american-fiction",
    title: "Американское чтиво",
    originalTitle: "American Fiction",
    searchTitles: ["Американское чтиво", "American Fiction", "американская литература"],
    type: "Фильм",
    year: "2023",
    rating: 7.3,
    genres: ["Драма", "Комедия"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt23561236", title: "Американское чтиво", originalTitle: "American Fiction", year: "2023", type: "Фильм" }),
    description: "Остроумная драма о писателе, который случайно превращает сатирический жест в издательский успех и семейный кризис.",
    trailerUrl: "https://www.youtube.com/embed/i0MbLCpYJPA",
    facts: [
      { label: "Страна", value: "США" },
      { label: "Длительность", value: "117 мин" },
      { label: "Бюджет", value: "около $10 млн" },
      { label: "Режиссёр", value: "Корд Джефферсон" },
      { label: "Главные герои", value: "Телониус Эллисон, Синтара, Лиза, Артур" },
      { label: "Основа", value: "роман Percival Everett «Erasure»" },
    ],
    cast: [
      { name: "Джеффри Райт", role: "Телониус Эллисон" },
      { name: "Трейси Эллис Росс", role: "Лиза" },
      { name: "Стерлинг К. Браун", role: "Клиффорд" },
    ],
    players: createKinopoiskPlayers(5212291),
  },
  {
    id: 433,
    kinopoiskId: 4860116,
    imdbId: "tt16426418",
    slug: "challengers",
    title: "Претенденты",
    originalTitle: "Challengers",
    searchTitles: ["Претенденты", "Challengers", "претенденты 2024"],
    type: "Фильм",
    year: "2024",
    rating: 7.1,
    genres: ["Драма", "Спорт", "Мелодрама"],
    countries: ["США", "Италия"],
    poster: getTmdbPoster({ imdbId: "tt16426418", title: "Претенденты", originalTitle: "Challengers", year: "2024", type: "Фильм" }),
    description: "Спортивная драма о теннисе, соперничестве и давней связи трёх людей, где матч становится продолжением личной истории.",
    trailerUrl: "https://www.youtube.com/embed/VobTTbg-te0",
    facts: [
      { label: "Страна", value: "США, Италия" },
      { label: "Длительность", value: "131 мин" },
      { label: "Бюджет", value: "около $55 млн" },
      { label: "Режиссёр", value: "Лука Гуаданьино" },
      { label: "Главные герои", value: "Таши Дункан, Арт Дональдсон, Патрик Цвейг" },
      { label: "Студия", value: "MGM, Pascal Pictures" },
    ],
    cast: [
      { name: "Зендея", role: "Таши Дункан" },
      { name: "Майк Фейст", role: "Арт Дональдсон" },
      { name: "Джош О'Коннор", role: "Патрик Цвейг" },
    ],
    players: createKinopoiskPlayers(4860116),
  },
  {
    id: 434,
    kinopoiskId: 1182400,
    imdbId: "tt7775622",
    slug: "free-solo",
    title: "Фри-соло",
    originalTitle: "Free Solo",
    searchTitles: ["Фри-соло", "Free Solo", "Алекс Хоннольд", "эль капитан"],
    type: "Документальный",
    year: "2018",
    rating: 8.1,
    genres: ["Документальный", "Спорт", "Биография"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt7775622", title: "Фри-соло", originalTitle: "Free Solo", year: "2018", type: "Документальный" }),
    description: "Документальный фильм о подготовке Алекса Хоннольда к прохождению маршрута на Эль-Капитане без страховочного снаряжения.",
    trailerUrl: "https://www.youtube.com/embed/urRVZ4SW7WU",
    facts: [
      { label: "Страна", value: "США" },
      { label: "Длительность", value: "100 мин" },
      { label: "Режиссёр", value: "Джимми Чин, Элизабет Чай Васархели" },
      { label: "Главные герои", value: "Алекс Хоннольд" },
      { label: "Награды", value: "Оскар за лучший документальный фильм" },
    ],
    cast: [
      { name: "Алекс Хоннольд", role: "участник документального проекта" },
      { name: "Санни Маккэндлесс", role: "участница документального проекта" },
    ],
    players: createKinopoiskPlayers(1182400),
  },
  {
    id: 435,
    kinopoiskId: 4632169,
    imdbId: "tt9098872",
    slug: "the-rescue-2021",
    title: "Спасательная операция",
    originalTitle: "The Rescue",
    searchTitles: ["Спасательная операция", "The Rescue", "тайские пещеры документальный"],
    type: "Документальный",
    year: "2021",
    rating: 8.3,
    genres: ["Документальный", "История"],
    countries: ["США", "Великобритания"],
    poster: getTmdbPoster({ imdbId: "tt9098872", title: "Спасательная операция", originalTitle: "The Rescue", year: "2021", type: "Документальный" }),
    description: "Хроника международной операции по спасению подростковой футбольной команды из затопленной пещеры в Таиланде.",
    trailerUrl: "https://www.youtube.com/embed/_-Kw5kAPSbk",
    facts: [
      { label: "Страна", value: "США, Великобритания" },
      { label: "Длительность", value: "107 мин" },
      { label: "Режиссёр", value: "Джимми Чин, Элизабет Чай Васархели" },
      { label: "Главные герои", value: "участники спасательной операции и команда Wild Boars" },
      { label: "Тема", value: "реальная спасательная операция 2018 года" },
    ],
    players: createKinopoiskPlayers(4632169),
  },
  {
    id: 436,
    kinopoiskId: 1405676,
    imdbId: "tt12888462",
    slug: "my-octopus-teacher",
    title: "Мой учитель-осьминог",
    originalTitle: "My Octopus Teacher",
    searchTitles: ["Мой учитель-осьминог", "My Octopus Teacher", "осьминог документальный"],
    type: "Документальный",
    year: "2020",
    rating: 8.1,
    genres: ["Документальный", "Природа", "Биография"],
    countries: ["ЮАР"],
    poster: getTmdbPoster({ imdbId: "tt12888462", title: "Мой учитель-осьминог", originalTitle: "My Octopus Teacher", year: "2020", type: "Документальный" }),
    description: "Наблюдательная история о документалисте, который возвращается к подводному миру и открывает необычную связь с осьминогом.",
    trailerUrl: "https://www.youtube.com/embed/3s0LTDhqe5A",
    facts: [
      { label: "Страна", value: "ЮАР" },
      { label: "Длительность", value: "85 мин" },
      { label: "Режиссёр", value: "Пиппа Эрлих, Джеймс Рид" },
      { label: "Главные герои", value: "Крейг Фостер и осьминог из леса ламинарий" },
      { label: "Награды", value: "Оскар за лучший документальный фильм" },
    ],
    cast: [
      { name: "Крейг Фостер", role: "участник документального проекта" },
    ],
    players: createKinopoiskPlayers(1405676),
  },
  {
    id: 437,
    kinopoiskId: 4831860,
    imdbId: "tt16227014",
    slug: "fire-of-love",
    title: "Вулкан любви",
    originalTitle: "Fire of Love",
    searchTitles: ["Вулкан любви", "Fire of Love", "Катя и Морис Краффт"],
    type: "Документальный",
    year: "2022",
    rating: 7.6,
    genres: ["Документальный", "Биография", "Природа"],
    countries: ["США", "Канада"],
    poster: getTmdbPoster({ imdbId: "tt16227014", title: "Вулкан любви", originalTitle: "Fire of Love", year: "2022", type: "Документальный" }),
    description: "Архивная документальная история вулканологов Кати и Мориса Краффт, которые посвятили жизнь изучению извержений.",
    trailerUrl: "https://www.youtube.com/embed/oMArx64RBO4",
    facts: [
      { label: "Страна", value: "США, Канада" },
      { label: "Длительность", value: "93 мин" },
      { label: "Режиссёр", value: "Сара Доса" },
      { label: "Главные герои", value: "Катя Краффт, Морис Краффт" },
      { label: "Формат", value: "архивные материалы и рассказ" },
    ],
    players: createKinopoiskPlayers(4831860),
  },
  {
    id: 438,
    kinopoiskId: 727913,
    imdbId: "tt2545118",
    slug: "blackfish",
    title: "Чёрный плавник",
    originalTitle: "Blackfish",
    searchTitles: ["Чёрный плавник", "Черный плавник", "Blackfish", "косатка Тиликум"],
    type: "Документальный",
    year: "2013",
    rating: 8.1,
    genres: ["Документальный", "Природа"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt2545118", title: "Чёрный плавник", originalTitle: "Blackfish", year: "2013", type: "Документальный" }),
    description: "Документальное расследование о содержании косаток в неволе и последствиях индустрии морских парков.",
    trailerUrl: "https://www.youtube.com/embed/fLOeH-Oq_1Y",
    facts: [
      { label: "Страна", value: "США" },
      { label: "Длительность", value: "83 мин" },
      { label: "Режиссёр", value: "Габриэла Каупертвэйте" },
      { label: "Главные герои", value: "Тиликум, бывшие тренеры и эксперты" },
      { label: "Тема", value: "животные в неволе и индустрия развлечений" },
    ],
    players: createKinopoiskPlayers(727913),
  },
  {
    id: 439,
    kinopoiskId: 416324,
    imdbId: "tt1155592",
    slug: "man-on-wire",
    title: "Человек на проволоке",
    originalTitle: "Man on Wire",
    searchTitles: ["Человек на проволоке", "Man on Wire", "Филипп Пети"],
    type: "Документальный",
    year: "2008",
    rating: 7.7,
    genres: ["Документальный", "Биография", "История"],
    countries: ["Великобритания", "США"],
    poster: getTmdbPoster({ imdbId: "tt1155592", title: "Человек на проволоке", originalTitle: "Man on Wire", year: "2008", type: "Документальный" }),
    description: "Документальная реконструкция знаменитого прохода Филиппа Пети между башнями Всемирного торгового центра в 1974 году.",
    trailerUrl: "https://www.youtube.com/embed/Cz6oddi0mts",
    facts: [
      { label: "Страна", value: "Великобритания, США" },
      { label: "Длительность", value: "94 мин" },
      { label: "Режиссёр", value: "Джеймс Марш" },
      { label: "Главные герои", value: "Филипп Пети и участники подготовки прохода" },
      { label: "Награды", value: "Оскар за лучший документальный фильм" },
    ],
    players: createKinopoiskPlayers(416324),
  },
  {
    id: 440,
    kinopoiskId: 513258,
    imdbId: "tt1645089",
    slug: "inside-job-2010",
    title: "Инсайдеры",
    originalTitle: "Inside Job",
    searchTitles: ["Инсайдеры", "Inside Job", "финансовый кризис документальный"],
    type: "Документальный",
    year: "2010",
    rating: 8.2,
    genres: ["Документальный", "История", "Биография"],
    countries: ["США"],
    poster: getTmdbPoster({ imdbId: "tt1645089", title: "Инсайдеры", originalTitle: "Inside Job", year: "2010", type: "Документальный" }),
    description: "Документальный разбор финансового кризиса 2008 года, решений банков, регуляторов и экономической системы.",
    trailerUrl: "https://www.youtube.com/embed/FzrBurlJUNk",
    facts: [
      { label: "Страна", value: "США" },
      { label: "Длительность", value: "109 мин" },
      { label: "Режиссёр", value: "Чарльз Фергюсон" },
      { label: "Главные герои", value: "экономисты, журналисты, представители финансовой индустрии" },
      { label: "Награды", value: "Оскар за лучший документальный фильм" },
    ],
    players: createKinopoiskPlayers(513258),
  },
  {
    id: 441,
    kinopoiskId: 654439,
    imdbId: "tt2125608",
    slug: "searching-for-sugar-man",
    title: "В поисках Сахарного Человека",
    originalTitle: "Searching for Sugar Man",
    searchTitles: ["В поисках Сахарного Человека", "Searching for Sugar Man", "Родригес музыкант"],
    type: "Документальный",
    year: "2012",
    rating: 8.2,
    genres: ["Документальный", "Музыка", "Биография"],
    countries: ["Швеция", "Великобритания", "Финляндия"],
    poster: getTmdbPoster({ imdbId: "tt2125608", title: "В поисках Сахарного Человека", originalTitle: "Searching for Sugar Man", year: "2012", type: "Документальный" }),
    description: "Музыкальное расследование о певце Родригесе, чьи песни неожиданно стали важной частью культуры в другой стране.",
    trailerUrl: "https://www.youtube.com/embed/KKXewWDh1og",
    facts: [
      { label: "Страна", value: "Швеция, Великобритания, Финляндия" },
      { label: "Длительность", value: "86 мин" },
      { label: "Режиссёр", value: "Малик Бенджеллуль" },
      { label: "Главные герои", value: "Сиксто Родригес, Стивен Сегерман, Крейг Бартоломью Страйдом" },
      { label: "Награды", value: "Оскар за лучший документальный фильм" },
    ],
    players: createKinopoiskPlayers(654439),
  },

  ...manualPremiumAdditions,
  ...manualPopularAnime,
  ...generatedKinoLumaMovies,
  ...curatedExpectedReleases,
  ...generatedKinopoiskRequestedMovies,
  ...generatedKinoLumaCartoons,

];

const BLOCKED_PUBLIC_CONTENT_TYPES = new Set<ContentType>(["Документальный"]);

const BLOCKED_PUBLIC_GENRE_PARTS = [
  "документ",
  "реальное тв",
  "реалити",
  "reality",
  "ток-шоу",
  "ток шоу",
  "talk show",
  "концерт",
  "concert",
  "музыка",
  "music",
  "новости",
  "news",
  "церемония",
  "шоу",
];

function normalizePublicCatalogText(value: string) {
  return value.toLowerCase().replaceAll("ё", "е").trim();
}

function getPublicCatalogYear(movie: Movie) {
  const match = String(movie.year || "").match(/\d{4}/);
  if (!match) return 0;

  const year = Number(match[0]);
  return Number.isFinite(year) ? year : 0;
}

function hasBlockedPublicGenre(movie: Movie) {
  return (movie.genres ?? []).some((genre) => {
    const normalizedGenre = normalizePublicCatalogText(String(genre));
    return BLOCKED_PUBLIC_GENRE_PARTS.some((blockedGenre) => normalizedGenre.includes(blockedGenre));
  });
}

function isCuratedExpectedRelease(movie: Movie) {
  return normalizePublicCatalogText(movie.source || "") === "kinoluma-curated-expected";
}

function isExpectedGeneratedRelease(movie: Movie) {
  if (isCuratedExpectedRelease(movie)) return false;

  const source = normalizePublicCatalogText(movie.source || "");
  const genres = (movie.genres ?? []).map((genre) => normalizePublicCatalogText(String(genre))).join(" ");
  const year = getPublicCatalogYear(movie);
  const currentYear = new Date().getFullYear();

  if (source.includes("ожидаем") || genres.includes("ожидаем")) return true;
  if (year >= currentYear && movie.rating <= 0.1) return true;

  return false;
}

function isPublicCatalogMovie(movie: Movie) {
  if (BLOCKED_PUBLIC_CONTENT_TYPES.has(movie.type)) return false;
  if (hasBlockedPublicGenre(movie)) return false;
  if (isExpectedGeneratedRelease(movie)) return false;

  return true;
}

function getPublicMovieUniqueKey(movie: Movie) {
  const slug = normalizePublicCatalogText(movie.slug || "");
  if (slug) return `slug:${slug}`;

  if (movie.kinopoiskId) return `kp:${movie.kinopoiskId}`;
  if (movie.imdbId) return `imdb:${normalizePublicCatalogText(movie.imdbId)}`;

  return `title:${normalizePublicCatalogText(`${movie.title}-${movie.originalTitle}-${movie.year}`)}`;
}

const seenPublicMovieKeys = new Set<string>();

function isUniquePublicMovie(movie: Movie) {
  const key = getPublicMovieUniqueKey(movie);
  if (seenPublicMovieKeys.has(key)) return false;

  seenPublicMovieKeys.add(key);
  return true;
}

export const movies: Movie[] = moviesRaw
  .filter(isPublicCatalogMovie)
  .filter(isUniquePublicMovie);


movies.forEach((movie) => {
  hydrateMovieContent(movie);
  sanitizeMoviePublicFields(movie);
});

export function getMovieBySlug(slug: string) {
  return movies.find((movie) => movie.slug === slug);
}
